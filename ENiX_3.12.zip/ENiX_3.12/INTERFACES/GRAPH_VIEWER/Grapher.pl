#!/usr/bin/perl -w
use strict;

use Math::Trig;

my @BUFFER=`cat EnglishGraph.txt`;

sub BASIC($){
    my $A=shift;
    my ($SIZE,$STR);
    my @COMPONENTS=();
    for($SIZE=0;$SIZE<@BUFFER;$SIZE++){
	if($BUFFER[$SIZE]=~m/$A/){
	    $STR=$BUFFER[$SIZE];
	    $STR=~s/$A//g;
	    @COMPONENTS=split(' ',$STR);
	}
    }
    return @COMPONENTS;
}

my @MOODS=BASIC("^Moods of grammar: +");
my @ARTICLES=BASIC("^Articles of grammar: +");

sub CACHE($){
    my $A=shift;
    my ($SIZE,$STR);
    my $FOUND=0;
    my @LINES=();
    for($SIZE=0;$SIZE<@BUFFER;$SIZE++){
	if($BUFFER[$SIZE]=~m/$A/){
	    $FOUND=1;
	}
	else{
	    if($FOUND==1){
		if($BUFFER[$SIZE]=~m/^ [^ ] /){
		    $FOUND=0;
		}
		else{
		    $STR=$BUFFER[$SIZE];
		    $STR=~s/^.*-> //g;
		    chomp $STR;
		    push @LINES,$STR;
		}
	    }
	}
    }
    return @LINES;
}

my @XOrdinates=();
my @YOrdinates=();

sub CreatePositions{
    my $NUMBER=@ARTICLES;
    my $DEGREES=(2*pi);
    my $RADIUS=400;
    my $POSITION;
    my $INCRIMENT=$DEGREES/$NUMBER;
    my ($X,$Y);
    for($POSITION=0;$POSITION<$DEGREES;$POSITION+=$INCRIMENT){
	$X=int($RADIUS*cos($POSITION))+$RADIUS+100;
	$Y=int($RADIUS*sin($POSITION))+$RADIUS+100;
	push @XOrdinates, ${X};
	push @YOrdinates, ${Y};
    }
}

my @CACHED=();
my @HMM;
sub GenerateMarkovModels{
    my ($POS1,$POS2,$POS3,@SPLIT,@DATA,@ANSWER);
    @ANSWER=();
    @HMM=();
    for($POS1=0;$POS1<@CACHED;$POS1++){
	@DATA=();
	if(${CACHED[$POS1]}=~m/N\/A/){
	    @DATA=();
	}
	else{
	    @SPLIT=();
	    @SPLIT=split(' ',${CACHED[$POS1]});
	    for($POS2=0;$POS2<@SPLIT;$POS2++){
		for($POS3=0;$POS3<@ARTICLES;$POS3++){
		    if(${ARTICLES[$POS3]}=~m/^${SPLIT[$POS2]}$/){
			push @DATA,$POS3;
		    }
		}
	    }
	}
	push @ANSWER, [@DATA];
    }
    @HMM=@ANSWER;
}

sub DrawGraph{
    my ($TITLE,$POS1,$POS2,$POS3,$HEIGHT,@DATA);
    my ($X,$Y,$XF,$YF,$BEGX,$BEGY,$FINX,$FINY);
    my ($Wibble,$Wobble);
    my $SPACING=1000;
    print "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.0//EN\" \"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\">\n";
    print "<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width='1100px' height='4000px'>\n";
    print "<title>Language Graphs</title>\n";
    print "<defs><marker id='myMarker' viewBox=\"0 0 20 10\" refX='1' refY='5' orient='auto' markerWidth='10' markerHeight='3'>\n";
    print "<polyline points=\"0,0 10,5 0,10 1,5\" fill='white' />\n";
    print "</marker></defs>\n";
    for($POS1=0;$POS1<@MOODS;$POS1++){
	$HEIGHT=$POS1*$SPACING+20;
	@CACHED=CACHE("^ . ${MOODS[$POS1]}");
	GenerateMarkovModels;
	$Wobble=uc(${MOODS[$POS1]});
	print "<text x='10' y=\"${HEIGHT}\" fill='yellow'>${Wobble}</text>\n";
	for($POS2=0;$POS2<@ARTICLES;$POS2++){
	    $X=${XOrdinates[$POS2]};
	    $Y=${YOrdinates[$POS2]}+$HEIGHT;
	    $Wibble=uc(${ARTICLES[$POS2]});
	    print "<text x=\"${X}px\" y=\"${Y}px\" fill='yellow'>${Wibble}</text>\n";
	    print "<circle cx=\"${X}\" cy=\"${Y}\" r='2' style='fill: white;'> </circle>\n";
	}
	for($POS2=0;$POS2<@HMM;$POS2++){
	    @DATA=();
	    @DATA=@{$HMM[$POS2]};
	    $X=${XOrdinates[$POS2]};
	    $Y=${YOrdinates[$POS2]}+$HEIGHT;
	    for($POS3=0;$POS3<@DATA;$POS3++){
		$XF=${XOrdinates[$DATA[$POS3]]};
		$YF=${YOrdinates[$DATA[$POS3]]}+$HEIGHT;
		$BEGX=(20*$X+$XF)/21;
		$BEGY=(20*$Y+$YF)/21;
		$FINX=($X+20*$XF)/21;
		$FINY=($Y+20*$YF)/21;
		print "<line x1=\"$BEGX\" y1=\"$BEGY\" x2=\"$FINX\" y2=\"$FINY\" stroke='white' stroke-width='2' marker-end='url(#myMarker)' />\n";
	    }
	}
    }
    print "</svg>\n";
}

CreatePositions;
DrawGraph;
