#!/usr/bin/perl -w

#################################################################
#                                                               #
#                 <<< GPL 2015, [OvO]wl >>>                     #
#                                                               #
#     This is an interface to generate music from ENiX 3.       #
#                                                               #
#         You need to install timidity and MIDI perl!           #
#                 To install soundfonts add:                    #
#                                                               #
#     soundfont /home/martyn/bin/MIDI/SF/Drum1/Drum1.sf2        #
#                                                               #
#      to /etc/timidity.cfg (or where ever the config is)       #
#                                                               #
# Remember to restart timidity ("/etc/init.d/timidity restart") #
#                                                               #
#################################################################

use MIDI;
use strict;
use warnings;

my $ENiX_EXE="";
my $ITERATION=0;

#######################################################
# To regenerate a particular track override this seed #
#######################################################
my $Seed=0;

my @events=();

sub Input;
sub Setup;
sub GetENiXOutput;
sub Read;
sub CreateMidi;
sub Convert2Mp3;

sub Input{
    my $NumArgs=$#ARGV+1;
    if ($NumArgs!=1) {
	print "\nUsage: ./Create_Track.pl <ENiX3 Binary Path>\n\n";
	exit;
    }
    $ENiX_EXE="${ARGV[0]}";
    unless( -e "${ENiX_EXE}"){
	print "\nERROR: ${ENiX_EXE} does not exist - aborting.\n\n";
	exit;
    }
    print "\nInput all looks valid, continuing...\n";
    if(!$Seed){
	$Seed=`date +%s`;
	chomp $Seed;
    }
    print "Using seed: ${Seed}\n";
}

sub Setup(){
    @events = (
        ['text_event',0, 'ENiX 3 Artificial Intelligence'],
        ['set_tempo', 0, 450_000], # 1qn = .45 seconds
        );
}

sub GetENiXOutput{
    my $Filename="";
    while( -e "ENiX3-${ITERATION}.txt"){
	$ITERATION++;
    }
    $Filename="ENiX3-${ITERATION}.txt";
    print "${Filename} does not exist, creating (this may take some time)...\n";
    `"${ENiX_EXE}" ":force adam :load"`;
    `"${ENiX_EXE}" ":force ${Seed} :randseed"`;
    `"${ENiX_EXE}" :music | grep -Ev "START|END" > "${Filename}"`;
}

sub Read(){
    my ($A,$B,$C,$Prev);
    my @Input=`cat "ENiX3-${ITERATION}.txt"`;
    my @Info;
    ${B}=@Input;
    ${Prev}=-1;
    print "Reading data...\n";
    for(${A}=0;${A}<${B};${A}++){
        chomp ${Input[${A}]};
        @Info=split(' ',${Input[${A}]});
        if(${Info[1]} != ${Prev}){
            push @events, ['patch_change' ,0,1,${Info[1]}], ;
        }
        push @events, ['note_on' ,0,1,${Info[2]},${Info[3]}], ['note_off',${Info[0]},1,${Info[2]},${Info[3]}], ;
        ${Prev}=${Info[1]};
    }
}

sub CreateMidi(){
    my $Track = MIDI::Track->new({ 'events' => \@events });
    my $opus = MIDI::Opus->new( { 'format' => 0, 'ticks' => 96, 'tracks' => [ $Track ] } );
    print "Writing data to midi file...\n";
    $opus->write_to_file( "ENiX3-${ITERATION}.mid" );
}

sub Convert2Mp3{
    print "Converting Midi file to mp3 (please wait)...\n";
    `timidity "ENiX3-${ITERATION}.mid" -Ow -o - | lame - -b 64 "ENiX3-${ITERATION}-${Seed}.mp3"`;
}

Input;
GetENiXOutput;
Setup;
Read;
CreateMidi;
Convert2Mp3;
