/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "ENiX_Globals.h"
#include "ENiX_STRING.h"
#include "ENiX_WMS.h"
#include "ENiX_WMS_COMPAT.h"
#include "ENiX_MULTIPLEX.h"
#include "ENiX_STEMMER.h"
#include "ENiX_LIST.h"
#include "ENiX_CONV.h"
#include "ENiX_OUTPUT.h"
#include "ENiX_DISK.h"
#include "ENiX_NLP.h"

/*! \brief The conversation buffer holds all conversation between ENiX and external entities.
 *
 */
struct Datablock *CreateConvBuffer(){
  struct Datablock *DB=NULL;
  if(!(DB=Goto_DB_Entry(Database[1],":convbuf")))
    DB=Database[1]=Add_DB_Entry(Database[1],":convbuf");
  return DB;
}

/*! \brief Add data to this conversation buffer.
 * - Source is the origin of the data. Data is the data to be stored.
 */
struct Datablock *Add2ConvBuffer(char *Source,char *Data){
  struct Datablock *DB=CreateConvBuffer();
  Add_DB_Pair(DB,Source,Data);
  return DB;
}

/*! \brief Dump the contents of the conversation buffer to the screen.
 * 
 */
struct List_Str  *GetConvBuffer(struct List_Str *Word_Buffer,struct List_Str *L){
  struct List_Str *Source=NULL,*Sentence=NULL;
  struct Datablock *DB=NULL;
  if((DB=Goto_DB_Entry(Database[1],":convbuf")))
    for(Source=DB->DS[1],Sentence=DB->DS[2];Source&&Sentence;Source=Source->Next,Sentence=Sentence->Next)
      printf("%s: %s\n",Source->Str,Sentence->Str);
  else
    if(ThinkOutLoud)
      printf("Warning: %s:%s:%d, Language / Conv buffer not setup.\n",__func__,__FILE__,__LINE__);
  return L;
}

/*! \brief The question buffer stores all questions that ENiX asks.
 * 
 */
struct Datablock *CreateQBuffer(){
  struct Datablock *DB=NULL;
  if(!(DB=Goto_DB_Entry(Database[1],":qbuf")))
    DB=Database[1]=Add_DB_Entry(Database[1],":qbuf");
  return DB;
}

/*! \brief Add data to this question buffer.
 * - Source is the origin of the data. Data is the data to be stored.
 */
struct Datablock *Add2QBuffer(char *Source,char *Data){
  struct Datablock *DB=CreateQBuffer();
  if(!Is_List_Element(DB->DS[2],Data))
    Add_DB_Pair(DB,Source,Data);
  return DB;
}

/*! \brief Dump the contents of the question buffer to the screen.
 * 
 */
struct List_Str  *GetQBuffer(struct List_Str *Word_Buffer,struct List_Str *L){
  struct List_Str *Source=NULL,*Sentence=NULL;
  struct Datablock *DB=NULL;
  if((DB=Goto_DB_Entry(Database[1],":qbuf")))
    for(Source=DB->DS[1],Sentence=DB->DS[2];Source&&Sentence;Source=Source->Next,Sentence=Sentence->Next)
      printf("%s: %s\n",Source->Str,Sentence->Str);
  else{
    if(ThinkOutLoud)
      printf("Warning: %s:%s:%d, Language / Q buffer not setup.\n",__func__,__FILE__,__LINE__);
    CreateQBuffer();
  }
  return L;
}

/*! \brief Associates user replies with questions that ENiX previously asked.
 * 
 */
struct List_Str *Think1(struct List_Str *WordList,struct List_Str *L){
  int C=0,Pos=0,AnswerFound=0,InitialVerbosity=0;
  char *SourceStr=NULL,*ConvStr=NULL,*FinalAnswer=NULL;
  struct List_Str *Source=NULL,*Question=NULL,*Result=NULL;
  struct Datablock *DB=NULL,*CONVDAT=NULL;
  struct Sentence *SData=NULL,*TempSentence=NULL;

  if(Detect_Sentiency()){
    if(ThinkOutLoud)
      puts("WARNING: Thinking activated.");
    
    if(!(DB=CreateQBuffer())){
      puts("No :qbuf data to process - aborting.");
      if(ThinkOutLoud)
	puts("WARNING: Thinking Finished.");
      return L;
    }

    InitialVerbosity=DetectVerbosity();
    
    /* go through each item in :qbuf look at the verb and see if its understood */    
    for(Source=DB->DS[1],Question=DB->DS[2];Question&&Source;){

      /* break up sentence into SData using ConvertSentence */
      SData=ConvertSentence(Str2List(Question->Str),0,0);

      /* if it is understood, then remove it from the buffer ! */
      if(IsConceptUnderstood(SData)==2){

	/* acknowledge understanding */
	if(InitialVerbosity)
	  printf("I understand: \"%s\"\n",Question->Str);
	Del_DB_Pair(DB,Source->Str,Question->Str);
	Source=DB->DS[1];
	Question=DB->DS[2];
      }
      else{
	if(InitialVerbosity)
	  printf("I don't understand: \"%s\"\n",Question->Str);
	Question=Question->Next;
	Source=Source->Next;
	
      }
    }

    /* the answers to questions in :convbuf from :qbuf. these need to be fed back into ENiX */
    if(!(CONVDAT=Goto_DB_Entry(Database[1],":convbuf"))){
      puts("No :convbuf data to process - aborting.");
      puts("WARNING: Thinking Finished."); 
      return L;
    }

    /* go through each remaining question */
    for(Source=DB->DS[1],Question=DB->DS[2];Question&&Source;Question=Question->Next,Source=Source->Next){
      SData=ConvertSentence(Str2List(Question->Str),0,0);
      AnswerFound=0;

      /* determine if the question is a ynq */
      if(!strcmp(SData->Mood,"ynq")){
      
	/* find the question in the conv buffer */
	if((Pos=Find_List_Element(CONVDAT->DS[2],Question->Str))+1){

	  /* look for the answer */
	  for(C=Pos-1;C>-1;C--){
	    SourceStr=Get_List_Element(CONVDAT->DS[1],C);
	    ConvStr=Get_List_Element(CONVDAT->DS[2],C);

	    /* if there is a YNQ before a yes or no answer then disambiguate */
	    /* only consider ENiX output, not thoughts */
	    if(!strcmp(SourceStr,"ENiX")){
	      /* need to determine if the output is in the qbuf */
	      if(Is_List_Element(CONVDAT->DS[2],ConvStr)){
		TempSentence=ConvertSentence(Str2List(ConvStr),0,0);
		if(TempSentence->Mood)
		  if(!strcmp(TempSentence->Mood,"ynq")){
		    /* if the answer to a question is found then break
		       and update the information appropriately */
		    if(AnswerFound){
		      break;
		    }
		    else{
		      
		      /* disambiguate */
		      puts("DEBUG Think1: disambiguate.");
		    }
		  }
	      }
	    }
	    
	    /* determine if its the answer */
	    if(strcmp(SourceStr,"ENiX")||strcmp(SourceStr,"Thoughts")){
	      if((!strcmp(ConvStr,"yes"))||(!strcmp(ConvStr,"no"))){
		FinalAnswer=ConvStr;
		AnswerFound=1;
	      }
	    }
	  }
	  
	  /* at this point, we have stopped searching for the answer to our question */
	  if(AnswerFound){
	    if(!strcmp(FinalAnswer,"yes")){
	      /* rearrange the question */
	      Result=Convert2Sentence(CreateSentenceStruct(SData->RefinedSubject,SData->SubjectLogic,SData->RefinedPredicate,SData->PredicateLogic,SData->RefinedVerb,0,"indicative"));
	      if(InitialVerbosity)
		PrintListSpecial("User confirmed: \"",Result," "," ","\"\n");
	      SetVerbosity(0);
	      IntelligentInt(Result,1);
	      SetVerbosity(InitialVerbosity);
	    }
	    if(!strcmp(FinalAnswer,"no")){
	      /* need to remove the thought from the concept */
	      /* Need to query what the effect would be of the cause */
	      /* need to negate the sentence! */
	      Result=Convert2Sentence(CreateSentenceStruct(SData->RefinedSubject,SData->SubjectLogic,SData->RefinedPredicate,SData->PredicateLogic,SData->RefinedVerb,0,"indicative"));
	      Result=NegateSentence(Result);
	      if(InitialVerbosity)
		PrintListSpecial("New modifying information: \"",Result," "," ","\"\n");
	      SetVerbosity(0);
	      IntelligentInt(Result,1);
	      SetVerbosity(InitialVerbosity);
	    }
	    break;
	  }
	}
      }
    }
    if(ThinkOutLoud)
      puts("WARNING: Thinking Finished.");
  }
  return L;
}

/*! \brief The sleep function maintains the WMS database and passively processes any unresolved questions or gaps in understanding that ENiX has.
 * 
 */
struct List_Str *Sleep(struct List_Str *WordList,struct List_Str *L){
   int                             C=0,Days=0,Months=0,Years=0; 
   double                          NumberToForget=0,OccuranceProb=0;
   char                            *RecordTime=NULL,*Time=Gettime(),*B=NULL;
   struct Datablock                *R=Database[1],*LS=NULL;
   struct List_Str                 *List=NULL; 

   if(ThinkOutLoud)
     puts("Classifying words...");
   for(LS=Database[1];LS;LS=LS->Next)
     StemClass(Str2List(LS->DS[0]->Str),NULL);
   Think1(NULL,NULL);

   Years=atoi(Time+9); 
   Months=atoi(Time+14); 
   Days=atoi(Time+17);
   if(Days<MemoryExp+2){ 
     if(Months==1){
       Years--;
       Months=12;
     } 
     else
       Months--;
     Days+=29-MemoryExp;
   }
   else
     Days-=MemoryExp;
   snprintf(Time+9,11,"%04d/%02d/%02d\n",Years,Months,Days);
   while(R){
      Rep_DB_Entry(R,0,6,FloatToString(MemoryProbability*atof(Get_DB_Entry(R,0,6))));
      R=R->Next;
   } 
   R=Database[1];
   if(MemoryLimit==-1){
      NumberToForget=Newly_Learnt*MemoryRate;
      while((R)&&(C<NumberToForget)){
	 B=Get_DB_Entry(R,0,0); 
	 if(B[0]!=':'){
	    OccuranceProb=atof(Get_DB_Entry(R,0,6));
	    RecordTime=Get_DB_Entry(R,0,5); 
	    if((OccuranceProb<MemoryThreshold)&&(strcmp(RecordTime+9,Time+9)<0)){ 
	       List=Ins_List_Element(List,B,0);
	       C++;
	    }
	 } 
	 R=R->Next;
      }
   }
   else{ 
      if(DB_Size>MemoryLimit){
	 NumberToForget=(DB_Size-=MemoryLimit);
	 while((R)&&(C<NumberToForget)){
	    B=Get_DB_Entry(R,0,0);
	    if(B[0]!=':'){
	       OccuranceProb=atof(Get_DB_Entry(R,0,6));
	       RecordTime=Get_DB_Entry(R,0,5);
	       if((OccuranceProb<MemoryThreshold)&&(strcmp(RecordTime+9,Time+9)<0)){ 
		  List=Ins_List_Element(List,B,0);
		  C++;
	       }
	    } 
	    R=R->Next;
	 }
      }
   }
   while(List){
      LS=Del_DB_Entry(LS,Find_DB_Entry(LS,List->Str));
      List=Del_List_Element(List,0);
   }
   Rep_DB_Entry(Goto_DB_Entry(LS,":mode"),2,5,FloatToString(Newly_Learnt=0));
   return L;
}



/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
