/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ENiX_Globals.h"
#include "ENiX_APPLICATIONS.h"
#include "ENiX_NLP.h"
#include "ENiX_DISK.h"
#include "ENiX_STRING.h"
#include "ENiX_CS.h"
#include "ENiX_WMS.h"
#include "ENiX_WMS_COMPAT.h"
#include "ENiX_LIST.h"
#include "ENiX_ANALYSER.h"
#include "ENiX_EXEC.h"
#include "ENiX_CALC.h"


int              ConceptUnderstood;
extern char      *DGateNames[];
extern char      *SGateNames[];

/*! \brief Allows ENiX to run a command.
 *
 */
struct List_Str *RUN_Answer(struct List_Str *WordList,struct List_Str *L){
  char *OS_CMD=NULL;
  FILE *CMD_OUT=NULL;
  if((CMD_OUT=popen(OS_CMD=List2Str(WordList),"r"))){
    ANSWER=Str2List(LoadPipe(CMD_OUT));
    pclose(CMD_OUT);
  }
  else
    if(ThinkOutLoud)
      printf("Error running commands: %s.\n",OS_CMD);
  return L;
}

/*! \brief Explain the logic of the neural network method.
 *
 */
struct List_Str *Reason(struct List_Str *WordList,struct List_Str *L){
  int _=0,A=0,Size[6],OutputSize=0,Pos=0,MaxOrder=0,i=0,C=0,D=0;
  char *Relationship=NULL,*Cache=NULL;
  struct List_Str *Input=NULL,*Alpha=NULL,*Beta=NULL,*Gamma=NULL,*LogicBuffer=NULL,*Explanation=NULL,*Legend=NULL,*Buffer=NULL,*Data=NULL;
  struct Datablock *DB=NULL;
  for(Input=WordList;Input;Input=Input->Next){
    Relationship=Input->Str;
    printf("Concept: [%s]\n",Relationship);
    DB=Goto_DB_Entry(Database[0],Relationship);
    if(DB){
      Alpha=DB->DS[1];
      Beta =DB->DS[2];
      OutputSize=atoi(Get_List_Element(DB->DS[0],3));
      LogicBuffer=Str2List(Get_List_Element(DB->DS[0],7));
      for(A=0;A<OutputSize;A++){
	Explanation=NULL;
	if(Beta){
	  printf("%-05s :IF ",Get_List_Element(Beta,A));
	}
	else{
	  printf("%5d :IF ",A);
	}
	Gamma=LogicBuffer;
	Pos=0;
	while(Gamma){
	  for(_=0;_<6;_++){
	    Size[_]=atoi(Gamma->Str);
	    Gamma=Gamma->Next;
	  }
	  if(Size[0]==A){
	    if(Size[2]==2){
	      Explanation=Ins_List_Element(Explanation,DGateNames[Size[3]],Pos-((1<<Size[1])-1));
	    }
	    else{
	      Explanation=Ins_List_Element(Explanation,SGateNames[Size[3]],Pos-((1<<Size[1])-1));
	    }
	    Pos++;
	  }
	}
	Gamma=LogicBuffer;
	Pos=0;
	MaxOrder=0;
	while(Gamma){
	  for(_=0;_<6;_++){
	    Size[_]=atoi(Gamma->Str);
	    Gamma=Gamma->Next;
	  }
	  if(Size[1]){
	    if((Size[0]==A)&&(Size[1]>MaxOrder)) MaxOrder=Size[1];
	  }
	  else{
	    if(Size[0]==A){
	      if(Alpha){
		if((Cache=Get_List_Element(Alpha,Size[4])))
		  Explanation=Ins_List_Element(Explanation,Cache,Pos);
		else
		  Explanation=Ins_List_Element(Explanation,FloatToString(Size[4]),Pos);
		Pos+=2;
		if((Cache=Get_List_Element(Alpha,Size[5])))
		  Explanation=Ins_List_Element(Explanation,Cache,Pos);
		else
		  Explanation=Ins_List_Element(Explanation,FloatToString(Size[5]),Pos);
		Pos+=2;
	      }
	      else{
		Explanation=Ins_List_Element(Explanation,FloatToString(Size[4]),Pos);
		Pos+=2;
		Explanation=Ins_List_Element(Explanation,FloatToString(Size[5]),Pos);
		Pos+=2;
	      }
	    }
	  }
	}
	Pos=Size_of_List(Explanation);
	for(_=0;_<MaxOrder+1;_++){
	  C=(1<<(_+3))-2;
	  D=(4*((1<<(_+1))-1));
	  for(i=0;i<Pos;i+=C){
	    Explanation=Ins_List_Element(Explanation,"(",i);
	    Explanation=Ins_List_Element(Explanation,")",i+D);
	  }
	}
	if(Explanation){
	  PrintList(Explanation);
	}
      }
      if(DB->DS[1]&&DB->DS[2]){
	Legend=RemoveDups(Ins_List_List(DB->DS[1],DB->DS[2],0));
	for(Buffer=Legend;Buffer;Buffer=Buffer->Next)
	  if(!strncmp(Buffer->Str,"cs",2))
	    if((Data=IntCSRecon(Buffer->Str))){
	      printf("%-7s = ",Buffer->Str);
	      PrintList(Data);
	    }
      }
    }
    puts("");
  }
  return L;
}

/*! \brief Corrects the number sequence to the most complex sentence that makes complete sense.
 *
 */
struct List_Str *Equalizer(struct List_Str *Word_List,struct List_Str *L){
  int Quit=0,Num=0;
  char *Concept=NULL;
  struct List_Str *Instructions=Ins_List_Element(NULL,Concept=Word_List->Str,0),*D=NULL,*Buffer=NULL;
  Num=Size_of_List(Word_List->Next)-1;
  D=Ins_List_Element(Ins_List_Element(D,FloatToString(Num),0),FloatToString(0),0);
  Decision_Maker(Word_List,NULL);
  Buffer=Word_List->Next;
  ANSWER=NULL;
  while(!Quit){
    ODDMAN(NULL,Instructions);
    if(ANSWER){
      if(strcmp(ANSWER->Str,":NULL")){
	Correct(ANSWER,Instructions);
	Decision_Maker(ANSWER,NULL);
	Domain(D,NULL);
	Decide(ANSWER,Instructions);
	Buffer=ANSWER;
      }
      else
	Quit=1;
    }
    Quit=1;
  }
  ANSWER=Buffer;
  return L;
}

/*! \brief Corrects the oddman out in a number sequence.
 *
 */
struct List_Str *CORRECTMAN(struct List_Str *WordList,struct List_Str *L){
  int i=0,Position=0,TPI=0,Complexity=0,Max_Complexity=0;
  char *Concept=NULL,*Buffer=NULL;
  struct List_Str *Values=NULL,*TMP=NULL;
  struct Datablock *DB=Database[0];
  Concept=L->Str;
  L=L->Next;
  if((Position=Find_DB_Entry(Database[0],Concept))<0){
    printf("%s not found. Aborting.\n",Concept);
    return L;
  }
  DB=Goto_DB_Entry(Database[0],Concept);
  Position=1<<atoi(Get_DB_Entry(DB,0,2));
  for(TPI=0;TPI<Position;TPI++)
    Values=Ins_List_Element(Values,FloatToString(TPI),TPI);
  Decide(Values,Ins_List_Element(NULL,Concept,0));
  ANSWER=Ins_List_Element(ANSWER,"scratchpad",0);
  TMP=ANSWER;
  Values=TMP;
  Values=Values->Next;
  i=0;
  Position=0;
  while(Values){
    Buffer=Values->Str;
    Values->Str=":unknown";
    Decision_Maker(TMP,NULL);
    Complexity=atoi(ANSWER->Str);
    if(!i)
      Max_Complexity=Complexity;
    if(Complexity>Max_Complexity){
      Max_Complexity=Complexity;
      Position=i;
    }
    i++;
    Values->Str=Buffer;
    Values=Values->Next;
  }  
  ANSWER=Ins_List_Element(NULL,FloatToString(Position),0); 
  return L;
}

/*! \brief Change number in the example sequence using the neural network.
 *
 */
struct List_Str *Revise(struct List_Str *WordList,struct List_Str *L){
  int Position=0,TPI=0;
  char *Concept=NULL;
  struct List_Str *In=NULL,*Out=NULL,*Values=NULL;
  struct Datablock *DB=Database[0];
  Concept=WordList->Str;
  if((Position=Find_DB_Entry(Database[0],Concept))<0){
    printf("%s not found. Aborting.\n",Concept);
    return L;
  }
  DB=Goto_DB_Entry(Database[0],Concept);
  In=Cpy_List(DB->DS[1]);
  Out=Cpy_List(DB->DS[2]);
  Position=1<<atoi(Get_DB_Entry(DB,0,2));
  for(TPI=0;TPI<Position;TPI++) 
    Values=Ins_List_Element(Values,FloatToString(TPI),TPI);
  Decide(Values,Ins_List_Element(NULL,":ERROR",0));
  Goto_DB_Entry(Database[1],":multiplexor");
  Rep_DB_Entry(DB,0,7,List2Str(ANSWER));
  DB->DS[1]=In;
  DB->DS[2]=Out;
  return L;
}

/*! \brief Use the neural network to decide on words.
 * - Obsolete, included for reference.
 */
struct List_Str *DecideWords(struct List_Str *WordList,struct List_Str *L){
  char *Concept=NULL;
  struct List_Str *Stuff=NULL;
  Concept=L->Str;
  L=L->Next;
  Stuff=Ins_List_Element(Stuff,Concept,0);
  Question(WordList,Stuff);
  Decide(NULL,Stuff);
  Outcome(NULL,Stuff);
  return L;
}

/*! \brief Work out the symbolic outcome of the answer from the neural network.
 * 
 */
struct List_Str *Outcome(struct List_Str *WordList,struct List_Str *L){
  int i=0,Position=0,In=0;
  char *Concept=NULL;
  struct List_Str *Input=NULL,*Out=NULL;
  Input=WordList;
  Concept=L->Str;
  Out=Goto_DB_Entry(Database[1],Concept)->DS[2];
  In=atof(Input->Str); 
  ANSWER=NULL; 
  if(In){
    for(;Out;Out=Out->Next){
      if((In>>i)&1)
	ANSWER=Ins_List_Element(ANSWER,Out->Str,Position++);
      i++;
    }
  }
  else ANSWER=Ins_List_Element(ANSWER,":NULL",0);
  return L->Next;
}

/*! \brief Form a TPI from some words.
 * 
 */
struct List_Str *Question(struct List_Str *WordList,struct List_Str *L){
  int Signal=0;
  char *Concept=NULL;
  struct List_Str *Input=NULL,*In=NULL;
  Input=WordList;
  Concept=L->Str;
  L=L->Next;
  if(!strcmp(Input->Str,":null"))
    ANSWER=Ins_List_Element(NULL,FloatToString(0),0);
  else{
    In=Goto_DB_Entry(Database[1],Concept)->DS[1];
    while(Input){
      Signal|=1<<Find_List_Element(In,Input->Str);
      Input=Input->Next;
    }
    ANSWER=Ins_List_Element(NULL,FloatToString(Signal),0);
  }
  return L;
}

/*! \brief Loads the neural network data into the multiplexor.
 * 
 */
struct List_Str *Multiplex(struct List_Str *L){
  char *Concept=NULL;
  struct Datablock *DB=Database[0];
  struct List_Str *In=NULL,*Out=NULL;
  L=L->Next;
  if(L){
    if(L->Str[0]!=':'){
      Concept=L->Str;
      L=L->Next;
    }
    else{
      puts("Syntax: NULL :CODE B");
      return L;
    }
  }
  else{
    puts("Syntax: NULL :CODE B");
    return L;
  }
  if(!(DB=Goto_DB_Entry(Database[0],":multiplexor"))){
    puts("You need to use this command after :NEW ... :THEN ... :END! Aborting.");
    return L;
  }
  ANSWER=Ins_List_Element(Str2List(Get_DB_Entry(DB,0,7)),Concept,0);
  In=DB->DS[1];
  Out=DB->DS[2];
  if(!(DB=Goto_DB_Entry(Database[0],Concept)))
    DB=Database[0]=Add_DB_Entry(Database[0],Concept);
  DB->DS[1]=In;
  DB->DS[2]=Out;
  return L;
}

/*! \brief Multiplex the word problem into a number sequence for the neural network.
 * 
 */
struct List_Str *ToMultiplex(struct List_Str *WordList, struct List_Str *L){
  int Null_In=0,Null_Out=0,Unknown_Out=0,i=0,Terminated=0,In=0,Out=0,SequenceLength=0;
  struct Datablock *DB=Database[0]; 
  struct List_Str *Situation=NULL,*Outcome=NULL,*BufferOut=NULL,*Multiplex_In,*Multiplex_Out=NULL,*Sequence=NULL;
  L=L->Next;
  if(!(DB=Goto_DB_Entry(Database[0],":multiplexor"))){
    puts("You've forgotten to clear the multiplex datablock. Run :NEW first! Aborting.");
    return L;
  }
  if((WordList)&&(L)){
    Outcome=L; 
    while(Outcome){ 
      if(strcmp(Outcome->Str,":end")==0) 
	Terminated=1; 
      Outcome=Outcome->Next; 
    }
    if(!Terminated){ 
      puts("Syntax: A :THEN B :END"); 
      return L; 
    }
    Outcome=NULL; 
    i=0;
    while(strcmp(L->Str,":end")){ 
      Outcome=Ins_List_Element(Outcome,L->Str,i++); 
      L=L->Next; 
    }
    Situation=WordList;
    Multiplex_In=DB->DS[1];  
    while(Multiplex_In) {  
      In++;  
      Multiplex_In=Multiplex_In->Next;   
    } 
    Multiplex_In=DB->DS[1];
    Multiplex_Out=DB->DS[2]; 
    while(Multiplex_Out){  
      Out++; 
      Multiplex_Out=Multiplex_Out->Next; 
    } 
    Multiplex_Out=DB->DS[2];
    if(!strcmp(Situation->Str,":null"))
      Null_In=1;
    if(!strcmp(Outcome->Str,":null"))
      Null_Out=1;
    if(!strcmp(Outcome->Str,":unknown"))            
      Unknown_Out=1;
    BufferOut=Outcome;
    if(!Null_In)
      while(Situation){
	if(!Is_List_Element(Multiplex_In,Situation->Str))
	  Multiplex_In=Ins_List_Element(Multiplex_In,Situation->Str,In++);
	Situation=Situation->Next; 
      } 
    Situation=WordList;
    if(!Null_Out&&!Unknown_Out)
      while(Outcome){
	if(!Is_List_Element(Multiplex_Out,Outcome->Str))
	  Multiplex_Out=Ins_List_Element(Multiplex_Out,Outcome->Str,Out++);
	Outcome=Outcome->Next;
      }  
    Outcome=BufferOut;
    DB->DS[1]=Multiplex_In; 
    DB->DS[2]=Multiplex_Out; 
    SequenceLength=1<<In; 
    In=0; 
    Out=0;
    while(Situation){ 
      In|=1<<Find_List_Element(Multiplex_In,Situation->Str); 
      Situation=Situation->Next; 
    }
    while(Outcome){ 
      Out|=1<<Find_List_Element(Multiplex_Out,Outcome->Str); 
      Outcome=Outcome->Next;     
    }
    Sequence=Str2List(Get_DB_Entry(DB,0,7)); 
    BufferOut=Sequence; 
    i=0;
    while(BufferOut){ 
      i++; 
      BufferOut=BufferOut->Next; 
    }
    for(;i<SequenceLength;i++) 
      Sequence=Ins_List_Element(Sequence,":unknown",i);
    if(Null_In) 
      In=0; 
    if(Null_Out) 
      Out=0;
    Sequence=Del_List_Element(Sequence,In); 
    if(!Unknown_Out) 
      Sequence=Ins_List_Element(Sequence,FloatToString(Out),In); 
    else
      Sequence=Ins_List_Element(Sequence,":unknown",In);
    Rep_DB_Entry(DB,0,7,List2Str(Sequence)); 
  } 
  else 
    puts("Syntax: A :THEN B :END"); 
  return L;
}

/*! \brief Erase the contents of the ENiX multiplexor.
 * 
 */
struct List_Str *ClearMultiplexor(struct List_Str *L){
  struct Datablock *DB=Database[0];
  L=L->Next;
  if(!(DB=Goto_DB_Entry(Database[1],":multiplexor"))){
    DB=Database[0]=Add_DB_Entry(Database[0],":multiplexor");
  }
  else{
    Rep_DB_Entry(DB,0,7,":unknown");
    DB->DS[1]=NULL;
    DB->DS[2]=NULL;
  }
  return L;
}

/*! \brief Use ENiX neural network to change a sequence so that the neurals understanding is the desired level.
 *  - Used for debugging.
 */   
struct List_Str *Nicefy(struct List_Str *Word_List,struct List_Str *L){
  int Seed=0,Comprehension_Lvl=atoi(L->Str),PriorComp,Min=-1,Max=0,Term=0,Length=0,Pos,_=0;
  struct List_Str *Buffer=Ins_List_Element(Word_List,"NICEFY",0),*Buffer2=NULL,*CMD=NULL,*Domain=NULL;
  struct Datablock *DB=NULL;
  DB=GetLang();
  if(DB){
    Decision_Maker(Buffer2=Buffer,NULL);
    Understand(NULL,CMD=Ins_List_Element(NULL,"NICEFY",0));
    PriorComp=atoi(ANSWER->Str);
    if((Pos=Find_List_Element(DB->DS[1],":randseed"))+1)
      Seed=atoi(Get_DB_Entry(DB,2,Pos));
    else Seed=14451;
    srand(Seed);
    for(Buffer=Buffer2->Next;Buffer;Buffer=Buffer->Next){
      Term=atoi(Buffer->Str);
      if(Term>Max)              Max=Term;
      if((Min==-1)||(Term<Min)) Min=Term;
      Domain=Ins_List_Element(Domain,FloatToString(_),_);
      _++;
    }   
    Buffer=Buffer2;
    Length=Size_of_List(Buffer)-1;
    while(PriorComp!=Comprehension_Lvl){
      if(PriorComp>Comprehension_Lvl){
	Pos=(rand()%Length)+1;
	Term=((Seed=rand())%(Max-Min))+Min;
	Buffer=Del_List_Element(Buffer,Pos);
	Buffer=Ins_List_Element(Buffer,FloatToString(Term),Pos);
	printf(" - "); PrintList(Buffer);
      }
      else{
	ODDMAN(NULL,CMD);
	Correct(ANSWER,CMD);
	Decision_Maker(ANSWER,NULL);
	Decide(Domain,CMD);
	Buffer=Ins_List_Element(ANSWER,"NICEFY",0);
	printf(" + "); PrintList(Buffer);
      }
      Decision_Maker(Buffer,NULL);
      Understand(NULL,CMD);
      PriorComp=atoi(ANSWER->Str);
    }
    ANSWER=Buffer->Next;
    Rep_DB_Pair(DB,":randseed",FloatToString(Seed));
  }
  else
    puts("Language not setup!");
  return L->Next;
}

/*! \brief Use matrix t-transformations on the boolean data an learn the problem in two different dimensions.
 *  
 */   
struct List_Str  *Orthogonal(struct List_Str *Word_List,struct List_Str *L){
  /* Needs to be a failsafe to kick in and terminate this heuristic if convergence ceases */
   int Prev=0,Quit=0,Size=Size_of_List(Word_List)-1;
   struct List_Str *Buffer=Word_List,*CMD=Ins_List_Element(NULL,"interntest",0),*ToCompute;
   Domain(Ins_List_Element(Ins_List_Element(NULL,"0",0),FloatToString(Size),1),NULL);
   ToCompute=ANSWER;
   while(!Quit){
      Buffer=Ins_List_Element(Buffer,"interntest",0);
      Decision_Maker(Buffer,NULL);
      Understand(NULL,CMD);
      Buffer=Del_List_Element(Buffer,0);
      if(atoi(ANSWER->Str)!=2){
	 Prev=0;
	 printf("FIX:       "); PrintList(Buffer);
	 ODDMAN(NULL,CMD);
	 Correct(ANSWER,CMD);
	 Decision_Maker(ANSWER,NULL);
	 Decide(ToCompute,CMD);
	 Buffer=ANSWER;
      }
      else{
	 printf("OK:        "); PrintList(Buffer);
	 if(Prev)
	   Quit=1;
	 else{
	    printf("Transform: "); PrintList(Buffer);
	    Prev=1;
	    T_Transform(Buffer,NULL);
	    Buffer=ANSWER;
	 }
      }
   }
   printf("Sequence orthognolly understood: "); PrintList(Buffer);
   ANSWER=Del_List_Element(Buffer,0);
   return L;
}

/*! \brief Create a new problem.
 *  
 */   
struct List_Str *New(struct List_Str *Word_List,struct List_Str *L){
   return ClearMultiplexor(Ins_List_Element(L,":ERROR",0));
}

/*! \brief Multiplexes L.
 *  
 */   
struct List_Str *Relationship(struct List_Str *Word_List,struct List_Str *L){
   return Multiplex(L);
}

/*! \brief Present the question in a way that the neural network understands.
 *  
 */   
struct List_Str *Wrap_Q(struct List_Str *PV,struct List_Str *PN){
  char *Verb=NULL;
  struct List_Str *Buffer=NULL,*Buffer2=NULL;
  puts("I can't remember. Thinking...");
  Think2(Ins_List_Element(NULL,Verb=GetCSRec(PV)->DS[0]->Str,0),NULL); 
  Buffer=ExtractArticles(PN,FILTERNOUNSONLY);
  Execute                                                       ( NULL,
   Buffer2=Ins_List_List                                        (
    Ins_List_Element                                            (
     Ins_List_Element                                           (
      Ins_List_Element                                          (
       Ins_List_Element                                         (
        Ins_List_Element                                        (
         Ins_List_Element                                       (NULL,":encode",   0)
	                                                             ,Verb,        1)
	                                                             ,":calculate",2)
                                                                     ,Verb,        3)
                                                                     ,":decode",   4)
                                                                     ,Verb,        5)
                                                                     ,Buffer,      0));
  return                                                         ANSWER;
}

/*! \brief Runs the ENiX neural network on word data.
 *  
 */   
struct List_Str *Think2(struct List_Str *Word_List,struct List_Str *L){ /* incomplete: need to think our way round the null problem */
   int _=0;
   char *Concept=NULL,*Alpha=NULL;
   struct List_Str *Input=NULL,*DS2=NULL,*DS3=NULL,*B1=NULL,*B2=NULL,*DEFAULT=NULL,*B=NULL,*Deref=NULL;
   struct Datablock *DB=NULL;
   Input=Word_List;
   while(Input){
      Alpha=Input->Str;
      if(isdigit(Alpha[0])){
	 Concept=(char *)malloc((_=(StrLen(Alpha)+3))*sizeof(char));
	 snprintf(Concept,_,"cs%s",Alpha);
      }
      else Concept=Alpha;
      DB=Goto_DB_Entry(Database[1],Concept);
      DS2=DB->DS[1];
      DS3=DB->DS[2];
      DEFAULT=Ins_List_Element(NULL,":null",0);
      ClearMultiplexor(DEFAULT);
      while(DS2){
	Deref=IntCSRecon(DS2->Str);
	 /* need to put in the :setnull extraction mechanism here. */
	 if(AreAnyGAttributes(":setnull",Deref))
	   B1=Ins_List_Element(NULL,":null",0);
	 else
	   B1=ExtractArticles(Deref,"noun pronoun propernoun");
	 /* need to put in the :setnull extraction mechanism here. */
	 if(AreAnyGAttributes(":setnull",B=Str2List(DS3->Str)))
	   B2=Ins_List_Element(NULL,":null",0);
	 else
	   B2=ExtractArticles(B,"noun pronoun propernoun");
	 if(B1&&B2)
	   Execute(NULL,Ins_List_List(Ins_List_Element(Ins_List_List(Ins_List_Element(NULL,":end",0),B2,0),":then",0),B1,0));
	 DS2=DS2->Next;
	 DS3=DS3->Next;
      }  
      Execute(NULL,Ins_List_Element(Ins_List_Element(Ins_List_Element(NULL,":learn",0),Concept,0),":relationship",0));
      ANSWER=NULL;
      Execute(NULL,Ins_List_Element(Ins_List_Element(NULL,":understand",0),Concept,1));
      if(strncmp(ANSWER->Str,"1.0",3)){ ConceptUnderstood=0; /*puts("I don't understand!");*/ }
      else                            { ConceptUnderstood=1; /*puts("I understand!");*/ }
      Input=Input->Next;
   }
   return L;
}

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
