#include <ncurses.h>

void PrintText(char *Text,int X,int Y);
void ColourText(char *Text,int X,int Y,int colour_pair);

void PrintText(char *Text,int X,int Y){
  move(Y,X);
  printw(Text);
}

void ColourText(char *Text,int X,int Y,int colour_pair){
  attron(COLOR_PAIR(1));
  PrintText(Text,X,Y);
  attroff(COLOR_PAIR(1));
}

int main()
{
  initscr();/* Start curses mode   */
  start_color();
  init_pair(1, COLOR_BLACK, COLOR_RED);

  ColourText("Test 1",10,10,1);
  refresh();/* Print it on to the real screen */
  getch();/* Wait for user input */
  endwin();/* End curses mode  */

  return 0;
}
