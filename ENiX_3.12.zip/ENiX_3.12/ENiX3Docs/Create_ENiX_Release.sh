#!/bin/bash
# GPL [OvO]wl 2015, saving time.

VERSION="ENiX_3.11"
BUILDAREA="/home/martyn/DEV/deleteme/"
SVNREPO="file:///var/svn/repos/ENiX/src"

function Debug_Settings {
    echo "Version number: ${VERSION}"
    echo "Build area....: ${BUILDAREA}"
    echo "SVN Repository: ${SVNREPO}"
}

function Release_ENiX {
    mkdir -p "${BUILDAREA}"
    cd "${BUILDAREA}"
    rm -rf "${VERSION}"*
    svn export "${SVNREPO}" "${VERSION}"
    cd "${VERSION}"
    touch configure.ac aclocal.m4 configure Makefile.am Makefile.in
    cd ..
    tar -cf "${VERSION}.tar" "${VERSION}" 
    gzip "${VERSION}.tar"
}

function Validate_Release {
    echo ""
    if [ -f "${VERSION}.tar.gz" ]
    then
	echo "New release location: ${BUILDAREA}${VERSION}.tar.gz :)"
    else
	echo "ERROR: Could not create release :("
    fi
    echo ""
}

Debug_Settings
Release_ENiX
Validate_Release
