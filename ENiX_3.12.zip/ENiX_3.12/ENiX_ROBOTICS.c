/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include "ENiX_STRING.h"
#include "ENiX_LIST.h"
#include "ENiX_WMS.h"
#include "ENiX_ROBOTICS.h"

struct termios RoboticsOptions;

/*! \brief Write data to the serial port.
 *
 */
int SerialWrite(int FileDesc,char *String){
  int Length=strlen(String);
  int Written=write(FileDesc,String,Length);
  if(Written!=Length) 
    return -1;
  return 0;
}

/*! \brief Set up the serial port coms.
 *
 */
struct List_Str *SetSerial(struct List_Str *Word_List,struct List_Str *L){
  char *PortName=L->Str;
  struct List_Str *Qualifiers=NULL;
  struct Datablock *DB=NULL;
  Qualifiers=Str2List(":DEVICE :ISPEED :OSPEED :CFLAG :IFLAG :LFLAG :OFLAG :VMIN :VTIME");
  if(Size_of_List(Qualifiers)==Size_of_List(Word_List)){
    if(!(DB=Goto_DB_Entry(Database[1],PortName)))
      DB=Database[1]=Add_DB_Entry(Database[1],PortName);
    DB->DS[1]=Qualifiers;
    DB->DS[2]=Word_List;
  }
  else
    printf("ERROR: %s:%d (%s) Incorrect number of parameters.\n",__FILE__,__LINE__,__func__);
  return L->Next;
}

/*! \brief Read from the serial port.
 *
 */
char *SerialRead(int FileDesc,unsigned long int Wait){
  char Character=0,*Buffer=NULL;
  int _=0,Read=0;
  unsigned long int Expired=0;
  Buffer=(char *)malloc(sizeof(char ));
  Buffer[0]='\0';
  do{
    if(Wait!=-1){
      if(Wait){
	if(Expired>Wait)
	  return NULL;
      }
      else
	return NULL;
    }
    Read=read(FileDesc,&Character,1);
    if(Read==-1)
      return NULL;
    if(Read==0){
      usleep(10000);
      Expired+=10000;
      continue;
    }
    Buffer=(char *)realloc(Buffer,(_+1)*sizeof(char ));
    Buffer[_++]=Character;
  } while(Character!='\n');
  Buffer[_]=0;
  return Buffer;
}

/*! \brief Open the serial port connection.
 *
 */
int SerialOpen(char *ENiXDevice){
  int FileDesc=0;
  char *Device=NULL;
  struct Datablock *DB=NULL;
  if(!(DB=Goto_DB_Entry(Database[1],ENiXDevice)))
    return -1;
  Device=Lookup_DB_Attr(DB,":DEVICE",NULL);
  if((FileDesc=open(Device,O_RDWR|O_NOCTTY|O_NDELAY))==-1)
    printf("ENiX unable to open %s\n",Device);
  else{
    printf("ENiX, %s opened.\n",Device);
    fcntl(FileDesc, F_SETFL, 0);
    if(tcgetattr(FileDesc, &RoboticsOptions)<0)
      puts("ENiX Robotics: Unable to get serial connection data.");
    cfsetispeed(&RoboticsOptions,atoi(Lookup_DB_Attr(DB,":ISPEED",NULL)));
    cfsetospeed(&RoboticsOptions,atoi(Lookup_DB_Attr(DB,":OSPEED",NULL)));
    RoboticsOptions.c_cflag=atoi(Lookup_DB_Attr(DB,":CFLAG",NULL));
    RoboticsOptions.c_iflag=atoi(Lookup_DB_Attr(DB,":IFLAG",NULL));
    RoboticsOptions.c_lflag=atoi(Lookup_DB_Attr(DB,":LFLAG",NULL));
    RoboticsOptions.c_oflag=atoi(Lookup_DB_Attr(DB,":OFLAG",NULL));
    RoboticsOptions.c_cc[VMIN]=atoi(Lookup_DB_Attr(DB,":VMIN",NULL));
    RoboticsOptions.c_cc[VTIME]=atoi(Lookup_DB_Attr(DB,":VTIME",NULL));
    if(tcsetattr(FileDesc,TCSANOW,&RoboticsOptions)<0)
      puts("ENiX Robotics: Unable to set serial connection data.");
  }
  return FileDesc;
}

/*! \brief Close the serial port connection.
 *
 */
void SerialClose(int FileDesc){
  puts("ENiX, serial port closed.");
  close(FileDesc);
}

/*! \brief Perform a serial port test.
 *
 */
struct List_Str *SerialTest(struct List_Str *Word_List,struct List_Str *L){
  int FileDesc=0,Read=0,Written=0,Prev=0;
  char Character='\0',*Buffer=NULL;
  FileDesc=SerialOpen(L->Str);
  if(FileDesc==-1)
    return L->Next;
  Buffer=StrCat(List2Str(Word_List),"\n");
  while(1){
    Read=read(FileDesc,&Character,1);    
    if(Read==1){
      if(Prev!=Read)
	printf("Received: ");
      printf("%c",Character);
    }
    else{
      Written=SerialWrite(FileDesc, Buffer);
      printf("Sent: %s",Buffer);
      if(Written==-1)
	return L->Next;
      sleep(1);
    }
    Prev=Read;
  }  
  SerialClose(FileDesc);
  return L->Next;
}

/*! \brief Send data to the serial port.
 *
 */
struct List_Str *SerialSend(struct List_Str *Word_List,struct List_Str *L){
  int FileDesc=0;
  char *Buffer=NULL,*Freeable=NULL;
  FileDesc=SerialOpen(L->Str);
  if(FileDesc==-1)
    return L->Next;
  sleep(1);
  SerialWrite(FileDesc,"INIT\n");
  sleep(1);
  Buffer=StrCat(Freeable=List2Str(Word_List),"\n");
  SerialWrite(FileDesc,Buffer);
  printf("Sent: %s",Buffer);
  SerialClose(FileDesc);
  /*
  free(Buffer);
  free(Freeable);
  */
  return L->Next;
}

/*! \brief Receive data from the serial port.
 *
 */
struct List_Str *SerialRecv(struct List_Str *Word_List,struct List_Str *L){
  int FileDesc=0;
  FileDesc=SerialOpen(L->Str);
  if(FileDesc==-1)
    return L->Next;
  puts("Waiting for data...");
  ANSWER=Str2List(SerialRead(FileDesc,-1));
  printf("Received: ");
  PrintList(ANSWER);
  SerialClose(FileDesc);
  return L->Next;  
}

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
