/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <string.h>
#include "ENiX_Globals.h"
#include "ENiX_STRING.h"
#include "ENiX_LIST.h"
#include "ENiX_WMS.h"
#include "ENiX_SETTHEORY.h"
#include "ENiX_SCOPE.h"

/*! \brief Lists scope resolutions.
 *
 */
struct List_Str  *LstScope(struct List_Str *Word_List,struct List_Str *L){
   struct List_Str *ResolutionList=NULL;
   ANSWER=NULL;
   for(ResolutionList=Goto_DB_Entry(Database[1],":scoperesolution")->DS[1];ResolutionList;ResolutionList=ResolutionList->Next)
     ANSWER=Ins_List_Element(ANSWER,StrFirst(ResolutionList->Str+1,-5),0);
   return L;
}

/*! \brief Lists the current scope resolution.
 *
 */
struct List_Str  *ShwScope(struct List_Str *Word_List,struct List_Str *L){
   ANSWER=Ins_List_Element(NULL,StrFirst(Get_DB_Entry(Goto_DB_Entry(Database[1],":scoperesolution"),0,7)+1,-5),0);
   return L;
}

/*! \brief Set the current scope resolution.
 *
 */
struct List_Str  *SetScope(struct List_Str *Word_List,struct List_Str *L){
   int _=0,OldScopePos=0,NewScopePos=0;
   char *OldScope=NULL,*NewScope=NULL,*RecData=NULL;
   struct List_Str *Old_Symbols=NULL,*New_Symbols=NULL,*Buffer=NULL,*AffectedSymbols=NULL;
   struct Datablock *ScopeRoot=NULL,*Q=NULL;

   /* Get the name of the new scope resolution */
   NewScope=StrCat(":",StrCat(L->Str,"scope"));
   OldScope=Get_DB_Entry(ScopeRoot=Goto_DB_Entry(Database[1],":scoperesolution"),0,7);
   L=L->Next;
   
   /* Get the symbols of the scope resolutions involved */
   if((NewScopePos=Find_List_Element(ScopeRoot->DS[1],NewScope))+1){
      RecData=Get_List_Element(ScopeRoot->DS[2],0);
      if(strcmp(RecData,"?"))
	 New_Symbols=Str2List(RecData);
   }
   else if(ThinkOutLoud) puts("Scope does not exist!");
   if((OldScopePos=Find_List_Element(ScopeRoot->DS[1],OldScope))+1){
      RecData=Get_List_Element(ScopeRoot->DS[2],OldScopePos);
      if(strcmp(RecData,"?"))
	Old_Symbols=Str2List(RecData);
   }
   else if(ThinkOutLoud) puts("Scope does not exist!");
   
   /* Register the new scope resolution deregister the old */
   Rep_DB_Entry(ScopeRoot,0,7,NewScope);
   
   /* Need to find the symbols used in L in the new scope resolution */
   for(Buffer=L;Buffer;Buffer=Buffer->Next)
     if(Buffer->Str[0]!=':')
       AffectedSymbols=Ins_List_Element(AffectedSymbols,Buffer->Str,0);
   
   /* Need to add these new symbols to the old symbols in the new scope resolution */
   for(Buffer=AffectedSymbols;Buffer;Buffer=Buffer->Next)
     New_Symbols=Add2Set(New_Symbols,Buffer->Str);
   if(New_Symbols)
     Rep_DB_Entry(ScopeRoot,2,NewScopePos,List2Str(New_Symbols));
   else
     Rep_DB_Entry(ScopeRoot,2,NewScopePos,"?");
   
   /* Need to locate and backup the old symbols */
   for(Buffer=Old_Symbols;Buffer;Buffer=Buffer->Next){
      Q=Goto_DB_Entry(Database[1],Buffer->Str);
      if(strcmp(RecData=Get_DB_Entry(Q,0,7),"?"))
	Rep_DB_Pair(Q,OldScope,RecData);
      else
	Rep_DB_Pair(Q,OldScope,"?");
   }
   
   /* Need to locate and copy the new scope resolution data into current scope */
   for(Buffer=New_Symbols;Buffer;Buffer=Buffer->Next){
      Q=Goto_DB_Entry(Database[1],Buffer->Str);
      if((_=Find_List_Element(Q->DS[1],NewScope))+1)
	Rep_DB_Entry(Q,0,7,Get_DB_Entry(Q,2,_));
      else
	Rep_DB_Entry(Q,0,7,"?");
   } 
   return L;
}

/*! \brief Create a duplicate scope resolution.
 *
 */
struct List_Str *CpyScope(struct List_Str *Word_List,struct List_Str *L){
   int _=0;
   char *From=NULL,*OldMeanings=NULL,*FromSymbols=NULL,*ThisScopeRes=NULL;
   struct List_Str *Buffer=NULL,*Input=NULL,*Buffer2=NULL;
   struct Datablock *Q=Goto_DB_Entry(Database[1],":scoperesolution"),*DB=NULL;
   
   ThisScopeRes=Get_DB_Entry(Q,0,7);
   
   /* Need to convert from symbols to scope resolutions :...scope */
   From=StrCat(":",StrCat(L->Str,"scope"));
   L=L->Next;
   for(;Word_List;Word_List=Word_List->Next)
      Input=Ins_List_Element(Input,StrCat(":",StrCat(Word_List->Str,"scope")),0);

   /* check that the scope resolution being copied from exists */
   if((_=Find_List_Element(Q->DS[1],From))+1)
      FromSymbols=Get_DB_Entry(Q,2,_);
   else if(ThinkOutLoud) printf("Scope resolution, %s does not exist.\n",From);

   /* copy data from FromSymbols to other scope resolution */
   for(Buffer=Input;Buffer;Buffer=Buffer->Next){
      if((_=Find_List_Element(Q->DS[1],Buffer->Str))+1)
	 Rep_DB_Entry(Q,2,_,FromSymbols);
      else if(ThinkOutLoud) printf("Scope resolution %s not found.\n",Buffer->Str);
   }
   
   /* go through all the symbols copying the scope resolution data from old scope into new */
   
   /* for each symbol */
   for(Buffer2=Str2List(FromSymbols);Buffer2;Buffer2=Buffer2->Next){
      DB=Goto_DB_Entry(Database[1],Buffer2->Str);
      
      /* if there is a from */
      if((_=Find_List_Element(DB->DS[1],From))+1)
	OldMeanings=Get_DB_Entry(DB,2,_);
      else{
	 if(!strcmp(Get_DB_Entry(Q,0,7),From))
	   OldMeanings=Get_DB_Entry(DB,0,7);
	 else{
	    if(ThinkOutLoud)
	      printf("%s does not exist in scope resolution %s.\n",Buffer2->Str,From);
	    OldMeanings=NULL;
	 }
      }
      
      /* for each target scope resolution */
      if(OldMeanings)
	for(Buffer=Input;Buffer;Buffer=Buffer->Next){
	  /* if the target scope resolution is the same as the current resolution. */
	   if(!strcmp(ThisScopeRes,Buffer->Str)){
	      Rep_DB_Entry(DB,0,7,OldMeanings);
	   }
	   else{
	      if((_=Find_List_Element(DB->DS[1],Buffer->Str))+1)
		Rep_DB_Entry(DB,2,_,OldMeanings);
	      else
		 Rep_DB_Pair(DB,Buffer->Str,OldMeanings);
	   }
	}
   }
   return L;
}


/*! \brief Delete a scope resolution.
 *
 */
struct List_Str *DelScope(struct List_Str *Word_List,struct List_Str *L){
   int _=0;
   char *StrData=NULL,*SymbolStr=NULL;
   struct List_Str *Symbols=NULL;
   struct Datablock *Q=Goto_DB_Entry(Database[1],":scoperesolution"),*Record=NULL;
   for(;Word_List;Word_List=Word_List->Next){

     /* need to enter into each object and delete its references to the scope resolution */
      if(!strcmp("global",Word_List->Str)) return L;
      if(!strcmp("local",Word_List->Str))  return L;
      StrData=StrCat(":",StrCat(Word_List->Str,"scope"));
      if((_=Find_List_Element(Q->DS[1],StrData))+1){
	 Symbols=NULL;
	 if(strcmp(SymbolStr=Get_DB_Entry(Q,2,_),"?"))
	    Symbols=Str2List(SymbolStr);
	 	 
     	 /* Need to remove the scope resolution */
	 Q->DS[1]=Del_List_Element(Q->DS[1],_);
	 Q->DS[2]=Del_List_Element(Q->DS[2],_);
	 
	 /* Need to see if the scope resolution is currently active if it is change it to global */
	 if(!strcmp(Get_DB_Entry(Q,0,7),StrData))
	   Rep_DB_Entry(Q,0,7,":globalscope");
	 
      }
      else if(ThinkOutLoud) puts("Scope does not exist!");
      
      for(;Symbols;Symbols=Symbols->Next){
	 Record=Goto_DB_Entry(Database[1],Symbols->Str);
	 if((_=Find_List_Element(Record->DS[1],StrData))+1){
	    Q->DS[1]=Del_List_Element(Q->DS[1],_);
	    Q->DS[2]=Del_List_Element(Q->DS[2],_);
	 }
      }
      
   }
   return L;
}

/*! \brief Add a scope resolution.
 *
 */
struct List_Str *AddScope(struct List_Str *Word_List,struct List_Str *L){
   struct Datablock *Q=Goto_DB_Entry(Database[1],":scoperesolution");
   for(;Word_List;Word_List=Word_List->Next)
      Rep_DB_Pair(Q,StrCat(":",StrCat(Word_List->Str,"scope")),"?");
   return L;
}

/*! \brief Enter into a scope resolution.
 *
 */
struct Datablock *StartScopeResolution(struct Datablock *DB,struct List_Str *Word_List){
   struct Datablock *OLD=NULL;
   for(;Word_List;Word_List=Word_List->Next){
      DB=Add_DB_Entry(DB,Word_List->Str);
      OLD=Goto_DB_Entry(Database[1],Word_List->Str);
      Rep_DB_Entry(DB,0,7,Get_DB_Entry(OLD,0,7));
      Rep_DB_Entry(OLD,0,7,"?");
   }
   return DB;
}

/*! \brief Exit from a scope resolution.
 *
 */
void CloseScopeResolution(struct Datablock *DB){
   struct Datablock *NEW=NULL;
   for(;DB;DB=DB->Next){
      NEW=Goto_DB_Entry(Database[1],Get_DB_Entry(DB,0,0));
      Rep_DB_Entry(NEW,0,7,Get_DB_Entry(DB,0,7));
   }
}



/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
