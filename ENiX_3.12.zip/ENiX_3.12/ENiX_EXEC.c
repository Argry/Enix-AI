/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ENiX_EXEC.h"
#include "ENiX_DISK.h"
#include "ENiX_CONV.h"
#include "ENiX_NLP.h"
#include "ENiX_WMS.h"
#include "ENiX_LIST.h"
#include "ENiX_WMS_COMPAT.h"
#include "ENiX_STRING.h"
#include "ENiX_Globals.h"

int              Translation_Bypass;

int              NumberofTerminations=2;
char             *TerminatedCommands[]={":foreach",":if"};

char             *Command_List[]={
  ":aavf",":add",":addemo",":addemodebug",":addscope",":addwref",":all",":allrels",":and",":answer",":append",":apvf",
  ":argue",":assignemo",":assimilate",":auxverbs",":borg",":calculate",":chocky",":clremodebug",":cmd",
  ":context",":convbuf",":correct",":cpyscope",":creategraph",":cs2sentence",":csaddr",":csdebug",":csload",":csrecon",
  ":cssave",
  ":debug",":debugaware",":debugcond",":debugreason",":dec",":decide",":decode",":define",":definition",":delete",":delscope",
  ":described",":deyoda",":div",
  ":do",":domain",":element",":emo2vec",":emodebug",":emodebugvec",":emofinds",":emomapper",":emotion",":emotionlist",
  ":empathyinj",
  ":empathypost",":empathypre",":encode",":end",":endpunct",":equalizer",":equivalence",":example",
  ":except",":exp",":express",":false",":first",":firstafter",":firstbefore",":force",":foreach",":forget",
  ":getemodebug",":getgraph",
  ":grammar",":graphs",":greater",":groupset",":groupshow",":help",":hook",":how",":if",":impevent",":infoevent",
  ":intersection",
  ":language",":languagedebug",":last",":lastafter",":lastbefore",":learn",":like",":limits",":listbytopic",
  ":listcsvalues",
  ":listsentences",":load",":locklang",":lstcomb",":lstscope",":map",":math",":meld",
  ":meldvf",":memory",":merge",":mode",":mul",":music",":mutate",":nand",":new",":nicefy",":nlpawrap",
  ":nlpcwrap",":nor",":not",":nouns",":null",":oddman",":or",":orthogonal",":otherwise",":pattern",
  ":personality",":phrase",":popemodebug",":ppronouns",":predverbs",":prepend",":pronouns",":purge",
  ":purpose",":qualify",":quote",":random",":randseed",":read",":reason",":recall",":recollect",":relationship",
  ":reverse",":revise",":route",":run",":save",":saveset",":savf",":scheddel",":schednew",":scheduler",":sempath",
  ":sentenceassign",":sentencecbase",":sentencecmood",":sentencectense",":sentencedebug",":sentenceemo",
  ":sentenceexp",":sentencetense",":sentenceunit",":sentiency",":serialrecv",":serialsend",":serialtest",
  ":setbias",":setcondcause",":setcondeffect",":setemomode",":setgender",":setmood",":setnull",":setpassive",":setquestion",":setscope",
  ":setserial",":setwh",":setyn",":shortpath",":showprof",":shrink",":shwscope",":signal",":similar",
  ":size",":sleep",":smaller",":smvf",":spa",":spath",":split",":spvf",":statistics",":stemadd",
  ":stembase",":stemclass",":stemfind",":stemmeld",":stemshow",":store",":study",":sub",":subj",
  ":subset",":systemmood",":swap",":tense",":tenses",":test",":then",":think",":thinkb",":tol",":topic",":translate",
  ":treegenerate",":true",":ttransform",":understand",":union",":unknown",":unstore",":unwrap",
  ":vec2emo",":verbosity",":verbpostproc",":verbtableadd",":version",":wait",":whqevent",":wrap",":xor",":ynqevent"
};

char             *Command_Info[]={
   "A    :AAVF          B    Language,    saves active verb forms type A to verb layout B.",
   "A    :ADD           B    Mathematics, adds value of A to the value of B and saves the result in :ANSWER.",
   "A    :ADDEMO        NULL Emotion,     adds emotions A to the :EMOTION attribute in language",
   "A    :ADDEMODEBUG   B    Emotion,     adds emotions A to the record B",
   "A    :ADDSCOPE      NULL Control,     create new scope(s) A.",
   "A    :ADDWREF       B    Language,    adds verb reference(s) in A refering to base verb B.",
   "NULL :ALL           NULL Set Theory,  saves to :ANSWER, a complete list of names of all data concepts in memory.",
   "NULL :ALLRELS       NULL Set Theory,  saves to :ANSWER, a complete list of names of all relationships in memory.",
   "A    :AND           B    Logic,       saves 1 into :ANSWER if both A and B are non-zero.",
   "A    :ANSWER        NULL Interface,   displays the contents of :ANSWER.",
   "A    :APPEND        B    Set Theory,  appends the contents of A to the end of list B and saves as :ANSWER.",
   "A    :APVF          B    Language,    saves passive verb forms type A to verb layout B.",
   "A    :ARGUE         NULL Language,    if A is ON or OFF sets arguing to on or off respectively.",
   "NULL :ASSIGNEMO     NULL High-Level,  associate smilies B to language.",
   "A    :ASSIMILATE    NULL Control,     run data A through OS.",
   "A    :AUXVERBS      NULL Language,    sets auxilliary verbs to A.",
   "A    :BORG          NULL High-Level,  Assimilates ideas based on A into a single concept.",
   
   "A    :CALCULATE     B    High-Level,  retrieve concept B and evaluate at scenerio A.",
   "A    :CHOCKY        NULL Control,     parse A through the Chocky interpretter.",
   "A    :CLREMODEBUG   NULL Emotion,     Clears emotion concept(s) A.",
   "NULL :CMD           NULL Control,     disables NLP for the duration of the command.",
   "A    :CONTEXT       NULL High-Level,  sets conversation context name.",
   "NULL :CONVBUF       NULL Language,    display the conversation buffer to stdout.",
   "A    :CORRECT       B    High-Level,  correct B using data A.",
   "A    :CPYSCOPE      B    Control,     copy scope B contents to all scopes A.",
   "A    :CREATEGRAPH   B    Language,    construct a graph template called B using tokens S,PV,PN in A.",
   "A    :CS2SENTENCE   NULL Language,    converts the CS values in A to sentences and outputs as ANSWER.",
   "A    :CSADDR        NULL Interface,   saves the record id in ANSWER from context A",
   "A    :CSDEBUG       NULL Interface,   retrieves DB entry addressed by context A.",
   "A    :CSLOAD        NULL Language,    saves the instructions at address A to :ANSWER.",
   "A    :CSRECON       NULL Language,    reconstruct an address from a record A.",
   "A    :CSSAVE        [B]  Language,    create a record at address A.",

   "[A]  :DEBUG         NULL Interface,   if A exists the display all of it, else display memory contents.",
   "NULL :DEBUGAWARE    B    High-Level,  displays awareness equalisation matrix.",
   "A    :DEBUGCOND     NULL Language,    debug conditional sentences.",
   "A    :DEBUGREASON   NULL Language,    debug reasoning.",
   "NULL :DEC           NULL Emotion,     displays the contents of the emotion cache.",   
   "A    :DECIDE        B    High-Level,  run pattern B at points A and save result to :ANSWER.",
   "-    :DECODE        -    High-Level,  -",
   "A    :DEFINE        NULL Control,     defines A as being all items after :DEFINE.",
   "NULL :DEFINITION    NULL Interface,   explains what all items are after :DEFINITION.",
   "A    :DELETE        NULL Control,     delete each of A from memory.",
   "A    :DELSCOPE      NULL Control,     delete scope resolution A.",
   "[A]  :DESCRIBED     B    Set Theory,  saves the concepts in A described by B in :ANSWER.",
   "A    :DEYODA        NULL Language,    decyphers the sentence A and finds one that makes sense.",
   "A    :DIV           B    Mathematics, divides A by B and saves result in :ANSWER.",
   "A    :DO            B    Control,     execute B while condition A applies.",
   "A    :DOMAIN        NULL Set Theory,  create a set between the first two variates in A and save to :ANSWER.",

   "A    :ELEMENT       B    Set Theory,  if elements A are elements of B then store 1 else 0 into :ANSWER.",   
   "A    :EMO2VEC       NULL Emotion,     converts an emotion name, A, into a vector, :ANSWER.",
   "A    :EMODEBUG      NULL Emotion,     displays :emodebug record.",
   "A    :EMODEBUGVEC   NULL Emotion,     decodes an emotion vector into labelled components.",
   "A    :EMOFINDS      B    High-Level,  save a CSNUM list of sentences, A that match emotion, B to :ANSWER.",
   "NULL :EMOMAPPER     NULL Emotion,     updates the systems emotion based on recent events.",
   "A    :EMOTION       B    Control,     specify A's emotion category as B.",
   "NULL :EMOTIONLIST   NULL Emotion,     save a list of emotions in ENiX to :ANSWER.",
   "A    :EMPATHYINJ    NULL High-Level,  injects data into emotion buffer.",
   "NULL :EMPATHYPOST   NULL High-Level,  Processes emotion buffer.",
   "A    :EMPATHYPRE    NULL High-Level,  empathise sentence A with user saves to emotion buffer.",
   "-    :ENCODE        -    High-Level,  -",
   "NULL :END           NULL Control,     terminate the control sequence.",
   "A    :ENDPUNCT      NULL Control,     Sets A as end punctuation.",
   "A    :EQUALIZER     NULL High-Level,  equalizes problem A, saving the data to :ANSWER.",
   "A    :EQUIVALENCE   B    Logic,       if A equals B then store 1 as :ANSWER else store 0.",
   "NULL :EXAMPLE       [B]  Control,     shows usage example for commands B.",
   "A    :EXCEPT        B    Set Theory,  saves contents of A without contents of B into :ANSWER.",
   "A    :EXP           B    Mathematics, raise A to the power of B and save in :ANSWER.",
   "A    :EXPRESS       NULL High-Level,  saves a sentence into answer, creates sentence in order of keywords, A.",

   "NULL :FALSE         NULL Logic,       save 0 to :ANSWER.",
   "A    :FIRST         B    Set Theory,  save the first B entries in A to :ANSWER.",
   "A    :FIRSTAFTER    B    Time Proc,   save to :ANSWER all A with the creation time after B seconds ago.",
   "A    :FIRSTBEFORE   B    Time Proc,   save to :ANSWER all A with the creation time before B seconds ago.",
   "NULL :FORCE         NULL Control,     forces the information afterwards to be taken literally.",   
   "A    :FOREACH       B    Control,     Chocky xargs on A if B=:NULL, Split by B if ALPHA or groups of B if Zahlen.",
   "A    :FORGET        NULL Control,     remove command component of concepts A.",

   "A    :GETEMODEBUG   NULL Emotion,     Displays all the associations associated with this emotion, A.",
   "NULL :GETGRAPH      NULL Language,    lists available Markov Models.",
   "A    :GRAMMAR       B    Control,     specify A's grammatical category as B.",
   "A    :GRAPHS        NULL Language,    register A as graphs.",
   "A    :GREATER       B    Logic,       if A is greater than B save 1 else save 0 in :ANSWER.",
   "A    :GROUPSET      B    Language,    specify nouns, A, as collective, B.",
   "NULL :GROUPSHOW     NULL Language,    lists the collectives.",

   "NULL :HELP          [B]  Interface,   displays help information on command B, else command list.",
   "A    :HOOK          B    High-Level,  sets the executional commands, A in :hook attribute of concept B.",
   "A    :HOW           B    High-Level,  finds symantic relation between A to B and stores in :ANSWER.",

   "NULL :IF            B    Control,     if B then run the rest upto :OTHERWISE or :END.",
   "A    :IMPEVENT      NULL Language,    sets A up as an imperative event.",
   "A    :INFOEVENT     NULL Language,    sets A up as an information event (indicative).",   
   "A    :INTERSECTION  B    Set Theory,  compute A intersection B and store in :ANSWER.",

   "A    :LANGUAGE      NULL High-Level,  sets ENiX up language to use all grammatical types in B.",
   "NULL :LANGUAGEDEBUG NULL Language,    debugs the current language setup.",
   "A    :LAST          B    Set Theory,  save the last B entries in A to :ANSWER.",
   "A    :LASTAFTER     B    Time Proc,   save to :ANSWER all A with last access time after B seconds ago.",
   "A    :LASTBEFORE    B    Time Proc,   save to :ANSWER all A with last access time before B seconds ago.",
   "A B  :LEARN         NULL High-Level,  attempts to understand pattern B and save it as A.",
   "A    :LIKE          B    Control,     categorise all of A just like B is.",
   "A    :LIMITS        NULL High-Level,  specifies number of MB to allocate to pattern recognition.",
   "A    :LISTBYTOPIC   NULL Language,    saves the CS registers, A, that match some part of the :TOPIC to :ANSWER.",
   "NULL :LISTCSVALUES  NULL Language,    lists all context addressible memory locations, saving to :ANSWER.",
   "A    :LISTSENTENCES NULL Language,    takes input from :LISTCSVALUES and saves to :ANSWER those which are sentences.",
   "A    :LOAD          NULL Memory,      load memory file A from disk.",
   "A    :LOCKLANG      NULL Control,     if A is ON or OFF, disable/set memory modification respectly.",
   "A    :LSTCOMB       NULL Control,     saves a list of combinations derived from A to :ANSWER.",
   "NULL :LSTSCOPE      NULL Control,     display available scopes.",
   
   "A    :MAP           NULL Language,    map the Hidden Markov Model A.",     
   "NULL :MATH          B    Control,     translate A into indicative.",
   "A    :MELD          B    Memory,      import concept A and dependencies from personality B.",
   "NULL :MELDVF        NULL Language,    combine active and passive verb forms.",
   "NULL :MEMORY        NULL Interface,   display the contents of the question motives.",
   "A    :MERGE         NULL Set Theory,  cat all the words in A together and save in :ANSWER.",
   "NULL :MODE          [B]  Memory,      view or redefine natural selection criteria for memory.",
   "A    :MUL           B    Mathematics, multiplies A and B and saves the result in :ANSWER.",
   "NULL :MUSIC         NULL High-Level,  create a music sequence.",
   "A    :MUTATE        B C  Control,     performs operation B on data A and B.",

   "A    :NAND          B    Logic,       if A nand B then save 1 else save 0 in :ANSWER.",
   "NULL :NEW           NULL High-Level,  create a new problem.",   
   "A    :NICEFY        B    High-Level,  save a sequence in :ANSWER based on A that is understood, B.",
   "A    :NLPAWRAP      B    High-Level,  saves avoidance argument between A and B to :ANSWER.",
   "A    :NLPCWRAP      B    High-Level,  saves causal argument between A and B to :ANSWER.",
   "A    :NOR           B    Logic,       if A nor B then save 1 else save 0 in :ANSWER.",
   "A    :NOT           NULL Logic,       if A then save 0 else save 1 in :ANSWER.",
   "A    :NOUNS         NULL Language,    specify the nouns A.",
   "NULL :NULL          NULL Control,     blank command (activates Chocky).",

   "NULL :ODDMAN        B    High-Level,  saves oddman-out sequence B to :ANSWER.",
   "A    :OR            B    Logic,       if A or B then save 1 else save 0 in :ANSWER.",
   "A    :ORTHOGONAL    NULL High-Level,  reduce A into an orthognolly understood pattern and save to :ANSWER.",
   "NULL :OTHERWISE     NULL Logic,       the exclusion of the :IF control sequence.",

   "A    :PATTERN       NULL Interface,   displays the pattern A.",
   "NULL :PERSONALITY   NULL High-Level,  displays name of ENiX profile.",
   "A    :PHRASE        NULL High-Level,  constructs grammatically correct sentences out of keywords A.",
   "A    :POPEMODEBUG   B    Emotion,     populate emotion registers from data A1 and A2 in mood B.",
   "A    :PPRONOUNS     NULL Language,    registers personal pronouns with ENiX.",
   "A    :PREDVERBS     NULL Language,    sets predicate verbs.",
   "A    :PREPEND       B    Set Theory,  prepend contents of B to the front of A, and save to :ANSWER.",   
   "A    :PRONOUNS      NULL Language,    specify pronouns.",
   "NULL :PURGE         NULL Memory,      erase everything in memory.",
   "A    :PURPOSE       B    Control,     specify A's purpose category as B.",

   "A    :QUALIFY       B    Control,     qualify concepts, A in respect of B[0] with rest of B.",
   "NULL :QUOTE         NULL Control,     interpret everything after :QUOTE to termination criteria as literal.",

   "A    :RANDOM        B    Mathematics, generates A numbers in the range [0,B).",
   "A    :RANDSEED      NULL Mathematics, sets a random seed, A.",
   "NULL :READ          B    Control,     assume input from file, B, rather than cli parameters.",
   "A    :REASON        NULL High-Level,  define logic for concept A.",
   "A    :RECALL        NULL High-Level,  constructs quotations from keywords A and saves in :ANSWER.",
   "A    :RECOLLECT     NULL High-Level,  retrieves quotations containing keywords A.",
   "NULL :RELATIONSHIP  B    High-Level,  creates numeric problem from relationship B.",
   "A    :REVERSE       NULL Set Theory,  reverses A and saves to :ANSWER.",   
   "A    :REVISE        NULL High-Level,  opens A for editing.",
   "A    :ROUTE         B    Language,    finds a data route A to B. Not for language.",
   "A    :RUN           NULL Control,     ENiX runs contents of A through OS.",

   "A    :SAVE          NULL Memory,      save memory as memory file, A.",
   "A    :SAVESET       B    Set Theory,  save the set A to B.",
   "NULL :SAVF          NULL Language,    show active verb forms.",

   "A    :SCHEDDEL      NULL Time,        delete timing schedule called name, A.",
   "A    :SCHEDNEW      [B]  Time,        create a new schedule name/start/period A to execute B.",
   "NULL :SCHEDULER     NULL Time,        invoke the ENiX scheduler to run any events.",

   "A    :SEMPATH       NULL High-Level,  saves a list of descriptions to :ANSWER.",
   "A    :SENTENCEASSIGNNULL High-Level,  takes sentence A and if suitable forms descriptions.",
   "A    :SENTENCECBASE NULL Language,    converts sentence A into the base verb and saves in :ANSWER.",
   "A    :SENTENCECMOOD B    Language,    converts sentence A into mood B and saves in :ANSWER.",
   "A    :SENTENCECTENSEB    Language,    converts sentence A into tense, B, and save to :ANSWER.",
   "A    :SENTENCEDEBUG NULL Interface,   display breakdown of sentence, A.",
   "A    :SENTENCEEMO   NULL Language,    show the emotion of a sentence, A.",
   "A    :SENTENCEEXP   NULL High-Level,  explain sentence, A.",
   "A    :SENTENCETENSE NULL Language,    saves the tense of A to :ANSWER",
   "NULL :SENTENCEUNIT  B    Language,    set B as sentence unit.",
   "A    :SENTIENCY     NULL Control,     A=ON enables and A=OFF disables higher linguistics.",
   "NULL :SERIALRECV    B    Robotics,    store received data in :ANSWER on serial port B.",
   "A    :SERIALSEND    B    Robotics,    send data A on serial port B.",
   "A    :SERIALTEST    B    Robotics,    send test data A every second on serial port B.",
   "A    :SETBIAS       NULL Emotion,     set A as a emotional bias.",
   "A    :SETCONDCAUSE  NULL Language,    set A as a conditional cause value.",
   "A    :SETCONDEFFECT NULL Language,    set A as a conditional effect value.",
   "A    :SETEMOMODE    B    Emotion,     set emotion attribute A as value B.",
   "A    :SETGENDER     B    Language,    set A's gender as B. Where B is male or female.",
   "A    :SETMOOD       NULL Emotion,     set A as the emotional mood of ENiX.",
   "A    :SETNULL       NULL Language,    set A as being equivalent to NULL.",
   "A    :SETPASSIVE    NULL OBSOLETE?,   set passive Hidden Markov Model A.",   
   "A    :SETQUESTION   NULL Language,    set the question identifier A.",
   "NULL :SETSCOPE      B    Control,     set scope resolution B.",
   "A    :SETSERIAL     B    Robotics,    sets the serial connection data A as com B.",
   "A    :SETWH         NULL Language,    shows keywords used to identify WH-Q sentences.",
   "A    :SETYN         NULL Language,    shows keywords used to identify YN-Q sentences.",
   "NULL :SHORTPATH     NULL High-Level,  save the shortest semantic pathway in cache to :ANSWER.",
   "NULL :SHOWPROF      NULL Control,     show the profiles available to ENiX3.",
   "A    :SHRINK        NULL Set Theory,  remove duplicated elements from :ANSWER.",
   "NULL :SHWSCOPE      NULL Control,     show the current scope resolution.",
   "A    :SIGNAL        NULL Logic,       save 1 if A else save 0 to :ANSWER.",
   "A    :SIMILAR       B    Set Theory,  finds descriptors B in A and saves matches in :ANSWER.",
   "A    :SIZE          NULL Set Theory,  saves cardinality of A to :ANSWER.",
   "NULL :SLEEP         NULL Memory,      sort out memory using natural selection.",
   "A    :SMALLER       B    Logic,       if A is smaller than B save 1 else save 0 to :ANSWER.",
   "NULL :SMVF          NULL Language,    print melded verb forms.",
   "A    :SPA           NULL Language,    -",
   "A    :SPATH         NULL High-Level,  Finds the semantic relation between A1 and A2.",
   "A    :SPLIT         NULL Set Theory,  caches the sequence of letters in A into :ANSWER.",
   "A    :SPVF          NULL Language,    set passive verb form A.",
   "NULL :STATISTICS    NULL Interface,   display memory statistics.",
   "A    :STEMADD       B    Language,    registers suffixes A to language article B.",
   "A    :STEMBASE      NULL Language,    saves a list of stems of words A to :ANSWER.",
   "A    :STEMCLASS     NULL Language,    classifies the words, A, by their suffixes.",
   "A    :STEMFIND      NULL Language,    saves a list of similar words to A, to :ANSWER.",
   "A    :STEMMELD      NULL Language,    associates meanings between similar words to A.",
   "NULL :STEMSHOW      NULL Language,    display stemming suffixes.",
   "A    :STORE         B    Control,     store A in B.",
   "A    :STUDY         B    High-Level,  associates A components in memory save to HMM B.",
   "A    :SUB           B    Mathematics, subtract B from A and save to :ANSWER.",
   "A    :SUBJ          NULL Language,    set subject tokens A.",
   "A    :SUBSET        B    Set Theory,  saves 1 else 0 to :ANSWER depending on whether A is a subset of B.",
   "NULL :SYSTEMMOOD    NULL Emotion,     retrieves the system emotion from the :emomode record.",
   "A    :SWAP          B    Control,     inserts A into prefix B saves B to :ANSWER in the process.",
   
   "A    :TENSE         B    Language,    this specifies the tense of A as tense, B.",
   "A    :TENSES        NULL Language,    this specifes a list of tenses A in WMS.",
   "[A]  :TEST          [B]  Reserved,    for development only.",
   "A    :THEN          B    Logic,       -",
   "NULL :THINK         NULL High-Level,  -",
   "NULL :THINKB        NULL High-Level,  -",
   "A    :TOL           NULL Control,     A=ON turns ON Think Out Loud.",
   "NULL :TOPIC         NULL High-Level,  Display topic of the conversation.",
   "A    :TRANSLATE     B    Control,     translate to language B (Incomplete).",   
   "A    :TREEGENERATE  NULL High-Level,  create a tree of sentences from A stores in :TREE.",
   "NULL :TRUE          NULL Logic,       save 1 to :ANSWER.",
   "A    :TTRANSFORM    NULL Logic,       T-transform A about binary diagnol.",
   
   "NULL :UNDERSTAND    B    High-Level,  0 if no, 1 if partial, 2 if complete.",
   "A    :UNION         B    Set Theory,  merge A and B into a set stored in :ANSWER.",
   "NULL :UNKNOWN       NULL High-Level,  -",
   "A    :UNSTORE       NULL Control,     extract contents of A and save to :ANSWER.",
   "A    :UNWRAP        NULL Set Theory,  remove the outer two words contained in A and save to B.",

   "A    :VEC2EMO       NULL Emotion,     convert an emotion vector, A, into an emotion name, :ANSWER.",
   "A    :VERBOSITY     NULL Control,     sets the either low, medium or high for the verbosity.",
   "A    :VERBPOSTPROC  NULL Language,    post-process the sentence A",
   "A    :VERBTABLEADD  [B]  Language,    Adds verb reference B addressed by triple, A.",
   "NULL :VERSION       NULL Interface,   display software version information.",

   "A    :WAIT          NULL Time,        wait A seconds before continuing processing.",
   "A    :WHQEVENT      NULL Language,    set whqevent to A.",
   "A    :WRAP          NULL Set Theory,  wraps A in quotes and saves in :ANSWER.",

   "A    :XOR           B    Logic,       if A xor B then save 1 else save 0 to :ANSWER.",

   "A    :YNQEVENT      NULL Language,    set ynqevent to A."
   
};

/*! \brief Displays examples on a command.
 *
 */
struct List_Str  *HelpExample(struct List_Str *Word_List,struct List_Str *L){
  char *CmdPrefix=NULL;
  struct List_Str *Buffer=NULL;
  CmdPrefix=StrCat("","cat Examples/");
  for(Buffer=L;Buffer;Buffer=Buffer->Next)
    if(Buffer->Str[0]==':'){
      if(system(StrCat(StrCat(CmdPrefix,ToLower(Buffer->Str)),".txt"))){}
    }
    else
      printf("Unable to find examples for: %s\n",Buffer->Str);
  return NULL;
}

/*! \brief Parses a command.
 *
 */
struct List_Str *Execute(struct List_Str *Pipe,struct List_Str *List){
  int InstructionIndex=0,ExecuteCommand=0,PositionofContext=0,Bypass=1,NumberofCommands=0;
  char *Syntax=NULL,*Execution_TPI=NULL;
  struct List_Str *ContextPrefix=NULL,*Context=NULL;
  ANSWER=Pipe;  
  NumberofCommands=sizeof(Command_List)/sizeof(*Command_List);
  while(List){
    if(List->Str[0]==':'){
      ExecuteCommand=-1;
      for(InstructionIndex=0;InstructionIndex<NumberofCommands;InstructionIndex++){
	if(!strcmp(List->Str,Command_List[InstructionIndex])){
	  ExecuteCommand=InstructionIndex;
	}
      }
      if(ExecuteCommand+1){
	Execution_TPI=List->Str;
	if(Context||ANSWER)
	  ContextPrefix=Context?Context:ANSWER;
	else
	  ContextPrefix=NULL;
	Syntax=Command_Info[ExecuteCommand];
	if((!ContextPrefix)&&(!strncmp(Syntax,"A   ",4))){
	  puts(Syntax);
	  List=List->Next;
	}
	else{
	  List=List->Next?List->Next:NULL;
	  if((!List)&&(!strncmp(Syntax+20,"B   ",4))){
	    puts(Syntax);
	  }
	  else{
	    Bypass=0;
	    if(!strncmp(Syntax+20,"B   ",4))
	      if(List)
		if(List->Str[0]==':')
		  Bypass=1;
	    if(Bypass)
	      puts(Syntax);
	    else{
	      if(strcmp(":force",Execution_TPI)){
		ANSWER=NULL;
		List=InstructionSet[ExecuteCommand](ContextPrefix,List);
		if(!ANSWER)
		  ANSWER=ContextPrefix;
		else
		  if(!strcmp(ANSWER->Str,":null"))
		    ANSWER=NULL;
		Context=NULL;
		PositionofContext=0;
	      }
	      else{ 
		Context=Ins_List_Element(Context,List->Str,PositionofContext++);
	      }
	    }
	  }
	}
      }
      else{
	if(ThinkOutLoud)
	  printf("Ignoring invalid command: %s.\n",List->Str);
	List=List->Next;
      }	    
    }
    else{
      Context=Ins_List_Element(Context,List->Str,PositionofContext++);
      List=List->Next;
    }
  }
  Save_Answer(ANSWER);
  return ANSWER;
}

/*! \brief Displays help data and syntax information on a topic.
 *
 */
struct List_Str *Help(struct List_Str *Word_List,struct List_Str *L){
  int C=0,Found=0,NumberofCommands=0;
  NumberofCommands=sizeof(Command_List)/sizeof(*Command_List);
  if(L){
    if(L->Str[0]==':'){ 
      for(C=0;C<NumberofCommands;C++)
	if(!strncasecmp(L->Str,Command_Info[C]+5,StrLen(L->Str))){
	  printf("%03d: %s\n",C,Command_Info[C]);
	  Found++;
	}
      if(!Found)
	printf("%s is not a behavioural inhibitor.\n",L->Str);
      L=L->Next;
    }
    else
      printf("No help available for \"%s\" because it is not a behavioural inhibitor.\nUse help on its own.\n",L->Str);
  }
  else{
    for(C=0;C<NumberofCommands;C++)
      printf("%03d: %s\n",C,Command_Info[C]);
    puts("-[ Use :help <:COMMAND> for specific commands ]-");
  }
  return L;
}

/*! \brief Save the ANSWER buffer to WMS database.
 *
 */
void Save_Answer(struct List_Str *L){
   char *Data=List2Str(L);
   struct Datablock *DB=Goto_DB_Entry(Database[1],":memory");
   if(!DB){
      Database[1]=Add_DB_Entry(Database[1],":memory");
      DB=Database[1];
   }
   if(Data)
     Rep_DB_Entry(DB,0,7,Data);
   else
     Rep_DB_Entry(DB,0,7,"?");
}

/*! \brief Run the interpreter that parses ENiX commands.
 *
 */
struct List_Str *Interpreter(struct List_Str *Com){
   char *S=NULL;
   struct List_Str *List=NULL,*Buffer=NULL;
   Com=Com->Next;
   while(Com){
     S=Com->Str;
     Com=Com->Next;
     if(List){ 
       while(List->Next) List=List->Next; 
       List->Next=Expand_Exp(S); 
     } 
     else{ 
       List=Expand_Exp(S); 
       Buffer=List; 
     }  
   } 
   List=Buffer; 
   List=Translate(List); 
   return List;
}

/*! \brief Separate words from punctuation.
 *
 */
struct List_Str *Expand_Exp(char *Word){
  int LastChar=0,Flag=0;
  char Last=0,*LastP=NULL,*WordBuf=StrCat("",Word);
  struct List_Str *R=NULL;
  LastChar=StrLen(WordBuf)-1;
  Last=WordBuf[LastChar];
  if((Last==',')||(Last=='.')||(Last==':')||(Last=='?')||(Last=='!')||(Last==';')){ 
    Flag=1;
  }
  if(Flag&&LastChar){
    LastP=(char *)malloc(2*sizeof(char));
    LastP[0]=Last;
    LastP[1]=0;
    WordBuf[LastChar]=0;
    R=Ins_List_Element(R,WordBuf,0);
    R=Ins_List_Element(R,LastP,1);
  }
  else
    R=Ins_List_Element(R,WordBuf,0);
  return R;
}

/*! \brief Recursively evaluate the meaning of concepts.
 *
 */
struct List_Str *Translate(struct List_Str *List) {
   int Position=0,Softquote=0,Hardquote=0,Force=0,New_Force=0;
   char *Word=NULL;
   struct List_Str *Output=NULL,*Translated=NULL;
   struct Datablock *DB=NULL;
   while(List){
      if(Force)
	Output=Ins_List_Element(Output,List->Str,Position++);
      else{
	 if(Hardquote){  
	    if(!strcmp(List->Str,":interpret"))
	      Hardquote=0; 
	    else
	      Output=Ins_List_Element(Output,List->Str,Position++);                            }
	 else
	   if((!strcmp(List->Str,":quote"))||(!strcmp(List->Str,":trans"))||(!strcmp(List->Str,":force"))||(!strcmp(List->Str,":literal"))){
	      if(!strcmp(List->Str,":force"))
		New_Force=1;
	      else{ 
		 if(!strcmp(List->Str,":quote"))
		   Softquote=1; 
		 else{
		    if(!strcmp(List->Str,":trans"))
		      Softquote=0;
		    else
		      Hardquote=1;
		 }
	      }
	   }
	   else{
	     if(List->Str[0]==':')
		Output=Ins_List_Element(Output,List->Str,Position++);
	     else{
	       if((DB=Goto_DB_Entry(Database[1],List->Str)))
		   Translated=Str2List(Get_DB_Entry(DB,0,7));
		else
		   Translated=Str2List("?");
		Word=Translated->Str;
		if(!strcmp(Word,"?"))
		  Output=Ins_List_Element(Output,List->Str,Position++);
		else{                  
		   if(!strcmp(Word,":trans"))
		     Softquote=0;
		   else{
		      if(!Softquote){ 
			 if(Paradox(Word,NULL,Softquote+(Hardquote<<1)+(Force<<2))==-1){
			    puts("Paradox Handling: Ignoring paradox or cyclic definition...");
			    Output=Ins_List_Element(Output,List->Str,Position++);
			 }
			 else
			   List=Ins_List_List(List,Translated,1);
		      }
		      else
			Output=Ins_List_Element(Output,List->Str,Position++);
		   }
		}
	     }
	   }
      }
      List=List->Next;
      Force=New_Force;
      New_Force=0;
   }
   return Output;
}

/*! \brief Paradox handler to prevent ENiX getting stuck in recursive evaluation loops.
 *
 */
int Paradox(char *Word,struct List_Str *Used,int Flags){
   int Softquote=0,Hardquote=0,Force=0; 
   struct List_Str *Translated=NULL,*List=NULL; 
   Softquote=Flags&1;
   Hardquote=(Flags>>1)&1;
   Force=(Flags>>2)&1;
   List=Ins_List_Element(NULL,Word,0);
   if((isdigit(Word[0]))||(Word[0]==':')){
     if((!strcmp(Word,":force"))||(!strcmp(Word,":literal"))||(!strcmp(Word,":interpret"))||(!strcmp(Word,":quote"))||(!strcmp(Word,":trans"))){
       if(!Force){
	 if(Hardquote){
	   if(!strcmp(List->Str,":interpret"))
	     Hardquote=0;
	 }
	 else
	   if((!strcmp(List->Str,":quote"))||(!strcmp(List->Str,":trans"))||(!strcmp(List->Str,":force"))||(!strcmp(List->Str,":literal"))){
	     if(!strcmp(List->Str,":force"))
	       Force=1;
	     else{ 
	       if(!strcmp(List->Str,":quote"))
		 Softquote=1; 
	       else{
		 if(!strcmp(List->Str,":trans"))
		   Softquote=0;
		 else
		   Hardquote=1;
	       }
	     }
	   }
       }
       return Softquote+(Hardquote<<1)+(Force<<2);
     }
     else return Flags;
   }
   else{
      if(!(Softquote+Hardquote+Force)){
	 if(Find_List_Element(Used,Word)>-1) 
	   return -1;
	 Used=Ins_List_Element(Used,Word,0);
	 Translated=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],Word),0,7));
	 if(Translated->Str[0]=='?') 
	   return Flags;
	 else{
	    while(Translated){
	       if((Flags=Paradox(Translated->Str,Used,(Softquote+(Hardquote<<1)+(Force<<2))))==-1)
		 return -1;
	       Softquote=Flags&1; 
	       Hardquote=(Flags>>1)&1; 
	       Force=(Flags>>2)&1;
	       Translated=Translated->Next;
	    }
	 }
      }
      else
	return Softquote+(Hardquote<<1)+(Force<<2);
   }
   return Softquote+(Hardquote<<1)+(Force<<2);
}


/*! \brief Conditional if command.
 *
 */
struct List_Str *If(struct List_Str *Word_List,struct List_Str *L){
   int _=0,Switch=0,T=0,F=0,A=!!(atoi(List2Nums(L)->Str)),Level=1;
   struct List_Str *Data=NULL,*TRUE=NULL,*FALSE=NULL,*PIPE=Word_List;
   L=L->Next;
   for(Data=L;Data&&Level;Data=Data->Next){
      if(Data->Str[0]==':'){
	 for(_=0;_<NumberofTerminations;_++)
	    if(!strcmp(Data->Str,TerminatedCommands[_]))
	      Level++;
	 if(!strcmp(Data->Str,":end"))
	   Level--;
	 if(!strcmp(Data->Str,":otherwise"))
	   Switch=1;
      }
      if(Switch)
	FALSE=Ins_List_Element(FALSE,Data->Str,F++);
      else
	TRUE=Ins_List_Element(TRUE,Data->Str,T++);
   }
   if(A)
      Execute(PIPE,TRUE);
   else
      Execute(PIPE,FALSE);
   return Data;
}

/*! \brief Swaps the data parameters before and after a command.
 *
 */
struct List_Str *Swap(struct List_Str *Word_List,struct List_Str *L){
   int _=0,Position=0;
   struct List_Str *Buffer=L;
   ANSWER=NULL;
   for(_=0;(Buffer&&(!Position));Buffer=Buffer->Next){
      if(Buffer->Str[0]==':'){
	 Position=_;
	 break;
      }
      else
	 ANSWER=Ins_List_Element(ANSWER,Buffer->Str,_++);
   }
   if(Position)
     L=Ins_List_List(Buffer,Word_List,1);
   return L;
}

/*! \brief Execute a command from it's number in the :help output.
 *
 */
struct List_Str *Mutate(struct List_Str *Word_List,struct List_Str *L){
  return InstructionSet[atoi(List2Nums(Str2List(L->Str))->Str)](Word_List,L->Next);
}

/*! \brief Displays the answer buffer of the last successful command.
 *
 */
struct List_Str *Answer(struct List_Str *Word_List,struct List_Str *L){
  PrintList(Word_List);
  return L;
}

/*! \brief ENiX equivalent of xargs.
 *
 */
struct List_Str *Foreach(struct List_Str *Word_List,struct List_Str *L){
  /* Chocky Xargs if B=:NULL separator if B is ALPHA or grouper if NUMERIC */
   int _=0,GroupSize=0,Depth=1,Position=0;
   char *Separator=L->Str;
   struct List_Str *Pipeline=NULL,*Buffer=NULL,*ToExe=NULL,*RemainingExe=NULL;
   L=L->Next;
   RemainingExe=L;
   for(Buffer=L;Buffer;Buffer=Buffer->Next){
      if(Buffer->Str[0]==':'){
	 for(_=0;_<NumberofTerminations;_++)
	   if(!strcmp(TerminatedCommands[_],Buffer->Str)){
	      Depth++;
	   }
      }
      if(Buffer->Str[0]==':'){
	 if(!strcmp(":end",Buffer->Str)){
	    Depth--;
	    if(!Depth){
	      break;
	    }
	 }
      }
      if(Depth>0){
	 ToExe=Ins_List_Element(ToExe,Buffer->Str,Position++);
	 RemainingExe=RemainingExe->Next;
      }
   }
   L=RemainingExe;
   if(!strcmp(":null",Separator)){
      while(Word_List){
	 Execute(Str2List(Word_List->Str),ToExe);
	 Word_List=Word_List->Next;
	 Pipeline=Ins_List_List(Pipeline,ANSWER,Size_of_List(Pipeline));
      }
   }
   else{
      if(isdigit(Separator[0])){
	 GroupSize=atoi(Separator);
	 while(Word_List){
	    ANSWER=NULL;
	    for(_=0;(_<GroupSize)&&Word_List;Word_List=Word_List->Next)
	      ANSWER=Ins_List_Element(ANSWER,Word_List->Str,_++);
	    Execute(ANSWER,ToExe);
	    Pipeline=Ins_List_List(Pipeline,ANSWER,Size_of_List(Pipeline));
	 }	 
      }
      else{
	 while(Word_List){
	    ANSWER=NULL;
	    for(_=0;(strcmp((Word_List?Word_List->Str:""),Separator))&&Word_List;Word_List=Word_List->Next)
	      ANSWER=Ins_List_Element(ANSWER,Word_List->Str,_++);
	    if(Word_List){
	       ANSWER=Ins_List_Element(ANSWER,Word_List->Str,_++);
	       Word_List=Word_List->Next;
	    }
	    Execute(ANSWER,ToExe);
	    Pipeline=Ins_List_List(Pipeline,ANSWER,Size_of_List(Pipeline));
	 }
      }      
   }
   ANSWER=Pipeline;
   return L;
}

/*! \brief Command line interpreter.
 *
 */
struct List_Str *Chocky(struct List_Str *Word_List,struct List_Str *L){
   Execute(NULL,Word_List);
   return L;
}

/*! \brief Displays ENiX version.
 *
 */
struct List_Str *Version(struct List_Str *Word_List,struct List_Str *L){
   puts("ENiX 3, AtlasNet. GPL [OvO]wl.");
   return L;
}

/*! \brief Disables evaluation for the following command.
 *
 */
struct List_Str *Force(struct List_Str *Word_List,struct List_Str *L){
   return L;
}

/*! \brief Null operator. This command does nothing, but there are syntactic reasons why it is necessary.
 *
 */
struct List_Str *Nothing(struct List_Str *Word_List,struct List_Str *L){
   return L;
}

/*! \brief Switches between indicative and functional paradigm. 
 *
 */
struct List_Str  *Math(struct List_Str *Word_List,struct List_Str *L){
   int Position=0,POrder=0,PL=1,C=0;
   struct List_Str *Input=NULL,*Buffer=NULL,*ToTrans=NULL,*Simplified=NULL,*Final=NULL;
   for(Input=NULL;L&&strcmp(L->Str,":endmath");L=L->Next)
     Input=Ins_List_Element(Input,L->Str,Position++);
   if(L)
     L=L->Next;
   while(PL>0){
      POrder=0;
      for(Buffer=Input;Buffer;Buffer=Buffer->Next){
	 if(!strcmp(Buffer->Str,"("))
	   POrder++;
	 if(!strcmp(Buffer->Str,")"))
	   POrder--;
	 if(POrder<0){ 
	    puts("Syntax: NULL :MATH B :ENDMATH, check your brackets - there is something wrong with them!");
	    return L;
	 }
      }
      if(POrder){
	 puts("Syntax: NULL :MATH B :ENDMATH, check your brackets - there is something wrong with them!");
	 return L;
      }
      PL=0;
      C=0;
      for(Buffer=Input;Buffer;Buffer=Buffer->Next){
	 if(!strcmp(Buffer->Str,"("))
	   POrder++;
	 if(!strcmp(Buffer->Str,")"))
	   POrder--;
	 if(POrder>PL)
	   PL=POrder;
      }
      ToTrans=NULL;
      Position=0;
      Simplified=NULL;
      for(Buffer=Input;Buffer;Buffer=Buffer->Next){
	 if(!strcmp(Buffer->Str,"("))
	   POrder++;
	 if(POrder!=PL)
	   Simplified=Ins_List_Element(Simplified,Buffer->Str,C++);
	 if(!strcmp(Buffer->Str,")")){
	    if(POrder==PL){
	       Execute(NULL,ToTrans);
	       Position=0;
	       ToTrans=NULL;
	       while(ANSWER){
		  Simplified=Ins_List_Element(Simplified,ANSWER->Str,C++);
		  ANSWER=ANSWER->Next;
	       }
	    }
	    POrder--;
	 }
	 if((POrder==PL)&&(!!strcmp(Buffer->Str,"("))&&(!!strcmp(Buffer->Str,")")))
	   ToTrans=Ins_List_Element(ToTrans,Buffer->Str,Position++);
      }
      if(Simplified)
	Final=Simplified;
      Input=Simplified;
   }
   ANSWER=Final;
   return L;
}

/*! \brief Executes a system command.
 *
 */
struct List_Str *RUN(struct List_Str *Word_List,struct List_Str *L){
  if(system(Get_DB_Entry(Goto_DB_Entry(Database[1],Word_List->Str),0,7))){}
  return L;
}

/*! \brief Executes the contents of a file.
 *
 */
struct List_Str *Read(struct List_Str *Word_List,struct List_Str *L){
  int argc=2,_=0;
  char *Filename1=NULL,*Commands=NULL,**Buffer=NULL,**argv=NULL;
  FILE *Disk=NULL;
  struct List_Str *Batch_Interface=NULL,*Com=NULL;
  Filename1=StrCat("./",L->Str); L=L->Next;
  if(!(Disk=fopen(Filename1,"r"))){
    printf("Abort operation: Open fail for %s\n",Filename1);
    return L;
  }
  else{
    Commands=LoadFile(Disk);
    fclose(Disk); 
  }
  Batch_Interface=Str2List(Commands); 
  Buffer=(char **)malloc(sizeof(char *)); 
  Buffer[0]=StrCat("","FILE");
  while(Batch_Interface){
    Buffer=(char **)realloc(Buffer,argc*sizeof(char *));
    Buffer[argc-1]=Batch_Interface->Str;
    Batch_Interface=Batch_Interface->Next;
    argc++;
  }
  argc--; 
  argv=Buffer; 
  for(_=0;_<argc;_++)
    Com=Ins_List_Element(Com,(char *)argv[_],_);
  Database[1]=Recognise(Database[1],Com);
  Translation_Bypass=1; 
  Execute(Recall_Prev_Answer(),Interpreter(Com));
  Translation_Bypass=0;
  return L;
}

/*! \brief Remove quotes from an expression
 * - quotes are :trans :quote
 */
struct List_Str *Unwrap(struct List_Str *WordList,struct List_Str *L){
   int C=0;
   struct List_Str *Inp1=NULL,*Buffer=NULL,*TmpBuffer=NULL;
   Inp1=WordList;
   Buffer=Inp1;
   for(C=0;Buffer;C++){
      Buffer=Buffer->Next;
   }
   if(C>2){
      Inp1=Inp1->Next;
      Buffer=Inp1;
      while(Inp1->Next){
	 TmpBuffer=Inp1;
	 Inp1=Inp1->Next;
      }  
      TmpBuffer->Next=NULL;
   }
   else{
      Buffer=NULL;
      Buffer=Ins_List_Element(Buffer,"?",0);
   }
   ANSWER=Buffer;
   return L;
}

/*! \brief Wraps quotes around an expression
 * - quotes are :trans :quote
 */
struct List_Str *Wrap(struct List_Str *WordList,struct List_Str *L){
   int C=0;
   struct List_Str *Inp1=NULL,*Buffer=NULL;
   Inp1=WordList;
   Inp1=Ins_List_Element(Inp1,":quote",0);
   Buffer=Inp1;
   for(C=0;Buffer;C++)
      Buffer=Buffer->Next;
   Inp1=Ins_List_Element(Inp1,":trans",C);
   ANSWER=Inp1;
   return L;
}

/*! \brief ENiX Do loop. Analogous to a for / while loop.
 *
 */
struct List_Str *Do(struct List_Str *Word_List,struct List_Str *L){
   float Continue=0;
   char *Command=NULL;
   struct List_Str *List=NULL,*Input=Word_List;
   Command=L->Str;
   L=L->Next;
   if(Input){
      if((Continue=atof(Input->Str))==0){
	 puts("DO not initialised.");
	 return L;
      }
   }
   else{
      puts("DO not initialised.");
      return L;
   }
   printf(" - CTRL SEQ: DO: [%15s]\n",Command);
   while(Continue){
      List=Expand_Exp(Command);
      List=Translate(List);
      Execute(NULL,List);
      Input=ANSWER;
      if(Input)
	Continue=atof(Input->Str);
      else
	Continue=0;
   }
   puts(" - CTRL SEQ:           TERMINATED.");
   return L;
}

/*! \brief Signal triggers conditional control sequences like :DO and :IF.
 * - true means continue.
 */
struct List_Str *SIGNAL(struct List_Str *Word_List,struct List_Str *L){
   int R=0;
   struct List_Str *I1=List2Nums(Word_List);
   ANSWER=NULL;
   for(;I1;I1=I1->Next){
      if(IsNumeric(I1->Str))
	if(atof(I1->Str)==1)
	  R=1;
   }
   ANSWER=Ins_List_Element(ANSWER,FloatToString(R),0);
   return L;
}

/*! \brief Evaluate a string from list "List" at position "Position".
 * 
 */
struct List_Str *Trans_First(struct List_Str *List,int Position){
   char *Word=Get_List_Element(List,Position);
   struct List_Str *R=Cpy_List(List), *Insert=NULL;
   if(Word){ 
     Insert=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],Word),0,7));
     if(!Insert) 
       return List;
     else
       return Ins_List_List(Del_List_Element(R,Position),Insert,Position);
   }
   else
     return List;
}




/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
