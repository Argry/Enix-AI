/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <string.h>
#include "ENiX_Globals.h"
#include "ENiX_STRING.h"
#include "ENiX_LIST.h"
#include "ENiX_WMS.h"
#include "ENiX_OUTPUT.h"
#include "ENiX_PLURALS.h"

/*! \brief Determines if the clause contains a grouping word.
 *  - Returns 1 if it does, 0 otherwise. Grouping word is "herd" of sheep for example.
 */
int ContainsGrouping(struct List_Str *Clause){
  struct List_Str *Buffer1=NULL,*Buffer2=NULL;
  struct Datablock *DB=NULL;
  if(!(DB=Goto_DB_Entry(Database[1],":group"))){
    if(ThinkOutLoud)
      printf("ERROR ContainsGrouping (%s:%d), Groups not setup!\n",__FILE__,__LINE__);
    return 0;
  }
  for(Buffer1=Clause;Buffer1;Buffer1=Buffer1->Next)
    for(Buffer2=DB->DS[2];Buffer2;Buffer2=Buffer2->Next)
      if(!strcmp(Buffer1->Str,Buffer2->Str))
	return 1;
  return 0;
}

/*! \brief Determines if the clause contains a plural.
 *  - Internal.
 */
int ContainsPlurals(struct List_Str *Clause){
  struct List_Str *Buffer=NULL;
  for(Buffer=Clause;Buffer;Buffer=Buffer->Next)
    if(IsArticle(Buffer->Str,"noun"))
      if(Buffer->Str[strlen(Buffer->Str)-1]=='s')
	return 1;
  return 0;
}

/*! \brief Determines if the clause contains a plural.
 *  
 */
int IsPlural(struct List_Str *Clause){
  if(!ContainsGrouping(Clause))
    if(ContainsPlurals(Clause))
      return 1;
  return 0;
}

/*! \brief List groups in ENiX.
 *  
 */
struct List_Str *GroupShow(struct List_Str *Word_List,struct List_Str *L){
  struct Datablock *DB=NULL;
  if((DB=Goto_DB_Entry(Database[1],":group")))
    Print_DB_Entry(DB,0);
  else
    puts("No groups found.");
  return L;
}

/*! \brief Set plural groups.
 *  
 */
struct List_Str *GroupSet(struct List_Str *Word_List,struct List_Str *L){
  struct Datablock *DB=NULL;
  if(!(DB=Goto_DB_Entry(Database[1],":group"))){
    Database[1]=Add_DB_Entry(Database[1],":group");
    DB=Database[1];
  }
  Rep_DB_Pair(DB,Word_List->Str,L->Str);
  return L->Next;
}


/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


*/
