/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2014.

*/

#include <stdio.h>
#include <string.h>
#include "ENiX_BASICOUT.h"
#include "ENiX_LIST.h"
#include "ENiX_STRING.h"
#include "ENiX_TIME.h"

/*! \brief Print a WMS database record.
 *
 */
void Print_DB_Basic(struct Datablock *LS,int P){
  int _=0;
  char *Str=NULL;
  struct List_Str *L1=NULL,*L2=NULL; 
  for(;LS;_++){ 
    if(_==P){
      if(strncmp(LS->DS[0]->Str,"cs",2)){
	printf("=[Datablock %05d]==========================================\n",_); 
	L1=LS->DS[0];
	printf("Name %23s Grammar %23s\n",Get_List_Element(L1,0),Get_List_Element(L1,1));
	printf("Purpose %20s Emotion %23s\n",Get_List_Element(L1,2),Get_List_Element(L1,3));
	printf("First Time %28s\n",FormatTime(Get_List_Element(L1,4))); 
	printf("Last Time %29s\n",FormatTime(Get_List_Element(L1,5)));
	printf("Probability    %13s Commands %22s\n",List2Str(AutoFormat(Str2List(Get_List_Element(L1,6)))),List2Str(AutoFormat(Str2List(Get_List_Element(L1,7)))));
	if((LS->DS[1])&&(LS->DS[2])){ 
	  puts("-[Comparisons]----------------------------------------------");
	  puts("Qualifier:                                            Value:"); 
	  for(L1=LS->DS[1],L2=LS->DS[2];L1&&L2;L1=L1->Next,L2=L2->Next){
	    Str=L2->Str;
	    printf("%-30s%30s\n",L1->Str,List2Str(AutoFormat(Str2List(Str)))); 
	  }
	}
	puts("============================================================"); 
      }
    }
    LS=LS->Next;  
  }
}


/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
