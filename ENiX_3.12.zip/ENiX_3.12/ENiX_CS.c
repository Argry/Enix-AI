/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ENiX_STRING.h"
#include "ENiX_SETTHEORY.h"
#include "ENiX_CS.h"
#include "ENiX_LIST.h"
#include "ENiX_WMS.h"

int CSN;

/*! \brief Goto context address and retrieve the record.
 * 
 */
struct List_Str *CSAddr(struct List_Str *Word_List,struct List_Str *L){
   struct Datablock *DB=GetCSRec(Word_List);
   if(DB)
     ANSWER=Ins_List_Element(NULL,DB->DS[0]->Str,0);
   else
     ANSWER=Ins_List_Element(NULL,Word_List->Str,0);
   return L;
}

/*! \brief Goto context address and retrieve the record.
 * - like CSAddr() but internal.
 */
struct Datablock *GetCSRec(struct List_Str *Word_List) {
   char *L1=NULL,*L2=NULL,*Reg=NULL;
   struct List_Str *Buffer=NULL;
   struct Datablock *DB=NULL;
   if(Word_List)
     Buffer=Word_List;
   else
     Buffer=ANSWER;
   if(Buffer){
      L1=Buffer->Str;
      Buffer=Buffer->Next;
      while(Buffer){
	 L2=Buffer->Str;
	 Reg=CSFind(L1,L2);
	 L1=Reg;
	 Buffer=Buffer->Next;
      }
   }
   if(L1){
      if(!(DB=Goto_DB_Entry(Database[1],L1)))
	return NULL;
      else
	return DB;
   }
   else
     return NULL;
}

/*! \brief List all the context addressible values in use in ENiX.
 *
 */
struct List_Str *ListCSValues(struct List_Str *Word_List,struct List_Str *L){
  ANSWER=CSList();
  return L;
}

/*! \brief List all the context addressible values in use in ENiX.
 * - same as ListCSValues but internal.
 */
struct List_Str *CSList(){
  char *Str=NULL;
  struct List_Str *R=NULL;
  struct Datablock *DB=NULL;
  for(DB=Database[1];DB;DB=DB->Next)
    if(!strncmp(Str=DB->DS[0]->Str,"cs",2))
      R=Ins_List_Element(R,Str,0);
  return R;
}

/*! \brief Finds the context address between consecutive steps in a context address.
 * - Internal function only.
 */
char *CSFind(char *C1,char *C2){
   char *CSText=NULL;
   struct List_Str *L1=NULL,*L2=NULL;
   struct Datablock *DB=Database[1];
   if(C1&&C2){
     if((DB=Goto_DB_Entry(Database[1],C1))){
	 L1=DB->DS[1];
	 L2=DB->DS[2];
	 while(L1){
	    if((!strcmp(L1->Str,C2))&&(!strncmp(L2->Str,"cs",2))){
	       L1=NULL; 
	       CSText=L2->Str;
	       return CSText;
	    }
	    else{
	       L1=L1->Next;
	       L2=L2->Next;
	    }
	 }
      }
   }
   return CSText;
}

/*! \brief Creates the context address between consecutive steps in a context address.
 * - Internal function only.
 */
char *CSLink(char *C1,char *C2){
   int _=0;
   char *CSText=SetCSVar(CSN+1),*R=NULL;
   struct List_Str *L=NULL;
   struct Datablock *DB=Database[1];
   if(!C1)
     R=C2;
   if(!(DB=Goto_DB_Entry(Database[1],C1)))
     DB=Database[1]=Add_DB_Entry(Database[1],C1);
   L=DB->DS[1];
   _=Find_List_Element(L,C2);
   if(_<0){
     DB->DS[1]=Ins_List_Element(DB->DS[1],C2,0); 
     DB->DS[2]=Ins_List_Element(DB->DS[2],CSText,0);
     CSN++;
     CSText=SetCSVar(CSN);
     return CSText;
   }
   else{
     if(!strncmp("cs",Get_List_Element(DB->DS[2],_),2)){
       return CSText;
     }
     else{
       DB->DS[1]=Ins_List_Element(DB->DS[1],C2,0);
       DB->DS[2]=Ins_List_Element(DB->DS[2],CSText,0);
       CSN++;
       CSText=SetCSVar(CSN);
       return CSText;
     }
   }
   return R;
}

/*! \brief Update ENiX with the latest context addressible memory identifier that's available.
 *  - Opposite of GetCSVar().
 */
char *SetCSVar(int CSNum){
   int _=0,C=0;
   char *CSText=NULL;
   struct Datablock *DB=Database[1];
   DB=Goto_DB_Entry(Database[1],":mode");
   for(C=CSNum;C;C/=10)
     _++;
   _+=4;
   CSText=(char *)malloc(_*sizeof(char));
   snprintf(CSText,_,"cs%d",CSNum);
   Rep_DB_Entry(DB,0,7,CSText);
   return CSText;
}

/*! \brief Retrieve the latest context addressible memory identifier that's available.
 *  - Opposite of SetCSVar().
 */
int GetCSVar(){
   int R=0;
   char *CSNUM=NULL;
   CSNUM=Get_DB_Entry(Goto_DB_Entry(Database[1],":mode"),0,7);
   R=atoi(CSNUM+2);
   return R;
}

/*! \brief Retrieve the data out of a context addressible memory location and store it to "ANSWER".
 *  
 */
struct List_Str *CSLoad(struct List_Str *Word_List,struct List_Str *L){
   char *L1=NULL,*L2=NULL,*Reg=NULL;
   struct List_Str *Buffer=NULL;
   struct Datablock *DB=NULL;   
   Buffer=Word_List;
   if(Buffer){
      L1=Buffer->Str;
      Buffer=Buffer->Next;
      while(Buffer){
	 L2=Buffer->Str;
	 Reg=CSFind(L1,L2);
	 L1=Reg;
	 Buffer=Buffer->Next;
      }
   }
   if(L1){
     if(!(DB=Goto_DB_Entry(Database[1],L1)))
       ANSWER=NULL;
     else
       ANSWER=Str2List(Get_DB_Entry(DB,0,7));
   }
   else{
     ANSWER=NULL;
   }
   return L;
}

/*! \brief Reconstruct the context address of a context addressible memory identifier.
 *
 */
struct List_Str *CSRecon(struct List_Str *Word_List,struct List_Str *L){
  ANSWER=IntCSRecon(Word_List->Str);
  return L;
}

/*! \brief Reconstruct the context address of a context addressible memory identifier.
 * - same as CSRecon but internal.
 */
struct List_Str  *IntCSRecon(char *CSStr){
  int _=0,Length=0,Found=0,STOP=0;
  char *CSNUM=NULL;
  struct List_Str *DSDATA=NULL,*R=NULL;
  struct Datablock *DB=Database[1];
  if(strncmp(CSStr,"cs",2)){
    if(isdigit(CSStr[0])){
      CSNUM=(char *)malloc((Length=3+StrLen(CSStr))*sizeof(char));
      snprintf(CSNUM,Length,"cs%s",CSStr);
    }
    else
      return Str2List(CSStr);
  }
  else
    CSNUM=CSStr;
  while(!STOP){
    Found=0;
    for(DB=Database[1];DB;DB=DB->Next){
      DSDATA=DB->DS[2];
      if((_=Find_List_Element(DSDATA,CSNUM))>-1){
	if(strncmp(Get_DB_Entry(DB,1,_),"cs",2)){
	   Found=1;
	   R=Ins_List_Element(R,Get_List_Element(DB->DS[1],_),0);
	   CSNUM=DB->DS[0]->Str;
	   break;
	}	
      }
    }
    if(!Found) STOP=1;
    else{
      if(strncmp(CSNUM,"cs",2)){
	R=Ins_List_Element(R,CSNUM,0);
	STOP=1;
      }
    }
  }
  return R;
}

/*! \brief Save data at a context addressible memory location.
 * 
 */
struct List_Str *CSSave(struct List_Str *Word_List,struct List_Str *L){
   char *C1=NULL,*V=NULL;
   struct Datablock *Meaning=NULL;
   C1=CSCreate(Word_List);
   if(L){
     V=L->Str;
      L=L->Next; 
      if((Meaning=Goto_DB_Entry(Database[1],V)))
	Rep_DB_Entry(Goto_DB_Entry(Database[1],C1),0,7,Get_DB_Entry(Meaning,0,7));
   }
   return L;
}

/*! \brief Create a context address and return the name of the CS ID.
 * 
 */
char *CSCreate(struct List_Str *Word_List){
  int Shared_Context=1;
  char *C1=NULL,*C2=NULL,*V=NULL,*B=NULL;
  struct List_Str *Buffer=NULL;
  Buffer=Word_List;
  CSN=GetCSVar();
  C1=Buffer->Str;
  Buffer=Buffer->Next;
  while(Buffer){
    C2=Buffer->Str;
    if((B=CSFind(C1,C2)))
      C1=B;
    else{
      Shared_Context=0;
      V=CSLink(C1,C2);
      C1=V;
    }
    Buffer=Buffer->Next;
  }
  if(!Shared_Context)
    Database[1]=Add_DB_Entry(Database[1],C1);
  return C1;
}

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
