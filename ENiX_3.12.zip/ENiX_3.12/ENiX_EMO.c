/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ENiX_Globals.h"
#include "ENiX_STRING.h"
#include "ENiX_LIST.h"
#include "ENiX_WMS.h"
#include "ENiX_NLP.h"
#include "ENiX_CALC.h"
#include "ENiX_SEMANTICS.h"
#include "ENiX_EMO.h"
#include "ENiX_WMS_COMPAT.h"
#include "ENiX_SPLINE.h"
#include "ENiX_HLR.h"
#include "ENiX_CS.h"
#include "ENiX_SETTHEORY.h"
#include "ENiX_MULTIPLEX.h"
#include "ENiX_APPLICATIONS.h"


struct EmoReady  *EmpatheticSummary=NULL;
struct ConceptE  *GlobalE=NULL; /* stores empathy of current sentence */
struct Feeling   *GlobalF=NULL; /* for the output of pattern analyser */
char    *Smilie=":|";


struct List_Str  *(*EmoProc[])(struct EmoReady *EmpData,struct List_Str *EmoData)={
  EmoUnderstanding,EmoMorality,EmoMortality,EmoAction,EmoDetermination
};

/*! \brief Maps the numeric emotion vector into low medium and high attributes.
 *
 */
struct List_Str *EmotionMapper(struct List_Str *Word_List,struct List_Str *L){
  int _=0;
  float EmoTriggers=0,EmoRate=0,EmoOld=0,EmoNew=0;
  char *EmotionAttributes[]={"understood","empathise","deadline","argue","verbosity"};
  struct List_Str *FinalEmotion=NULL,*Attributes=NULL,*Levels=Str2List("low medium high"),*AttributeName=NULL;
  struct Datablock *DB=Goto_DB_Entry(Database[1],":emomode");
  /* locate the system mood */

  Attributes=Str2List(Lookup_DB_Attr(DB,"systemmood",NULL));
  /* EmoUnderstanding,EmoMorality,EmoMortality,EmoAction,EmoDetermination */
  
  for(_=0;_<5;_++){
    EmoTriggers=EmoRate=EmoOld=EmoNew=0;

    /* Find the low / medium / high values */
    EmoTriggers=Find_List_Element(Levels,Lookup_DB_Attr(DB,StrCat("trig",EmotionAttributes[_]),NULL))-1;
    
    /* Find the rates of decay */
    EmoRate=atof(Lookup_DB_Attr(DB,StrCat("rate",EmotionAttributes[_]),NULL));
    
    /* Find the old emotion values */
    EmoOld=atof(Get_List_Element(Attributes,_));

    EmoNew=(1-EmoRate)*EmoTriggers+EmoRate*EmoOld;
    FinalEmotion=Ins_List_Element(FinalEmotion,FloatToString(EmoNew),_);
    
    /* Need to update the output data */
    AttributeName=Str2List(EmotionAttributes[_]);
    if(EmoNew<=(-1/3))
      SetEmotionAttr(AttributeName,"low");
    if(EmoNew<=(-1/3))
      SetEmotionAttr(AttributeName,"medium");
    if((EmoNew>(-1/3))&&(EmoNew<(1/3)))
      SetEmotionAttr(AttributeName,"high");
  }

  /* need to save the FinalEmotion data */
  Rep_DB_Pair(DB,"systemmood",List2Str(FinalEmotion));
  return L;
}

/*! \brief Initialise the ConceptE structure.
 *
 */
struct ConceptE *ZeroConceptE(){
  struct ConceptE *R=(struct ConceptE *)malloc(sizeof(CETemplate));
  R->BeforeSize=0;
  R->AfterSize=0;
  R->UnchangedSize=0;  
  R->EmoTB=NULL;
  R->EmoTA=NULL;
  R->EmoTU=NULL;
  R->EmoTD=NULL;
  R->BConcepts=NULL;
  R->AConcepts=NULL;
  R->UConcepts=NULL;
  R->EmoBConcepts=NULL;
  R->EmoAConcepts=NULL;
  R->EmoUConcepts=NULL;
  return R;
}

/*! \brief Initialise the EmoReady structure.
 *
 */
struct EmoReady *ZeroEmoReady(){
  struct EmoReady *New=(struct EmoReady *)malloc(sizeof(ERTemplate));
  New->Sentence=NULL;
  New->EmoTB=NULL;
  New->EmoTA=NULL;
  New->EmoTU=NULL;
  New->EmoTD=NULL;
  New->Empathetic_Targets=0;
  New->Empathetic_Target_List=NULL;
  return New;
}

/*! \brief Populate the ConceptE structure with sensible defaults.
 *
 */
struct ConceptE *PopConceptE(struct ConceptE *Blank,struct List_Str *LastSentence){
  int _=0,A=0;
  struct List_Str *NoEmotion=NULL;
  A=Size_of_List(Str2List(Lookup_DB_Attr(GetLang(),":emotion",NULL)));
  for(_=0;_<A;_++)
    NoEmotion=Ins_List_Element(NoEmotion,"0",_);
  Blank->EmoTB=NoEmotion;
  Blank->EmoTA=NoEmotion;
  Blank->EmoTU=NoEmotion;
  Blank->EmoTD=VectorSub(Blank->EmoTA,Blank->EmoTB);
  if(LastSentence){
    Blank->AfterSize=1;
    SentenceEmotion(LastSentence,NULL);
    Blank->AConcepts=(struct List_Str **)malloc(sizeof(struct List_Str *));
    Blank->AConcepts[0]=Ins_List_Element(NULL,List2Str(LastSentence),0);
    Blank->EmoAConcepts=(struct List_Str **)malloc(sizeof(struct List_Str *));
    Blank->EmoAConcepts[0]=Ins_List_Element(NULL,List2Str(ANSWER),0);
    Blank->EmoTA=ANSWER;
  }
  return Blank;
}

/*! \brief Populate the PopEmoReady structure with sensible defaults.
 *
 */
struct EmoReady *PopEmoReady(struct EmoReady *Blank,struct List_Str *LastSentence,struct List_Str *Topics){
  int _=0;
  struct List_Str *Buffer=NULL;
  Blank->Sentence=LastSentence;
  Blank->Empathetic_Targets=Size_of_List(Topics);
  Blank->Empathetic_Target_List=(struct ConceptE **)malloc((Blank->Empathetic_Targets)*sizeof(struct ConceptE *));
  for(_=0;_<Blank->Empathetic_Targets;_++)
    Blank->Empathetic_Target_List[_]=NULL;   
  for(Buffer=Str2List(Lookup_DB_Attr(GetLang(),":emotion",NULL));Buffer;Buffer=Buffer->Next){
    Blank->EmoTB=Ins_List_Element(Blank->EmoTB,"0",0);
    Blank->EmoTA=Ins_List_Element(Blank->EmoTA,"0",0);
    Blank->EmoTU=Ins_List_Element(Blank->EmoTU,"0",0);
    Blank->EmoTD=Ins_List_Element(Blank->EmoTD,"0",0);
  }
  return Blank;
}

/*! \brief Determine the level of understanding of a sentence.
 *
 */
struct List_Str *EmoUnderstanding(struct EmoReady *EmpData,struct List_Str *EmoData){
  int Response=0;
  char *CSNUM=0,*PatternName=NULL;
  struct List_Str *AddedSentence=NULL,*VerbBlock=NULL,*Question=NULL;
  struct Sentence *Sentence=ConvertSentence(EmpData->Sentence,0,0);
  puts("DEBUG EmoUnderstanding");
  /* need to determine if the modifying sentence has a pattern associated with it 
     if it does work out whether the new sentence makes sense */
  AddedSentence=EmpData->Sentence;
  /* extract the verb part */

  /* :csaddr to recall context addr */
  CSAddr(VerbBlock,NULL);
  if(ANSWER){
    CSNUM=ANSWER->Str;
    if(!strncmp(CSNUM,"cs",2)){
      /* need to see if there is a method for this address */
      PatternName=StrCat("_enix_",CSNUM);
      if((Goto_DB_Entry(Database[0],PatternName))){
	/* Need to pose a question */
	Question=Ins_List_Element(AddedSentence,"did",0);
	Question=Ins_List_Element(Question,"?",Size_of_List(Question));
	
	IsMultiplexQuery(Sentence);
	/*
	Response=YNQWrapper(Sentence);
	*/
	/*
	Response=YNQWrapperWrapper(Sentence->S,Sentence->PV,Sentence->PN);
	*/
	if(Response){
	  Reason(Ins_List_Element(NULL,PatternName,0),NULL);
	}
	else{
	  puts("That makes no sense!");
	}
      }
      else{
	printf("Insufficient data on \"%s\"\n",List2Str(AddedSentence));
      }
    }
  }
  return NULL;
}

/*! \brief Determine the level of morality of a sentence.
 *
 */
struct List_Str  *EmoMorality(struct EmoReady *EmpData,struct List_Str *EmoData){
  float Total=0,C=0;
  double Angle=0,Old=10;
  struct List_Str *Buffer=NULL,*Sentences=NULL,*ThisSentence=NULL,*TMP=NULL,*Closest=NULL;

  puts("DEBUG EmoMorality");
  
  for(Buffer=EmoData;Buffer;Buffer=Buffer->Next){
    C=atof(Buffer->Str);
    Total+=C;
  }
  if(Total>=0){
    /* if the total is negative then adjust it */
    /* find a list of sentences */
    ListSentences(CSList(),NULL);
    CS2Sentence(ANSWER,NULL);
    Sentences=ANSWER;
    for(Buffer=Sentences;Buffer;Buffer=Buffer->Next){
      ThisSentence=Str2List(Buffer->Str);
      SentenceEmotion(ThisSentence,NULL);
      Equivalence(TMP=ANSWER,Str2List("0"));
      if(ANSWER->Str[0]=='0'){
	/* Note that opposite vectors can have zero angle between them! */
	Angle=ScalarProduct(TMP,EmoData);
	Angle=(Angle<0)?-1*Angle:Angle;
	if(Angle<Old){
	  Closest=ThisSentence;
	}
      }
    }
    PrintList(Closest);
    return Closest;
  }
  else{
    /* if the total is positive then dont adjust it */
    return NULL;
  }
  return NULL;
}

/*! \brief Determine the level of mortality of a sentence.
 *
 */
struct List_Str  *EmoMortality(struct EmoReady *EmpData,struct List_Str *EmoData){
  float ThirdDiffC=0,ThirdSEC=0;
  struct List_Str *Sentences=NULL,*Buffer=NULL,*ThisSentence=NULL;
  puts("DEBUG EmoMortality");
  /* At this point the Emotion vector shows a mortality component
   possibly the easier thing is to search for something with a conpensatory component */
  ListSentences(CSList(),NULL);
  CS2Sentence(ANSWER,NULL);
  Sentences=ANSWER;
  ThirdDiffC=atof(Get_List_Element(EmoData,2));
  for(Buffer=Sentences;Buffer;Buffer=Buffer->Next){
    ThisSentence=Str2List(Buffer->Str);
    SentenceEmotion(ThisSentence,NULL);
    if(strcmp(List2Str(ANSWER),"?"))
      ThirdSEC=atof(Get_List_Element(ANSWER,2));
    else
      ThirdSEC=0;
    if((ThirdDiffC+66.66666>ThirdSEC)&&(ThirdDiffC-66.66666<ThirdSEC)){
      PrintList(ThisSentence);
    }
  }
  return NULL;
}

/*! \brief Determine the level of action of a sentence.
 *
 */
struct List_Str *EmoAction(struct EmoReady *EmpData,struct List_Str *EmoData){
  float Action=0;
  int Argument=0,SentenceNum=0;
  struct List_Str *Sentence=NULL,*Conversation=NULL,*LastSentence=NULL,*AllSentences=NULL,*Buffer=NULL,*Final=NULL;
  struct ConceptE *Reason=NULL;
  printf("DEBUG EmoAction: ");
  PrintList(EmoData);

  /* the point of this is motivate the user "Can you do x ?" */
  LastSentence=RecPrevSentence(0);
  if(!strcmp(List2Str(LastSentence),List2Str(EmpData->Sentence))){
    LastSentence=RecPrevSentence(1);
  }

  Action=atof(Get_List_Element(EmoData,3));

  if(Action==0){
    puts("DEBUG EmoAction 2: NO ACTION REQUIRED");
    return NULL;
  }

  /* action is required */
  /* need to work out the first action that the action needs to be based on */
  
  for(Argument=0;Argument<EmpData->Empathetic_Targets;Argument++){
    Reason=EmpData->Empathetic_Target_List[Argument];
    for(SentenceNum=0;SentenceNum<Reason->BeforeSize;SentenceNum++){
      Conversation=Reason->BConcepts[SentenceNum];
      for(Sentence=Conversation;Sentence;Sentence=Sentence->Next)
	AllSentences=Add2Set(AllSentences,Sentence->Str);
    }
  }
  if(Action==-100){
    puts("DEBUG EmoAction 3: PREVENTATIVE ACTION REQUIRED");
    for(;AllSentences;AllSentences=AllSentences->Next){
      Sentence=Str2List(AllSentences->Str);
      NLPAvoidWrap(Sentence,LastSentence);
      for(Buffer=ANSWER;Buffer;Buffer=Buffer->Next)
	Final=Add2Set(Final,Buffer->Str);
    }
  }
  if(Action==100){
    puts("DEBUG EmoAction 4: ACTION REQUIRED");
    for(;AllSentences;AllSentences=AllSentences->Next){
      Sentence=Str2List(AllSentences->Str);
      NLPCauseWrap(Sentence,LastSentence);
      for(Buffer=ANSWER;Buffer;Buffer=Buffer->Next)
	Final=Add2Set(Final,Buffer->Str);
    }
  }
  PrintListSpecial("",Final,"\n","\n","\n");

  return NULL;
}

/*! \brief Determine the level of determination of a sentence.
 * - Incomplete
 */
struct List_Str  *EmoDetermination(struct EmoReady *EmpData,struct List_Str *EmoData){
  puts("DEBUG EmoDetermination");
  /* assess the urgency of action */

  /*
  atof(Get_List_Element(EmoData,4));
  */

  return NULL;
}

/*! \brief Compute the emotional response required. 
 * - Incomplete
 */
void ComputeEmoResp(struct EmoReady *EmpData,struct List_Str *EmoDiff){
  int Function=0;
  char *Str=NULL;
  struct List_Str *Normalised=NormalizedEmo(EmoDiff),*Buffer=NULL,*Output=NULL,*Final=NULL;
  
  puts("DEBUG ComputeEmoResp 1");
  puts("----------------------");

  /* <COMMENT> EMOTION TYPES: understanding morality mortality action determination */
  /* Cycles through all the operators */

  /* Incomplete!! */

  for(Buffer=Normalised;Buffer;Buffer=Buffer->Next){
    Output=EmoProc[Function](EmpData,Normalised);
    if(Output){
      Str=List2Str(Output);
      
      Final=Add2Set(Final,Str);
    }
    Function++;
  }

}

/*! \brief Determines the emotional response required to get user mood into target mood.
 * 
 */
void EvalResponse(struct EmoReady *EmpData,char *EmoResponse){
  int Found=0;
  int A=0,B=0,C=0;
  char *Mood=NULL,*CurrentEmo=NULL;
  struct List_Str *Sentences=NULL,*Buffer=NULL,*MoodEmoVec=NULL,*OutcomeEmoVec=NULL,*DiffEmo=NULL;
  struct ConceptE *CE=NULL;
  
  Mood=Lookup_DB_Attr(GetLang(),":mood",NULL);
  if((!EmoResponse)||(!Mood)){
    if(ThinkOutLoud)
      printf("%s:%d either EmoResponse or Mood is undefined!\n",__FILE__,__LINE__);
    return ;
  }

  /* Outcome 1: Is the sentence S equal to M ? */
  SentenceEmotion(EmpData->Sentence,NULL);
  if(!strcmp(ReportEmotionName(ANSWER),Mood)){
    puts("Outcome 1:");
    puts(":)");
    return;
  }
    
  /* Outcome 2: Is the emotional outcome of Oa equal to M ? */
  if(!strcmp(EmoResponse,Mood)){
    puts("Outcome 2:");
    /* need to remind the user of the Oa state */
    Found=0;
    for(A=0;A<EmpData->Empathetic_Targets;A++){
      CE=EmpData->Empathetic_Target_List[A];
      if(CE){
	for(B=0;B<CE->AfterSize;B++)
	  for(Buffer=CE->AConcepts[B];Buffer;Buffer=Buffer->Next)
	    if(!Is_List_Element(Sentences,Buffer->Str)){
	      Sentences=Ins_List_Element(Sentences,Buffer->Str,C++);
	      Found=1;
	    }
      }
    }
    /* this needs to be cleaned up */
    if(Found){
      PrintListSpecial("-> [",Sentences,"]\n   [","]\n   [","]\n");
      return;
    }
  }

  /* Outcome 3: Report the sentences in Oa that can be mapped to M ? */
  C=0;
  Sentences=NULL;
  for(A=0;A<EmpData->Empathetic_Targets;A++){
    CE=EmpData->Empathetic_Target_List[A];
    if(CE){
      for(B=0;B<CE->AfterSize;B++)
	for(Buffer=CE->AConcepts[B];Buffer;Buffer=Buffer->Next){
	  if(!Is_List_Element(Sentences,Buffer->Str)){
	    SentenceEmotion(Str2List(Buffer->Str),NULL);
	    if(!strcmp(ReportEmotionName(ANSWER),Mood))
	      Sentences=Ins_List_Element(Sentences,Buffer->Str,C++);
	  }
	}
    }
  }
  if(Sentences){
    puts("Outcome 3:");
    PrintListSpecial("-> [",Sentences,"]\n   [","]\n   [","]\n");
    return;
  }

  /* Outcome 4: find sentences that can map the user E to M ? */
  C=0;
  Sentences=NULL;
  CurrentEmo=EmoTableLookup(EmoResponse,NULL,Mood);
  for(A=0;A<EmpData->Empathetic_Targets;A++){
    CE=EmpData->Empathetic_Target_List[A];
    if(CE){
      for(B=0;B<CE->AfterSize;B++)
	for(Buffer=CE->AConcepts[B];Buffer;Buffer=Buffer->Next){
	  if(!Is_List_Element(Sentences,Buffer->Str)){
	    SentenceEmotion(Str2List(Buffer->Str),NULL);
	    if(!strcmp(ReportEmotionName(ANSWER),CurrentEmo))
	      Sentences=Ins_List_Element(Sentences,Buffer->Str,C++);
	  }
	}
    }
  }
  if(Sentences){
    puts("Outcome 4:");
    PrintListSpecial("-> [",Sentences,"]\n   [","]\n   [","]\n");
    return;
  }

  /* Outcome 5: Looking for a sentence outside of the topic of conversation whose emotion will map the user mood into the 
    system mood! */
  /* find a list of sentences that aren't in the topic */
  Sentences=SenOutTopic();
  for(Buffer=Sentences;Buffer;Buffer=Buffer->Next){
    SentenceEmotion(Str2List(Buffer->Str),NULL);
    CurrentEmo=ReportEmotionName(ANSWER);
    if(EmoTableLookup(CurrentEmo,NULL,Mood)){
      puts("Outcome 5:");
      printf("->[%s]\n",Buffer->Str);
      return ;
    }
  }

  /* Outcome 6: Work out corrective action by deducting the Oa from the M and working out corrective actions */  
  Emo2Vec(Ins_List_Element(NULL,Mood,0),NULL);
  MoodEmoVec=ANSWER;
  Emo2Vec(Ins_List_Element(NULL,EmoResponse,0),NULL);
  OutcomeEmoVec=ANSWER;

  printf("M    : "); PrintList(MoodEmoVec);
  printf("Oa   : "); PrintList(OutcomeEmoVec);

  DiffEmo=VectorSub(MoodEmoVec,OutcomeEmoVec);

  printf("Delta: ");
  PrintList(DiffEmo);

  puts("Outcome 6:");
  ComputeEmoResp(EmpData,DiffEmo);

}

/*! \brief Calculate what emotion the response has to have.
 * 
 */
struct List_Str *ComputeOOa(char *EmotionName){
  int Found=0,Pos=0;
  struct List_Str *Buffer=NULL,*R=NULL;
  ListSentences(CSList(),NULL);
  FindEmoSentence(ANSWER,Str2List(EmotionName));
  if(ANSWER){
    if(!strcmp(ANSWER->Str,":null")){
      return NULL;
    }
    else{
      CS2Sentence(ANSWER,NULL);
      for(Buffer=ANSWER;Buffer;Buffer=Buffer->Next){
	SentenceEmotion(Str2List(Buffer->Str),NULL);
	Vec2Emo(ANSWER,NULL);
	if(!strcmp(ANSWER->Str,EmotionName)){
	  R=Ins_List_Element(R,Buffer->Str,Pos++);
	  Found=1;
	}
      }
      if(!Found){
	return NULL;
      }
    }
  }
  else
    return NULL;
  return R;
}

/*! \brief Convert an emotion vector into an emotion name.
 * 
 */
struct List_Str  *Vec2Emo(struct List_Str *Word_List,struct List_Str *L){
  char *Str=NULL;
  if((Str=ReportEmotionName(Word_List)))
    ANSWER=Ins_List_Element(NULL,Str,0);
  return L;
}

/*! \brief Search the database for sentences with a required emotion.
 * 
 */
struct List_Str  *FindEmoSentence(struct List_Str *Word_List,struct List_Str *L){
  int Found=0,Pos=0;
  char *EmotionName=NULL;
  struct List_Str *B1=NULL,*B2=NULL,*Buffer=NULL,*Result=NULL;
  /* use :sentenceemotion command to determine the emotion of the sentence */
  for(B1=Word_List;B1;B1=B1->Next){
    CS2Sentence(Ins_List_Element(NULL,B1->Str,0),NULL);
    Buffer=ANSWER;
    Found=0;
    for(B2=Buffer;B2;B2=B2->Next){
      SentenceEmotion(Str2List(B2->Str),NULL);
      EmotionName=ReportEmotionName(ANSWER);
      if(EmotionName)
	Found=!strcmp(EmotionName,L->Str);
      if(Found) break;
    }
    if(Found)
      Result=Ins_List_Element(Result,B1->Str,Pos++);    
  }
  if(Result)
    ANSWER=Result;
  else
    ANSWER=Str2List(":null");
  return L->Next;
}

/*! \brief This function injects emotions into the empathy pipeline so that behaviour can be tested easily.
 *  - For debugging only.
 */
struct List_Str  *EmpathyInj(struct List_Str *Word_List,struct List_Str *L){
  int _=0,B=0,C=0;
  char *Data=NULL;
  struct List_Str *Buffer=NULL,*EmoList=NULL;
  struct ConceptE *Delta=NULL;
  /*
    M   = Mood of ENiX
    E   = EmoReady->EmoTA (emotion afterwards)
    D   = Difference between after and before
    OOa = Emotion response
    Oj  = CE->EmoAConcepts[x] Data
    Oi  = CE->EmoAConcepts[x] Emotion name
    Ok  = Correctable Data
    CorrectiveMoodList = changes required to users emotion to get it to M
  */
  PrintListSpecial("Injecting: ", Word_List," "," "," [D E Oi] :EMPATHYINJ\n");
  puts("D  = Resultant difference");
  puts("E  = After concept emotion");
  puts("Oi = Resultant afterwards");
  
  if(Size_of_List(Word_List)!=3){
    puts("List incorrect (See above)! ");
    return L;
  }
  for(Buffer=Word_List;Buffer;Buffer=Buffer->Next){
    Data=Get_DB_Entry(Goto_DB_Entry(Database[1],Buffer->Str),0,3);
    EmoList=Ins_List_Element(EmoList,Data,_++);
  }
  /* Populates the D */
  EmpatheticSummary->EmoTD=Str2List(EmoList->Str);
  if(ThinkOutLoud){
    printf("D: "); PrintList(EmpatheticSummary->EmoTD);
  }
  /* Populates the E */
  EmpatheticSummary->EmoTA=Str2List(EmoList->Next->Str);
  if(ThinkOutLoud){
    printf("E: "); PrintList(EmpatheticSummary->EmoTA);
  }
  for(_=0;_<EmpatheticSummary->Empathetic_Targets;_++){
    Delta=EmpatheticSummary->Empathetic_Target_List[_];
    if(Delta){
      if(ThinkOutLoud)
	printf("Path %d, Data: %d sections\n",_,Delta->AfterSize);
      for(C=0;C<Delta->AfterSize;C++){
	if(ThinkOutLoud)
	  PrintListSpecial("Before: [",Delta->EmoAConcepts[C],"][","][","]\n");
	Buffer=NULL;
	for(B=0;B<Size_of_List(Delta->EmoAConcepts[C]);B++)
	  Buffer=Ins_List_Element(Buffer,EmoList->Next->Next->Str,B);
	Delta->EmoAConcepts[C]=Buffer;
	if(ThinkOutLoud)
	  PrintListSpecial("After:  [",Delta->EmoAConcepts[C],"][","][","]\n");
      }
    }
  }
  /* need to flush back to the pipeline */
  FlushEmoDB(EmpatheticSummary);
  return L;
}

/*! \brief Works out the behaviour required for a response.
 *  
 */
struct List_Str  *EmpathyPost(struct List_Str *Word_List,struct List_Str *L){
  char *ResponseEmo=NULL;
  ResponseEmo=EmotionCPU(3,EmpatheticSummary);
  /* may need to tweek the first parameter for testing */
  EvalResponse(EmpatheticSummary,ResponseEmo);
  return L;
}

/*! \brief Wraps the empathy processing in a concise function call.
 *  
 */
struct List_Str  *EmpathyWrapper(struct List_Str *Word_List,struct List_Str *L){
  int _=0,Pos=0;
  struct List_Str *Buffer=NULL,*Topics=NULL,*Buffer2=NULL,*SubjectTopic=NULL,*RegisteredEmos=NULL;
  struct Datablock *DB=NULL;
  struct ConceptE *E=NULL;

  ENABLEOUT=0;
  Topic(NULL,NULL);
  ENABLEOUT=1;
  Topics=ANSWER;
  if((DB=Goto_DB_Entry(Database[1],":emotionlist")))
    RegisteredEmos=Str2List(Get_DB_Entry(DB,0,7));
  else
    RegisteredEmos=NULL;
  EmpatheticSummary=PopEmoReady(ZeroEmoReady(),Word_List,Topics);
  for(Buffer=Topics;Buffer;Buffer=Buffer->Next){
    _=0;
    SubjectTopic=NULL;
    for(Buffer2=Str2List(Buffer->Str);Buffer2;Buffer2=Buffer2->Next){
      if(IsArticle(Buffer2->Str,"noun"))
	SubjectTopic=Ins_List_Element(SubjectTopic,Buffer2->Str,_++);
      if(IsArticle(Buffer2->Str,"adjective"))
	if(!Is_List_Element(RegisteredEmos,Buffer2->Str))
	  SubjectTopic=Ins_List_Element(SubjectTopic,Buffer2->Str,_++);
    }
    if(ThinkOutLoud){
      PrintListSpecial("Attempting to empathise with: [",SubjectTopic,"][","][","]; via: ");
      PrintList(Word_List);
    }

    /* code is correct down to here */
    E=Empathy(Word_List,SubjectTopic);
    if(E){
      if(ThinkOutLoud)
	DebugCE(E);
      EmpatheticSummary->Empathetic_Target_List[Pos++]=E;
      EmpatheticSummary->EmoTB=VectorAdd(EmpatheticSummary->EmoTB,E->EmoTB);
      EmpatheticSummary->EmoTA=VectorAdd(EmpatheticSummary->EmoTA,E->EmoTA);
      EmpatheticSummary->EmoTU=VectorAdd(EmpatheticSummary->EmoTU,E->EmoTU);
      EmpatheticSummary->EmoTD=VectorAdd(EmpatheticSummary->EmoTD,E->EmoTD);
    }
  }
  FlushEmoDB(EmpatheticSummary);
  /*
  DebugEmotionCache(NULL,NULL);
  */
  return L;
}

/*! \brief Provides the emotion name that the response has to take.
 *  
 */
char *EmotionCPU(int Type,struct EmoReady *E){
   char *Mood=NULL,*ResultEmotionName=NULL,*LookedUp=NULL,*GetHookExec=NULL;
   struct List_Str *EmotionVector=NULL,*EmotionList=NULL,*Buffer=NULL;
   struct Datablock *DB=NULL;
   struct List_Str *Ordinates=NULL,*Ref_Ordinates=NULL;
   if(Type==0) EmotionVector=E->EmoTB;
   if(Type==1) EmotionVector=E->EmoTA;
   if(Type==2) EmotionVector=E->EmoTU;
   if(Type==3) EmotionVector=E->EmoTD;
   EmotionList=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],":emotionlist"),0,7));
   Mood=Lookup_DB_Attr(GetLang(),":mood",NULL);
   if(!strcmp(Mood,"?")){
      if(ThinkOutLoud)
	puts("Warning, no mood.");
      Mood=NULL;
      return NULL;
   }
   Ordinates=NormalizedEmo(EmotionVector);   
   for(Buffer=EmotionList;Buffer;Buffer=Buffer->Next){
      Ref_Ordinates=NormalizedEmo(Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],Buffer->Str),0,3)));
      if(!strcmp(List2Str(Ref_Ordinates),List2Str(Ordinates)))
	ResultEmotionName=Buffer->Str;	 
   }
   if(!ResultEmotionName)
     ResultEmotionName="neutral";
   if((DB=Goto_DB_Entry(Database[0],StrCat(":Cache_",Mood))))
      LookedUp=Lookup_DB_Attr(DB,ResultEmotionName,NULL);
   if(ThinkOutLoud)
     printf("System mood: %s, User mood: %s, Response: %s\n",Mood,ResultEmotionName,LookedUp);
   if(LookedUp)
     if((GetHookExec=Lookup_DB_Attr(Goto_DB_Entry(Database[1],LookedUp),":hook",NULL)))
       IntelligentInt(Str2List(GetHookExec),1);
   return LookedUp;
}

/*! \brief Find the emotion pathways.
 *  
 */
struct List_Str *EmotionPathway(char *Start,char *Finish,struct List_Str *AvailableMoods,struct List_Str *Visited){
  struct Datablock *DB=NULL;
  struct List_Str  *Buffer=NULL,*R=NULL,**PathList=NULL;
  int              _=0,Pos=0,Element=0,Size=0,Found=-1;
  if(ThinkOutLoud){
    printf("\nStart: [%s] Finish: [%s]\n",Start,Finish);
    printf("Moods: [%s] Visited: [%s]\n",List2Str(AvailableMoods),List2Str(Visited));
  }
  if(!AvailableMoods)
    for(DB=Database[0];DB;DB=DB->Next)      
      if((!strncmp(DB->DS[0]->Str,":Cache_",7))&&(DB->DS[1]))
	AvailableMoods=Ins_List_Element(AvailableMoods,DB->DS[0]->Str,0);
  if(!AvailableMoods)
    return NULL;
  if(Is_List_Element(Goto_DB_Entry(Database[0],StrCat(":Cache_",Finish))->DS[1],Start))
    return Ins_List_Element(NULL,Finish,0);
  for(Buffer=AvailableMoods;Buffer;Buffer=Buffer->Next){
    if((_=Find_List_Element((DB=Goto_DB_Entry(Database[0],Buffer->Str))->DS[1],Start))+1)
      if((R=EmotionPathway(Buffer->Str+7,Finish,Del_List_Element(Cpy_List(AvailableMoods),Pos),Ins_List_Element(Visited,Start,0))))
	PathList=Add_To_Array(PathList,Ins_List_Element(R,Buffer->Str+7,0),Element++);
    Pos++;
  }
  for(Pos=0;Pos<Element;Pos++)
    if((_=Size_of_List(PathList[Pos]))){
      if(_){
	if(Found==-1){
	  Size=_;
	  Found=Pos;
	}
	else
	  if(_<Size){
	    Size=_;
	    Found=Pos;
	  }
      }
    }
  if(Found>-1)
    R=PathList[Found];
  return R;
}

/*! \brief Load the emotions from the :EMOTIONPIPELINE record into global scope.
 *  
 */
void LoadEmoDB(){
  int _=0;
  char *Data=NULL;
  struct List_Str *Concepts=NULL; 
  struct Datablock *DB=NULL;
  if((DB=Goto_DB_Entry(Database[1],":EMOTIONPIPELINE"))){
    EmpatheticSummary=ZeroEmoReady();
    Data=Get_DB_Entry(DB,0,7);
    if(strcmp(Data,"?")){
      EmpatheticSummary->Empathetic_Targets=Size_of_List(Concepts=Str2List(Data));
      EmpatheticSummary->Empathetic_Target_List=(struct ConceptE **)malloc(_*sizeof(struct ConceptE *));
      for(_=0;_<EmpatheticSummary->Empathetic_Targets;_++){
	EmpatheticSummary->Empathetic_Target_List[_]=LoadConceptE(Get_List_Element(Concepts,_));	  
	if(!EmpatheticSummary->Empathetic_Target_List[_])
	  if(ThinkOutLoud)
	    puts("DEBUG LoadEmoDB 1, No Empathetic_Target_List!!");
      }
    }
    if((Data=Lookup_DB_Attr(DB,":EmoTB",NULL)))
      EmpatheticSummary->EmoTB=Str2List(Data);
    if((Data=Lookup_DB_Attr(DB,":EmoTA",NULL)))
      EmpatheticSummary->EmoTA=Str2List(Data);
    if((Data=Lookup_DB_Attr(DB,":EmoTU",NULL)))
      EmpatheticSummary->EmoTU=Str2List(Data);
    if((Data=Lookup_DB_Attr(DB,":EmoTD",NULL)))
      EmpatheticSummary->EmoTD=Str2List(Data);
    EmpatheticSummary->Sentence=Str2List(Get_DB_Entry(DB,0,1));
  }
}

/*! \brief Populate ConceptE structure with emotion and semantic data.
 *  
 */
struct ConceptE *LoadConceptE(char *Name){
  int _=0,Found=1,C=0;
  char *Data=NULL,AName[16];
  struct List_Str *Cardinalities=NULL;
  struct Datablock *DB=NULL;
  struct ConceptE *E=NULL;
  E=ZeroConceptE();
  if((DB=Goto_DB_Entry(Database[1],Name))){
    Data=Get_DB_Entry(DB,0,7);
    if(strcmp(Data,"?")){
      Cardinalities=Str2List(Data);
      E->BeforeSize    = atoi(Get_List_Element(Cardinalities,0));
      E->AfterSize     = atoi(Get_List_Element(Cardinalities,1));
      E->UnchangedSize = atoi(Get_List_Element(Cardinalities,2));
      if((Data=Lookup_DB_Attr(DB,":EmoTB",NULL)))
	E->EmoTB=Str2List(Data);
      if((Data=Lookup_DB_Attr(DB,":EmoTA",NULL)))
	E->EmoTA=Str2List(Data);
      if((Data=Lookup_DB_Attr(DB,":EmoTU",NULL)))
	E->EmoTU=Str2List(Data);
      if((Data=Lookup_DB_Attr(DB,":EmoTD",NULL)))
	E->EmoTD=Str2List(Data);
      /* note this has been changed and may not be right: */
      E->BConcepts=(struct List_Str **)malloc(E->BeforeSize*sizeof(struct List_Str *));
      E->AConcepts=(struct List_Str **)malloc(E->AfterSize*sizeof(struct List_Str *));
      E->UConcepts=(struct List_Str **)malloc(E->UnchangedSize*sizeof(struct List_Str *));
      E->EmoBConcepts=(struct List_Str **)malloc(E->BeforeSize*sizeof(struct List_Str *));
      E->EmoAConcepts=(struct List_Str **)malloc(E->AfterSize*sizeof(struct List_Str *));
      E->EmoUConcepts=(struct List_Str **)malloc(E->UnchangedSize*sizeof(struct List_Str *));
      for(_=0;_<E->BeforeSize;_++){
	Found=1;
	E->BConcepts[_]=NULL;
	E->EmoBConcepts[_]=NULL;
	for(C=0;Found;C++){
	  memset(AName,0,16);
	  sprintf(AName,":BC-%05d-%05d",_,C);
	  if(Is_List_Element(DB->DS[1],AName)){
	    Data=Lookup_DB_Attr(DB,AName,NULL);
	    E->BConcepts[_]=Ins_List_Element(E->BConcepts[_],Data,C);
	    memset(AName,0,16);
	    sprintf(AName,":EBC%05d-%05d",_,C);
	    Data=Lookup_DB_Attr(DB,AName,NULL);
	    E->EmoBConcepts[_]=Ins_List_Element(E->EmoBConcepts[_],Data,C);
	  }
	  else
	    Found=0;
	}
      }
      for(_=0;_<E->AfterSize;_++){
	Found=1;
	E->AConcepts[_]=NULL;
	E->EmoAConcepts[_]=NULL;
	for(C=0;Found;C++){
	  memset(AName,0,16);
	  sprintf(AName,":AC-%05d-%05d",_,C);
	  if(Is_List_Element(DB->DS[1],AName)){
	    Data=Lookup_DB_Attr(DB,AName,NULL);
	    E->AConcepts[_]=Ins_List_Element(E->AConcepts[_],Data,C);
	    memset(AName,0,16);
	    sprintf(AName,":EAC%05d-%05d",_,C);
	    Data=Lookup_DB_Attr(DB,AName,NULL);
	    E->EmoAConcepts[_]=Ins_List_Element(E->EmoAConcepts[_],Data,C);
	  }
	  else
	    Found=0;
	}
      }
      for(_=0;_<E->UnchangedSize;_++){
	Found=1;
	E->UConcepts[_]=NULL;
	E->EmoUConcepts[_]=NULL;
	for(C=0;Found;C++){
	  memset(AName,0,16);
	  sprintf(AName,":UC-%05d-%05d",_,C);
	  if(Is_List_Element(DB->DS[1],AName)){
	    Data=Lookup_DB_Attr(DB,AName,NULL);
	    E->UConcepts[_]=Ins_List_Element(E->UConcepts[_],Data,C);
	    memset(AName,0,16);
	    sprintf(AName,":EUC%05d-%05d",_,C);
	    Data=Lookup_DB_Attr(DB,AName,NULL);
	    E->EmoUConcepts[_]=Ins_List_Element(E->EmoUConcepts[_],Data,C);
	  }
	  else
	    Found=0;
	}
      }
    }
    else
      return NULL;
  }
  else
    if(ThinkOutLoud)
      printf("Warning [LoadConceptE]: DB inconsistency cannot find [%s]\n",Name);
  return E; 
}

/*! \brief Write ConceptE structure data to the database.
 *  
 */
void FlushConceptE(char *Name,struct ConceptE *E){
  int _=0,C=0;
  char AName[16];
  struct Datablock *DB=NULL;
  struct List_Str *Dimensions=NULL,*Buffer=NULL;
  if(!E){
    /* need to insert event handling here */
    if(!(DB=Goto_DB_Entry(Database[1],Name)))
      DB=Database[1]=Add_DB_Entry(Database[1],Name);    
    return;
  }
  /* create the concept if it doesnt exist */
  if(!(DB=Goto_DB_Entry(Database[1],Name)))
    DB=Database[1]=Add_DB_Entry(Database[1],Name);
  /* Clear out the concept */
  DB->DS[1]=NULL;
  DB->DS[2]=NULL;
  Rep_DB_Entry(DB,0,7,"?");
  /* set the cardinalities */
  Dimensions=Ins_List_Element(Ins_List_Element(Ins_List_Element(NULL,FloatToString(E->UnchangedSize),0),FloatToString(E->AfterSize),0),FloatToString(E->BeforeSize),0);
  Rep_DB_Entry(DB,0,7,List2Str(Dimensions));
  /* set summary emotions */
  Rep_DB_Pair(DB,":EmoTB",List2Str(E->EmoTB));
  Rep_DB_Pair(DB,":EmoTA",List2Str(E->EmoTA));
  Rep_DB_Pair(DB,":EmoTU",List2Str(E->EmoTU));
  Rep_DB_Pair(DB,":EmoTD",List2Str(E->EmoTD));    
  /* Save data and emotion pipelines */
  for(_=0;_<E->BeforeSize;_++){
    C=0;
    for(Buffer=E->BConcepts[_];Buffer;Buffer=Buffer->Next){
      memset(AName,0,16);
      sprintf(AName,":BC-%05d-%05d",_,C);
      Rep_DB_Pair(DB,StrCat("",AName),Get_List_Element(E->BConcepts[_],C));
      memset(AName,0,16);
      sprintf(AName,":EBC%05d-%05d",_,C);
      Rep_DB_Pair(DB,StrCat("",AName),Get_List_Element(E->EmoBConcepts[_],C++));
    }
  }
  for(_=0;_<E->AfterSize;_++){
    C=0;
    for(Buffer=E->AConcepts[_];Buffer;Buffer=Buffer->Next){
      memset(AName,0,16);
      sprintf(AName,":AC-%05d-%05d",_,C);
      Rep_DB_Pair(DB,StrCat("",AName),Get_List_Element(E->AConcepts[_],C));
      memset(AName,0,16);
      sprintf(AName,":EAC%05d-%05d",_,C);
      Rep_DB_Pair(DB,StrCat("",AName),Get_List_Element(E->EmoAConcepts[_],C++));
    }
  }
  for(_=0;_<E->UnchangedSize;_++){
    C=0;
    for(Buffer=E->UConcepts[_];Buffer;Buffer=Buffer->Next){
      memset(AName,0,16);
      sprintf(AName,":UC-%05d-%05d",_,C);
      Rep_DB_Pair(DB,StrCat("",AName),Get_List_Element(E->UConcepts[_],C));
      memset(AName,0,16);
      sprintf(AName,":EUC%05d-%05d",_,C);
      Rep_DB_Pair(DB,StrCat("",AName),Get_List_Element(E->EmoUConcepts[_],C++));
    }
  }
}

/*! \brief Write all emotion data to the database.
 *  
 */
void FlushEmoDB(struct EmoReady *E){
  struct Datablock *DB=NULL;
  struct List_Str *ConceptList=NULL;
  char *Name_Prefix=":CONCEPT_E_",*Name=NULL,Number[6];
  int _=0,Targets=0;
  /* need to create emotion pipeline datablock */
  if(!(DB=Goto_DB_Entry(Database[1],":EMOTIONPIPELINE")))
    DB=Database[1]=Add_DB_Entry(Database[1],":EMOTIONPIPELINE");
  /*  need to find out how many empathy targets to record  */
  if(E){
    /* clear the data */
    DB->DS[1]=NULL;
    DB->DS[2]=NULL;
    Rep_DB_Entry(DB,0,7,"?");
    /* need to extract */
    if((Targets=E->Empathetic_Targets)){
      for(_=0;_<Targets;_++){
	memset(Number,0,6);
	sprintf(Number,"%05d",_);
	Name=StrCat(Name_Prefix,Number);
	FlushConceptE(Name,E->Empathetic_Target_List[_]);
	ConceptList=Ins_List_Element(ConceptList,Name,0);
      }
      /* need to store the Empathetic_Target_List to 0 7 */
      Rep_DB_Entry(DB,0,7,List2Str(ConceptList));
    }
    Rep_DB_Pair(DB,":EmoTB",List2Str(E->EmoTB));
    Rep_DB_Pair(DB,":EmoTA",List2Str(E->EmoTA));
    Rep_DB_Pair(DB,":EmoTU",List2Str(E->EmoTU));
    Rep_DB_Pair(DB,":EmoTD",List2Str(E->EmoTD));
    Rep_DB_Entry(DB,0,1,List2Str(E->Sentence));
  }
}

/*! \brief Show the contents of the empathy data.
 *  - For debugging only.
 */
struct List_Str *EmpathyDebug(struct List_Str *Word_List,struct List_Str *L){
  DebugCE(GlobalE);
  return L;
}

/*! \brief Reconstruct a conversation from emotion.
 * 
 */
struct ConvList *ReconFromEmotion(struct EmoReady *EmpData,char *EmotionName,int Bitfield){
  /* Bitfield &1=before, &2=after, &4=unchanged, &8=difference */
   int _=0,C=0;
   struct ConceptE *ThisConcept=NULL;
   struct Meanings *Alpha=NULL;
   struct ConvList *R=(struct ConvList *)malloc(sizeof(CLTemplate));
   R->Size=0;
   R->Conversations=NULL;
   
   if(EmpData){
      for(_=0;_<EmpData->Empathetic_Targets;_++){
	 ThisConcept=EmpData->Empathetic_Target_List[_];

	 /* need to first of all check if any of the conversations have a particular emotional summary */
	 if(Bitfield&1){
	    Alpha=(struct Meanings *)malloc(sizeof(MeaningTemplate));
	    Alpha->Size=0;
	    Alpha->Conversations=NULL;
	    if(!strcmp(EmotionName,ReportEmotionName(ThisConcept->EmoTB))){
	       Alpha->Size=ThisConcept->BeforeSize;
	       Alpha->Conversations=ThisConcept->BConcepts;
	    }
	    else{
	       for(C=0;C<ThisConcept->BeforeSize;C++)
		 if(!strcmp(EmotionName,ReportEmotionName(ThisConcept->EmoBConcepts[C])))
		   Alpha->Conversations=Add_To_Array(Alpha->Conversations,ThisConcept->BConcepts[C],Alpha->Size++);
	    }
	    if(Alpha->Size){
	       if(R->Size)
		  R->Conversations=(struct Meanings **)realloc(R->Conversations,(R->Size+1)*sizeof(struct Meanings *));
	       else
		  R->Conversations=(struct Meanings **)malloc(sizeof(struct Meanings *));
	       R->Conversations[R->Size++]=Alpha;	       
	    }
	 }
	 if(Bitfield&2){
	    Alpha=(struct Meanings *)malloc(sizeof(MeaningTemplate));
	    Alpha->Size=0;
	    Alpha->Conversations=NULL;
	    if(!strcmp(EmotionName,ReportEmotionName(ThisConcept->EmoTA))){
	       Alpha->Size=ThisConcept->AfterSize;
	       Alpha->Conversations=ThisConcept->AConcepts;
	    }
	    else{
	       for(C=0;C<ThisConcept->AfterSize;C++)
		 if(!strcmp(EmotionName,ReportEmotionName(ThisConcept->EmoAConcepts[C])))
		   Alpha->Conversations=Add_To_Array(Alpha->Conversations,ThisConcept->AConcepts[C],Alpha->Size++);
	    }
	    if(Alpha->Size){
	       if(R->Size){
		  R->Conversations=(struct Meanings **)realloc(R->Conversations,(R->Size+1)*sizeof(struct Meanings *));
		  R->Conversations[R->Size]=Alpha;
		  R->Size++;
	       }
	       else{
		  R->Conversations=(struct Meanings **)malloc(sizeof(struct Meanings *));
		  R->Conversations[R->Size]=Alpha;
		  R->Size=1;
	       }
	    }
	 }
	 if(Bitfield&4){
	    Alpha=(struct Meanings *)malloc(sizeof(MeaningTemplate));
	    Alpha->Size=0;
	    Alpha->Conversations=NULL;
	    if(!strcmp(EmotionName,ReportEmotionName(ThisConcept->EmoTU))){	    
	       Alpha->Size=ThisConcept->UnchangedSize;
	       Alpha->Conversations=ThisConcept->UConcepts;
	    }
	    else{
	       for(C=0;C<ThisConcept->UnchangedSize;C++)
		 if(!strcmp(EmotionName,ReportEmotionName(ThisConcept->EmoUConcepts[C])))
		   Alpha->Conversations=Add_To_Array(Alpha->Conversations,ThisConcept->UConcepts[C],Alpha->Size++);
	    }
	    if(Alpha->Size){
	       if(R->Size){
		  R->Conversations=(struct Meanings **)realloc(R->Conversations,(R->Size+1)*sizeof(struct Meanings *));
		  R->Conversations[R->Size]=Alpha;
		  R->Size++;
	       }
	       else{
		  R->Conversations=(struct Meanings **)malloc(sizeof(struct Meanings *));
		  R->Conversations[R->Size]=Alpha;
		  R->Size=1;
	       }
	    }
	 }
	 if(Bitfield&8){
	    Alpha=(struct Meanings *)malloc(sizeof(MeaningTemplate));
	    Alpha->Size=0;
	    Alpha->Conversations=NULL;
	    if(!strcmp(EmotionName,ReportEmotionName(ThisConcept->EmoTD))){
	       
	    }
	    if(Alpha->Size){
	       if(R->Size){
		  R->Conversations=(struct Meanings **)realloc(R->Conversations,(R->Size+1)*sizeof(struct Meanings *));
		  R->Conversations[R->Size]=Alpha;
		  R->Size++;
	       }
	       else{
		  R->Conversations=(struct Meanings **)malloc(sizeof(struct Meanings *));
		  R->Conversations[R->Size]=Alpha;
		  R->Size=1;
	       }
	    }
	 }
	 
      }
   }
   
   /* need to do some debugging here */
   
   for(_=0;_<R->Size;_++)
     for(C=0;C<R->Conversations[_]->Size;C++){
	printf("%07dx%07d: ",_,C);
	PrintList(R->Conversations[_]->Conversations[C]);
     }
   return R;
}

/*! \brief Return an emotion name from an emotion vector.
 * 
 */
char *ReportEmotionName(struct List_Str *EmotionVector){
   struct List_Str *SpecifiedFeeling=NULL,*ThisFeeling=NULL;
   char *Str=NULL;
   struct List_Str *EmotionList=NULL,*Buffer=NULL,*ThisEmoVector=NULL;
   struct Datablock *DB=NULL;
   SpecifiedFeeling=NormalizedEmo(EmotionVector);
   DB=Goto_DB_Entry(Database[1],":emotionlist");
   if(!DB){
      puts("No emotion data!");
      return NULL;
   }
   EmotionList=Str2List(Get_DB_Entry(DB,0,7));
   for(Buffer=EmotionList;Buffer;Buffer=Buffer->Next){
      ThisEmoVector=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],Buffer->Str),0,3));
      ThisFeeling=NormalizedEmo(ThisEmoVector);
      if(!strcmp(List2Str(SpecifiedFeeling),List2Str(ThisFeeling)))
	Str=Buffer->Str;
   }
   return Str;
}

/*! \brief Debug all of the emotion cache.
 * - For debugging.
 */
struct List_Str *DebugEmotionCache(struct List_Str *Word_List,struct List_Str *L){
  int _=0;
  puts("Empathetic Data Summary:");
  puts("----------------------------------");
  puts("Operator sentence:");
  PrintList(EmpatheticSummary->Sentence);
  puts("");
  if(EmpatheticSummary){
    for(_=0;_<EmpatheticSummary->Empathetic_Targets;_++)
      if(EmpatheticSummary->Empathetic_Target_List[_]){	  
	printf("Semantic Path %d:\n",_);
	DebugCE(EmpatheticSummary->Empathetic_Target_List[_]);
	puts("");
      }
    puts("-[Resultant]----------------------");
    printf(" Before:     "); PrintList(EmpatheticSummary->EmoTB);
    printf(" After:      "); PrintList(EmpatheticSummary->EmoTA);
    printf(" Unchanged:  "); PrintList(EmpatheticSummary->EmoTU);
    printf(" Difference: "); PrintList(EmpatheticSummary->EmoTD);
    puts("----------------------------------");
    puts("");
    puts("Legend: A=After B=Before U=Unchanged D=Difference\n");
  }
  return L;
}

/*! \brief Normalise an emotion vector so it's with computational parameters.
 * 
 */
struct List_Str *NormalizedEmo(struct List_Str *EmoVector){
  int _=0,Final=0;
  float Value=0,Max=0;
  struct List_Str *Buffer=NULL,*R=NULL;
  for(Buffer=EmoVector;Buffer;Buffer=Buffer->Next){
    Value=atoi(Buffer->Str);
    Value=(Value>0)?Value:-1*Value;
    Max=(Value>Max)?Value:Max;
  }
  for(Buffer=EmoVector;Buffer;Buffer=Buffer->Next){
    Value=atof(Buffer->Str);
    if(Max!=0)                                  Value=Value/Max;
    else                                        Value=0;
    if(Value<-0.3333333)                        Final=-100;
    if(Value> 0.3333333)                        Final=100;
    if((Value<=0.3333333)&&(Value>=-0.3333333)) Final=0;
    R=Ins_List_Element(R,FloatToString(Final),_++);
  }
  return R;
}

/*! \brief Display the contents of ConceptE structures.
 * - For debugging.
 */
void DebugCE(struct ConceptE *E){
   int _=0,A=0;
   char *EmoName=NULL;
   struct List_Str *Buffer1=NULL,*Buffer2=NULL,*EmoCache=NULL;
   if(E){
      puts(" -Before:");
      for(_=0;_<E->BeforeSize;_++){
	Buffer2=E->EmoBConcepts[_];
	A=0;
	for(Buffer1=E->BConcepts[_];Buffer1;Buffer1=Buffer1->Next){
	  if(Buffer1)
	    printf("  %03d S: %s\n",A,Buffer1->Str);
	  if(Buffer2){
	    printf("  %03d E: ",A); PrintList(Str2List(Buffer2->Str));
	    if((EmoName=ReportEmotionName(EmoCache=Str2List(Buffer2->Str))))
	      printf("  %03d N: %s\n",A,EmoName);
	    Buffer2=Buffer2->Next;
	  }
	  A++;
	  puts("");
	}
      }
      puts(" -After:");
      for(_=0;_<E->AfterSize;_++){
	 Buffer2=E->EmoAConcepts[_];
	 A=0;
	 for(Buffer1=E->AConcepts[_];Buffer1;Buffer1=Buffer1->Next){
	   if(Buffer1)
	     printf("  %03d S: %s\n",A,Buffer1->Str);
	   if(Buffer2){
	     printf("  %03d E: ",A); PrintList(Str2List(Buffer2->Str));
	     if((EmoName=ReportEmotionName(EmoCache=Str2List(Buffer2->Str))))
	       printf("  %03d N: %s\n",A,EmoName);
	     Buffer2=Buffer2->Next;
	   }
	   A++;
	   puts("");
	 }
      }
      puts(" -Unchanged:");
      for(_=0;_<E->UnchangedSize;_++){
	 Buffer2=E->EmoUConcepts[_];
	 A=0;
	 for(Buffer1=E->UConcepts[_];Buffer1;Buffer1=Buffer1->Next){
	   if(Buffer1)
	     printf("  %03d S: %s\n",A,Buffer1->Str);
	   if(Buffer2){
	     printf("  %03d E: ",A); PrintList(Str2List(Buffer2->Str));
	     if((EmoName=ReportEmotionName(EmoCache=Str2List(Buffer2->Str))))
	       printf("  %03d N: %s\n",A,EmoName);
	     Buffer2=Buffer2->Next;
	   }
	   A++;
	   puts("");
	 }
      }
      puts("-[SUMMARY]-----------");
      printf(" Before     total: "); PrintList(E->EmoTB);
      printf(" After      total: "); PrintList(E->EmoTA);
      printf(" Unchanged  total: "); PrintList(E->EmoTU);
      printf(" Difference total: "); PrintList(E->EmoTD);
      puts("---------------------");
   }
   else
     puts("Nothing to debug.");
}

/*! \brief Computes the emotion of a sentence.
 * 
 */
struct List_Str *SentenceEmotion(struct List_Str *Word_List,struct List_Str *L){
  int AdjectiveNum=0,_=0,Size=0;
  double Rads=0;
  struct List_Str *Buffer=NULL,*Buffer2=NULL,*AdjEmotion=NULL,*Sentence_Components=NULL,*SEmotion=NULL,*PNEmotion=NULL,*Resultant=NULL,*SemEmotion=NULL;
  struct Datablock *S=NULL,*PN=NULL,*FoundDB=NULL;
  Word_List=Str2List(List2Str(Word_List));
  for(Buffer=Word_List;Buffer;Buffer=Buffer->Next){
    if(IsArticle(Buffer->Str,"adjective")){
      FoundDB=Goto_DB_Entry(Database[1],Buffer->Str);
      AdjectiveNum++;
      AdjEmotion=Str2List(Get_DB_Entry(FoundDB,0,3));
    }
  }
  Sentence_Components=Get_Sem_CSNouns(Word_List);
  if(!Sentence_Components){
    if(ThinkOutLoud)
      puts("ERROR: SentenceEmotion, no Sentence_Components!");
    ANSWER=Str2List("0 0 0 0 0");
    return L;
  }
  CSAddr(Str2List(Get_List_Element(Sentence_Components,0)),NULL);
  SEmotion=Str2List(Get_DB_Entry(S=Goto_DB_Entry(Database[1],ANSWER->Str),0,3));
  CSAddr(Str2List(Get_List_Element(Sentence_Components,2)),NULL);
  PNEmotion=Str2List(Get_DB_Entry(PN=Goto_DB_Entry(Database[1],ANSWER->Str),0,3));
  SEmotion=(!strcmp(SEmotion->Str,"?"))?NULL:SEmotion;
  PNEmotion=(!strcmp(PNEmotion->Str,"?"))?NULL:PNEmotion;
  if(SEmotion||PNEmotion){
    if((!!SEmotion)^(!!PNEmotion)){
      SEmotion?Rep_DB_Entry(FoundDB,0,3,List2Str(SEmotion)):Rep_DB_Entry(FoundDB,0,3,List2Str(PNEmotion));
      SemEmotion=SEmotion?SEmotion:PNEmotion;
    }
    else{
      if((Size=Size_of_List(SEmotion))==Size_of_List(PNEmotion)){
	SemEmotion=NULL;
	Buffer=SEmotion;
	Buffer2=PNEmotion;
	for(_=0;_<Size;_++){
	  SemEmotion=Ins_List_Element(SemEmotion,FloatToString((atof(Buffer->Str)+atof(Buffer2->Str))/2),_);
	  Buffer=Buffer->Next;
	  Buffer2=Buffer2->Next;
	}
      }
      else{
	if(ThinkOutLoud) puts("Dimensionally incompatible emotion.");
	return NULL;
      }
    }
  }
  else{
    SemEmotion=NULL;
  }
  if(ThinkOutLoud){
    printf("SEM EMO:"); PrintList(SemEmotion);
    printf("ADJ EMO:"); PrintList(AdjEmotion);
  }
  ANSWER=NULL;
  if(SemEmotion){
    ANSWER=SemEmotion;
    if(AdjectiveNum){
      if((Rads=ScalarProduct(AdjEmotion,SemEmotion))>1.5){
	puts("haha");
      }
    }
    else
      Rep_DB_Entry(FoundDB,0,3,List2Str(SemEmotion));
  }
  else{
    if(AdjectiveNum){
      Resultant=AdjEmotion;
      Rep_DB_Entry(S,0,3,List2Str(AdjEmotion));
      Rep_DB_Entry(PN,0,3,List2Str(AdjEmotion));
      ANSWER=Resultant;
    }
    else{
      ANSWER=NULL;
      if(ThinkOutLoud)
	puts("No emotion found!");
    }
  }
  if(!ANSWER){
    ANSWER=Str2List("0 0 0 0 0");    
  }
  return L;
}

/*! \brief Attempts to empathise with a sentence.
 * 
 */
struct ConceptE *Empathy(struct List_Str *Word_List,struct List_Str *L){
  int _=0,A=0,B=0,Alpha=0,Beta=0,Gamma=0;
  char *Start=NULL,*Finish=NULL;
  struct List_Str *NoEmotion=NULL,*BeforeEmotions=NULL,*AfterEmotions=NULL,*UnchangedEmotions=NULL,*Buffer=NULL,*B2=NULL,*Sources=NULL;
  struct Datablock *Lang=GetLang();
  struct Meanings *Initial_Thoughts=NULL,*Current_Thoughts=NULL,*After_Thoughts=NULL,*Unmodified=NULL,*Modified=NULL;
  struct Related *Rel=NULL;

  /* find a list of affected sentences by the last sentence */
  Rel=ListRelatedSentences(Word_List);

  /* need to compute the target audience of the conversation */
  Sources=L;
  if(ThinkOutLoud){
    PrintListSpecial("Empathy Sources: [",Sources,"][","][","]\n");
    PrintListSpecial("Empathy Targets: [",Rel->Targets,"][","][","]\n");
  }
   
  /* if there is nothing to empathise with display a neutral emotion. May need to be changed. */
  if(!Sources){
    GlobalE=PopConceptE(ZeroConceptE(),Word_List);
    if(ThinkOutLoud)
      DebugCE(GlobalE);
    return GlobalE;
  }
  /* Set the semantic pathways before and after the new sentence was added */
  if(!Initial_Thoughts){
    Initial_Thoughts=ZeroMeanings();
    After_Thoughts=ZeroMeanings();
  }
  for(Buffer=Sources;Buffer;Buffer=Buffer->Next){
    Start=Sources->Str;
    for(B2=Rel->CanonicalTargets;B2;B2=B2->Next){
      Finish=B2->Str;
      /* returns null when there is no route */
      Current_Thoughts=S_Spline(Start,Finish,Ins_List_Element(NULL,"?",0),Rel->CSVerbs,Rel->CSNouns);      
      if(Current_Thoughts){
	for(_=0;_<Current_Thoughts->Size;_++){
	  Initial_Thoughts->Conversations=Add_To_Array(Initial_Thoughts->Conversations,Current_Thoughts->Conversations[_],Initial_Thoughts->Size++);
	  After_Thoughts->Conversations=Add_To_Array(After_Thoughts->Conversations,Current_Thoughts->Conversations[_],After_Thoughts->Size++);
	}
      }
      else
	After_Thoughts->Conversations=Add_To_Array(After_Thoughts->Conversations,Ins_List_Element(Str2List(":ERROR"),List2Str(Word_List),0),After_Thoughts->Size++);
    }
  }
  if(Initial_Thoughts->Conversations)
    Initial_Thoughts=Optimise_Spline(Initial_Thoughts);
  else
    Initial_Thoughts->Conversations=Add_To_Array(Initial_Thoughts->Conversations,NULL,Initial_Thoughts->Size++);
  After_Thoughts=Optimise_Spline(After_Thoughts);

  /* Get the semantic pathways that are modified and unchanged */
  if(After_Thoughts->Size){
    Unmodified=ZeroMeanings();
    Modified=ZeroMeanings();
    /* Should sort out which routes have been modified and which havent */
    for(_=0;_<After_Thoughts->Size;_++){
      for(A=0;A<Size_of_List(Rel->AffectedSentences);A++){
	/* if there are affected sentences in the after thoughts, then save in modified, else in unmodified */
	if((B=Find_List_Element(After_Thoughts->Conversations[_],Get_List_Element(Rel->AffectedSentences,A)))+1){
	  /* Replace the old sentence with the new */
	  After_Thoughts->Conversations[_]=Del_List_Element(After_Thoughts->Conversations[_],B);
	  After_Thoughts->Conversations[_]=Ins_List_Element(After_Thoughts->Conversations[_],List2Str(Word_List),B);
	  /* need to save in modified struct meanings */
	  if(Initial_Thoughts->Conversations)
	    Modified->Conversations=Add_To_Array(Modified->Conversations,Initial_Thoughts->Conversations[_],Modified->Size++);
	  else
	    Modified->Conversations=Add_To_Array(Modified->Conversations,NULL,Modified->Size++);
	  Modified->Conversations=Add_To_Array(Modified->Conversations,After_Thoughts->Conversations[_],Modified->Size++);
	}
	else{
	  /*
	    need to save in unmodified struct meanings
	  */
	  if(Initial_Thoughts->Conversations[0])
	    Unmodified->Conversations=Add_To_Array(Unmodified->Conversations,Initial_Thoughts->Conversations[_],Unmodified->Size++);
	  else{
	    Modified->Conversations=Add_To_Array(Modified->Conversations,NULL,Modified->Size++);
	    Modified->Conversations=Add_To_Array(Modified->Conversations,Ins_List_Element(NULL,List2Str(Word_List),0),Modified->Size++);
	  }
	}
      }
    }

    /* initialise ConceptE */
    GlobalE=ZeroConceptE();
    GlobalE->BeforeSize=Modified->Size>>1;
    GlobalE->AfterSize=GlobalE->BeforeSize;
    GlobalE->UnchangedSize=Unmodified->Size;
    if(GlobalE->BeforeSize){
      GlobalE->BConcepts=(struct List_Str **)malloc(GlobalE->BeforeSize*sizeof(struct List_Str *));
      GlobalE->AConcepts=(struct List_Str **)malloc(GlobalE->BeforeSize*sizeof(struct List_Str *));
      GlobalE->EmoBConcepts=(struct List_Str **)malloc(GlobalE->BeforeSize*sizeof(struct List_Str *));
      GlobalE->EmoAConcepts=(struct List_Str **)malloc(GlobalE->BeforeSize*sizeof(struct List_Str *));
    }
    if(GlobalE->UnchangedSize){
      GlobalE->UConcepts=(struct List_Str **)malloc(GlobalE->UnchangedSize*sizeof(struct List_Str *));
      GlobalE->EmoUConcepts=(struct List_Str **)malloc(GlobalE->UnchangedSize*sizeof(struct List_Str *));
      GlobalE->EmoBConcepts=(struct List_Str **)malloc(GlobalE->UnchangedSize*sizeof(struct List_Str *));
      GlobalE->EmoAConcepts=(struct List_Str **)malloc(GlobalE->UnchangedSize*sizeof(struct List_Str *));
    }

    /* need to populate GlobalE */
    Alpha=Beta=0;
    A=Size_of_List(Str2List(Lookup_DB_Attr(Lang,":emotion",NULL)));
    for(_=0;_<A;_++)
      NoEmotion=Ins_List_Element(NoEmotion,"0",_);
    AfterEmotions=NoEmotion;
    BeforeEmotions=NoEmotion;
    UnchangedEmotions=NoEmotion;
    for(_=0;_<Modified->Size;_+=2){
      GlobalE->BConcepts[Alpha]=Modified->Conversations[_];
      GlobalE->AConcepts[Beta]=Modified->Conversations[_+1];
      GlobalE->EmoBConcepts[Alpha]=NULL;
      GlobalE->EmoAConcepts[Beta]=NULL;
      Gamma=0;
      for(Buffer=Modified->Conversations[_];Buffer;Buffer=Buffer->Next){
	SentenceEmotion(Str2List(Buffer->Str),NULL);
	if(ANSWER)
	  if(!strcmp(ANSWER->Str,"?"))
	    ANSWER=NULL;
	if(ANSWER){
	  GlobalE->EmoBConcepts[Alpha]=Ins_List_Element(GlobalE->EmoBConcepts[Alpha],List2Str(ANSWER),Gamma++);
	  BeforeEmotions=VectorAdd(BeforeEmotions,ANSWER);
	}
	else
	  GlobalE->EmoBConcepts[Alpha]=Ins_List_Element(GlobalE->EmoBConcepts[Alpha],List2Str(NoEmotion),Gamma++);
      }
      Gamma=0;
      for(Buffer=Modified->Conversations[_+1];Buffer;Buffer=Buffer->Next){
	SentenceEmotion(Str2List(Buffer->Str),NULL);
	if(ANSWER)
	  if(!strcmp(ANSWER->Str,"?"))
	    ANSWER=NULL;
	if(ANSWER){
	  GlobalE->EmoAConcepts[Beta]=Ins_List_Element(GlobalE->EmoBConcepts[Beta],List2Str(ANSWER),Gamma++);
	  AfterEmotions=VectorAdd(AfterEmotions,ANSWER);
	}
	else
	  GlobalE->EmoAConcepts[Beta]=Ins_List_Element(GlobalE->EmoBConcepts[Beta],List2Str(NoEmotion),Gamma++);
      }
      Alpha++;
      Beta++;
    }
    GlobalE->EmoTB=BeforeEmotions;
    GlobalE->EmoTA=AfterEmotions;
    Alpha=0;
    for(_=0;_<Unmodified->Size;_++){
      GlobalE->UConcepts[Alpha]=Unmodified->Conversations[_];
      Gamma=0;
      for(Buffer=Unmodified->Conversations[_];Buffer;Buffer=Buffer->Next){
	SentenceEmotion(Str2List(Buffer->Str),NULL);
	if(ANSWER)
	  if(!strcmp(ANSWER->Str,"?"))
	    ANSWER=NULL;
	if(ANSWER){
	  GlobalE->EmoAConcepts[Alpha]=Ins_List_Element(GlobalE->EmoBConcepts[Alpha],List2Str(ANSWER),Gamma++);
	  UnchangedEmotions=VectorAdd(UnchangedEmotions,ANSWER);
	}
	else
	  GlobalE->EmoAConcepts[Alpha]=Ins_List_Element(GlobalE->EmoBConcepts[Alpha],List2Str(NoEmotion),Gamma++);
      }
      Alpha++;
    }
    GlobalE->EmoTU=UnchangedEmotions;
    GlobalE->EmoTD=VectorSub(GlobalE->EmoTA,GlobalE->EmoTB);
    /* Disabled for testing */
    if(ThinkOutLoud)
      DebugCE(GlobalE);
  }
  else{
    GlobalE=NULL;
  }
  if(!Sources)
    puts("No subject to empathise with!");
  /*   puts("OK"); */
  return GlobalE;
}

/*! \brief Associate words with emotions.
 * 
 */
void Associate_Emo(struct List_Str *L,struct Feeling *Dominant){
   struct List_Str *Buffer=NULL;
   struct Datablock *DB=NULL;
   for(Buffer=L;Buffer;Buffer=Buffer->Next)
     if((DB=Goto_DB_Entry(Database[1],Buffer->Str)))
       Rep_DB_Entry(DB,0,3,List2Str(Dominant->EmotionList));
}

/*! \brief Detect a dominant emotion.
 * 
 */
struct Feeling *Detect_Dominant_Emo(struct List_Str *L){
  int Debug1=0; 
  char *Debug2=NULL;
  int SizeofEmoList=0,_=0,Max=0;
  float Bias=0,*Emos=NULL,SizeofSentence=0;
  float T=0;
  struct List_Str *Buffer=NULL,*WordEmos=NULL,*Select=NULL;
  struct Datablock *Lang=GetLang(),*DB=NULL;
  struct Feeling *F=(struct Feeling *)malloc(sizeof(FeelingTemplate));
  Debug1=Find_List_Element(Lang->DS[1],":emotion");
  Debug2=Get_DB_Entry(Lang,2,Debug1);
  if(!Debug2){
    if(ThinkOutLoud) puts("ERROR [DDE]: Unabled to determine dominant emotion. :ADDEMO not setup! Unable to continue.");
    return NULL;
  }
  SizeofEmoList=Size_of_List(Select=Str2List(Debug2));
  Emos=(float *)malloc(SizeofEmoList*sizeof(float));
  memset(Emos,0,SizeofEmoList);
  for(Buffer=L;Buffer;Buffer=Buffer->Next){
    if((DB=Goto_DB_Entry(Database[1],Buffer->Str))){
      WordEmos=Str2List(Get_DB_Entry(DB,0,3));
      if(strcmp(WordEmos->Str,"?"))
	for(_=0;_<SizeofEmoList;_++)
	  Emos[_]+=T=atof(Get_List_Element(WordEmos,_));
    }
    SizeofSentence++;
  }
  if((_=Find_List_Element(Lang->DS[1],":setbias"))+1)
    Bias=atof(Get_DB_Entry(Lang,2,_));
  for(_=0;_<SizeofEmoList;_++){
    if(strcmp(Get_List_Element(Select,_),"neutral"))
      Emos[_]=((Emos[_]*Bias)/(SizeofSentence));
    else
      Emos[_]=50;
  }
  F->EmotionList=NULL;
  F->DominantEmo=Find_List_Element(Select,"neutral");
  for(_=0;_<SizeofEmoList;_++){
    if(Emos[_]>Max){
      Max=Emos[_];
      F->DominantEmo=_;
    }
    F->EmotionList=Ins_List_Element(F->EmotionList,FloatToString(Emos[_]),_);
  }
  F->DominantName=Get_List_Element(Select,F->DominantEmo);
  return F;
}

/*! \brief Associate emotions with words and sentences.
 * 
 */
void ParseSentenceEmotion(struct List_Str *L){
   int Setup=1;
   struct Feeling *F=NULL;
   struct Datablock *Lang=GetLang();
   if(Lang) 
     Setup=!((!Is_List_Element(Lang->DS[1],":emotion"))||(!Is_List_Element(Lang->DS[1],":setbias")));
   else 
     Setup=0;
   if(Setup){
      if(LEGACYEMOTION)
	Associate_Emo(L,F=Detect_Dominant_Emo(L));
      Add2Conversation(0,L);
      InputFeedback(F);
   }
}

/*! \brief Associate emotions with words and sentences.
 * 
 */
void InputFeedback(struct Feeling *Dominant){ /* needs testing */
  int _=0;
  struct Datablock *R=Goto_DB_Entry(Database[1],"CONVBUFFER");
  if(R)
    if((_=Find_List_Element(R->DS[2],"C"))+1){
      if(LEGACYEMOTION)
	Associate_Emo(IntCSRecon(Get_DB_Entry(R,1,_)),Dominant);
    }
}

/*! \brief Sets the dominant emotion.
 * 
 */
void AwarenessFeedback(int Understanding){
   int _=0,Select_Size=0;
   struct List_Str *Select=NULL;
   struct Datablock *DB=GetLang();
   if(DB){
      if((_=Find_List_Element(DB->DS[1],":emotion"))+1)
	 Select_Size=Size_of_List(Select=Str2List(Get_DB_Entry(DB,2,_)));
      else{
	 GlobalF=NULL;
	 return;
      }
      GlobalF=(struct Feeling *)malloc(sizeof(FeelingTemplate));
      GlobalF->DominantName=NULL;
      if(Understanding==0)
	GlobalF->DominantName="sad";
      if(Understanding==1)
	GlobalF->DominantName="neutral";
      if(Understanding==2)
	GlobalF->DominantName="happy";
      GlobalF->DominantEmo=Find_List_Element(Select,GlobalF->DominantName);
      GlobalF->EmotionList=NULL;
      for(_=0;_<Select_Size;_++){
	 if(_==GlobalF->DominantEmo)
	   GlobalF->EmotionList=Ins_List_Element(GlobalF->EmotionList,"1000",_);
	 else
	   GlobalF->EmotionList=Ins_List_Element(GlobalF->EmotionList,"0",_);
      }
   }
}

/*! \brief Display the components of an emotion vector.
 *  - For debugging.
 */
struct List_Str  *EmoDebugVec(struct List_Str *Word_List,struct List_Str *L){
  struct List_Str *Buffer=NULL,*Data=NULL;
  Data=Str2List("Understanding Morality Mortality Action Determination");
  if(Size_of_List(Word_List)==5)
    for(Buffer=Word_List;Buffer;Buffer=Buffer->Next,Data=Data->Next)
      printf("%s %s\n",Buffer->Str,Data->Str);
  else
    PrintListSpecial("[",Word_List,"][","][","] Is not a valid emotion vector\n");
  return L;
}

/*! \brief Display the appropriate smilie.
 *
 */
void DisplayEmotion(){
   ANSWER=Ins_List_Element(NULL,Smilie,0);
}

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
