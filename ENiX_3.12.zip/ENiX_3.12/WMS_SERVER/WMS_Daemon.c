#include "WMS_API.h"

int main(){
  Daemon();
  return 0;
}
