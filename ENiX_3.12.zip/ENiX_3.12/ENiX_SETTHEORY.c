/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <string.h>
#include "ENiX_STRING.h"
#include "ENiX_LIST.h"
#include "ENiX_WMS.h"
#include "ENiX_SETTHEORY.h"

/*! \brief Compute if a set is the subset of another.
 *
 */
struct List_Str *Subset(struct List_Str *WordList,struct List_Str *L){
   int Found1=1,Found2=0;
   struct List_Str *Inp1=NULL,*Inp2=NULL,*Buffer=NULL,*Output=NULL;
   Inp1=WordList;
   Buffer=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],L->Str),0,7));
   while(Inp1){
      Inp2=Buffer;
      Found2=0;
      while(Inp2){
	 if(!strcmp(Inp1->Str,Inp2->Str))
	   Found2=1;
	 Inp2=Inp2->Next;
      } 
      if(!Found2)
	Found1=0;
      Inp1=Inp1->Next;
   }
   if(Found1)
     Output=Ins_List_Element(Output,FloatToString(1),0); 
   else
     Output=Ins_List_Element(Output,FloatToString(0),0); 
   ANSWER=Output;
   L=L->Next;
   return L;
}

/*! \brief Compute if a set is the subset of another.
 * - Just like Subset() but internal.
 */
int IntSubset(struct List_Str *Needle,struct List_Str *Haystack){
   int Found1=1,Found2=0;
   struct List_Str *Inp1=NULL,*Inp2=NULL,*Buffer=NULL;
   Inp1=Needle;
   Buffer=Haystack;
   while(Inp1){
      Inp2=Buffer;
      Found2=0;
      while(Inp2){
	 if(!strcmp(Inp1->Str,Inp2->Str))
	   Found2=1;
	 Inp2=Inp2->Next;
      } 
      if(!Found2)
	Found1=0;
      Inp1=Inp1->Next;
   }
   return Found1;
}

/*! \brief Compute the union of two sets.
 * 
 */
struct List_Str *Union(struct List_Str *WordList,struct List_Str *L){
   struct List_Str *Inp1=NULL,*Inp2=NULL,*Output=NULL;
   Inp1=WordList;
   Inp2=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],L->Str),0,7));
   while(Inp1){
     Output=Ins_List_Element(Output,Inp1->Str,0); 
     Inp1=Inp1->Next;
   }
   while(Inp2){       
     Output=Ins_List_Element(Output,Inp2->Str,0); 
     Inp2=Inp2->Next;                  
   }
   ANSWER=Output;
   return L->Next;
}

/*! \brief Compute the intersection of two sets.
 *  - The same as Intersection(), but internal
 */
struct List_Str *IntIntersect(struct List_Str *Inp1,struct List_Str *Inp2){
  struct List_Str *Output=NULL,*Buffer=NULL;
  while(Inp1){
    Buffer=Inp2;
    while(Buffer){
      if(!strcmp(Inp1->Str,Buffer->Str)){
	Output=Ins_List_Element(Output,Inp1->Str,0);
      }
      Buffer=Buffer->Next;
    }
    Inp1=Inp1->Next;
  }
  return Output;
}

/*! \brief Compute the intersection of two sets.
 *  
 */
struct List_Str  *Intersection(struct List_Str *WordList,struct List_Str *L){
  struct List_Str *Inp1=NULL,*Buffer=NULL;
  Inp1=WordList;
  Buffer=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],L->Str),0,7));
  ANSWER=IntIntersect(Inp1,Buffer);
  L=L->Next;
  return L;
}

/*! \brief Compute the set theory exclusion (complement) of within one set, but outside the other.
 *  
 */
struct List_Str *Except(struct List_Str *WordList,struct List_Str *L){
   struct List_Str *Buffer=NULL;
   Buffer=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],L->Str),0,7));
   ANSWER=SetExclude(WordList,Buffer);
   return L->Next;
}

/*! \brief Determine if something is an element of a set.
 *  
 */
struct List_Str *Element(struct List_Str *WordList,struct List_Str *L){
   int                  Found1=1,Found2=0;
   struct List_Str      *Inp1=NULL,*Inp2=NULL,*Buffer=NULL,*Output=NULL;
   Inp1=WordList;
   Buffer=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],L->Str),0,7));
   while(Inp1){
      Inp2=Buffer;
      Found2=0;
      while(Inp2){
	 if(!strcmp(Inp1->Str,Inp2->Str))
	   Found2=1;
	 Inp2=Inp2->Next;
      } 
      if(!Found2)
        Found1=0;
      Inp1=Inp1->Next;
   }
   if(Found1)
     Output=Ins_List_Element(Output,FloatToString(1),0); 
   else
     Output=Ins_List_Element(Output,FloatToString(0),0);   
   ANSWER=Output;
   L=L->Next;
  return L;
}

/*! \brief Compute the union of two sets.
 * - The same as Union() but internal.
 */
struct List_Str *IntUnion(struct List_Str *WordList,struct List_Str *L){
  struct List_Str *Buffer=NULL;
  for(Buffer=L;Buffer;Buffer=Buffer->Next)
    WordList=Add2Set(WordList,Buffer->Str);
  return WordList;
}

/*! \brief Add elements to a set.
 * 
 */
struct List_Str *Add2Set(struct List_Str *Set,char *Element){
  struct List_Str *R=Set;
  if(!Is_List_Element(Set,Element))
    R=Ins_List_Element(R,Element,0);
  return R;
}

/*! \brief Calculate a set exclusion (compliment).
 * 
 */
struct List_Str  *SetExclude(struct List_Str *WordList,struct List_Str *L){
  int Found=0,Pos=0;
  struct List_Str *Inp1=NULL,*Inp2=NULL,*Output=NULL;
  for(Inp1=WordList;Inp1;Inp1=Inp1->Next){
    Found=0;
    for(Inp2=L;Inp2;Inp2=Inp2->Next){
      if(!strcmp(Inp1->Str,Inp2->Str))
	Found=1;
    }
    if(!Found)
      Output=Ins_List_Element(Output,Inp1->Str,Pos++); 
  }
  return Output;
}

/*! \brief Shrink a set, i.e. remove the duplicate elements.
 * 
 */
struct List_Str *Shrink(struct List_Str *WordList, struct List_Str *L){
  /*
  struct List_Str *Buffer=NULL,*Output=NULL;
  for(Buffer=WordList;Buffer;Buffer=Buffer->Next)
    Output=Add2Set(Output,Buffer->Str);
  ANSWER=Output;
  */
  ANSWER=IntShrink(WordList);
  return L;
}

/*! \brief Internal shrink a set, i.e. remove the duplicate elements.
 * 
 */
struct List_Str *IntShrink(struct List_Str *Set){
  struct List_Str *Buffer=NULL,*Output=NULL;
  for(Buffer=Set;Buffer;Buffer=Buffer->Next)
    Output=Add2Set(Output,Buffer->Str);
  return Output;
}

/*! \brief Determine if the sets are the same.
 * 
 */
int SameSet(struct List_Str *Set1,struct List_Str *Set2){
  struct List_Str *Buffer=NULL;
  for(Buffer=Set1;Buffer;Buffer=Buffer->Next)
    if(!Is_List_Element(Set2,Buffer->Str))
      return 0;
  for(Buffer=Set2;Buffer;Buffer=Buffer->Next)
    if(!Is_List_Element(Set1,Buffer->Str))
      return 0;
  return 1;
}

/*! \brief Determine if ALL needles are in haystack
 * 
 */
int AreAllIn(struct List_Str *Haystack,struct List_Str *Needles){
  struct List_Str *Buffer=NULL;
  for(Buffer=Needles;Buffer;Buffer=Buffer->Next)
    if(!Is_List_Element(Haystack,Buffer->Str))
      return 0;
  return 1;
}

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
