/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#ifndef NLP
#define NLP

#include "ENiX_LDEFS.h"

extern int ENABLEOUT;
extern int Suppress_ANSWER;
extern struct EmoReady  *EmpatheticSummary;
extern struct ConceptE  *GlobalE; /* stores empathy of current sentence */
extern struct Feeling   *GlobalF; /* for the output of pattern analyser */

#define FILTERNOUNSONLY  "noun pronoun propernoun"
#define FILTERNOUNCLAUSE "noun pronoun propernoun adjective"
#define FILTERCLAUSE "noun pronoun propernoun adjective definitearticle indefinitearticle"

struct Meanings  *ZeroMeanings();
struct List_Str  *ParallelSimples(struct List_Str *SN,struct List_Str *PV,struct List_Str *PN);

/************************************************************* 
                        High Level
*************************************************************/
struct List_Str  *Scheduler(struct List_Str *Word_List,struct List_Str *L);

struct Sentence  *ConvertSentence(struct List_Str *Sentence,int AutoLearnWords,int DisableComplexS);
struct List_Str  *IntelligentInt(struct List_Str *Word_List,int Save);
void             TouchTopic(struct Sentence *Sentence);
struct List_Str  *ListByTopic(struct List_Str *Word_List,struct List_Str *L);
struct Datablock *Add2Conversation(int Type,struct List_Str *L);
struct List_Str  *DeYoda(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Phrase_Generator(struct List_Str *WordList, struct List_Str *L);
struct List_Str  *Study(struct List_Str *WordList,struct List_Str *L);

struct List_Str  *Sentence_Generator(struct List_Str *WordList, struct List_Str *L);
struct List_Str  *Sentence_Designer(struct List_Str *WordList, struct List_Str *L);




/************************************************************* 
                        Mid Level
*************************************************************/
int              IndicativeWrapper(struct Sentence *Sentence);
struct List_Str  *CS2Sentence(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *CSSentenceRecon(char *CSID);
struct List_Str  *QWrapper(struct Sentence *Sentence);
int              YNQWrapper(struct Sentence *Sentence);
int              YNQuest(struct List_Str *S,struct List_Str *PV,struct List_Str *PN);
int              Awareness1(struct List_Str *L,int BR);               /* BR 1 == No BI Returned BR 0 == BI Returned */
int              Awareness2(char *L,int BR);                          /* BR 1 == No BI Returned BR 0 == BI Returned */
char             *IndicativeComponent(struct List_Str *Sentence);
int              SeparateSentence(struct Sentence *Sentence);
void             SubstitutePronouns(struct List_Str *Subjects,struct List_Str *Predicates);
struct List_Str  *CompoundSentence(struct List_Str *Sentence);
struct List_Str  *GroupClauses(struct List_Str *Word_List);
void             Permutation(struct List_Str *Set, struct List_Str *Perm, int N);
void             Permutation2(struct List_Str *Set, struct List_Str *Perm, int N);

struct List_Str  *Translator(struct List_Str *Word_List, struct List_Str *L);
struct List_Str  *Recollect(struct List_Str *WordList, struct List_Str *L);
struct List_Str  *IWrapper(struct List_Str *Com);

struct Conditional *ConvertConditional(struct List_Str *SentenceData);
struct Conditional *SeparateConditional(struct Conditional *ConditionalLogic);
struct Conditional *ProcessConditional(struct Conditional *Cond);

struct CombinedSentence *BreakCombSentence(struct List_Str *CombinedSentence);
struct CombinedSentence *SplitConjSentences(struct CombinedSentence *Conjoined);


/************************************************************* 
                        Low Level
*************************************************************/
struct List_Str  *ListSentences(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Random(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *ListCombinations(struct List_Str *WordList, struct List_Str *L);
void             CombRec(struct List_Str *Sofar, struct List_Str *D,int L);
void             Paragraph2Sentence(struct List_Str *Paragraph);
char             *Sentence2NegCSVar(struct List_Str *S);

/************************************************************* 
                  Context Addressibility
*************************************************************/
struct List_Str  *GenerateCSVerbs();
struct List_Str  *GenerateCSNouns(struct List_Str *Inp);
struct List_Str  *SharedContext(char *Str,struct List_Str *CSVerbs,struct List_Str *CSNouns);
struct List_Str  *Get_Sem_CSNouns(struct List_Str *Sentence);
struct List_Str  *ListReleventVerbs(struct List_Str *Verb);

/************************************************************* 
                    Sentence Generation
*************************************************************/
struct List_Str  *AssembleSentence(struct List_Str *Subject,struct List_Str *PredicateVerb,struct List_Str *Qualifiers,struct List_Str *Nouns);
struct List_Str  *OutputAnswer(char *Pre,struct List_Str *L,char *Space,char *Final,char *End,int ThoughtsOnly);
struct List_Str  *RecPrevSentence(int Prev); /* Prev represents the number of sentences ago */

/************************************************************* 
                         Detection
*************************************************************/
int              Detect_Voice(struct List_Str *L);
struct List_Str  *SentenceTense(struct List_Str *Word_List,struct List_Str *L);
int              Active_Passive(struct List_Str *A);
int              ComplexSentence(struct Sentence *Sentence);
int              SameNegation(struct List_Str *A,struct List_Str *B);
int              IsNegated(struct List_Str *PV);

/************************************************************* 
                         Debugging
*************************************************************/
void             DebugMeanings(struct Meanings *M);

/************************************************************* 
                         Filteration 
*************************************************************/
struct List_Str  *RootVerb(struct List_Str *WordList);
struct List_Str  *Canonical(struct List_Str *L,int Translate,int BR); /* Translate 0 == dont Translate 1 == do */
struct List_Str  *PutAdverbsLast(struct List_Str *List);
struct List_Str  *PutAdjectivesFirst(struct List_Str *List);
struct List_Str  *DiscardTense(struct List_Str *VerbData);
struct List_Str  *FilterTense(struct List_Str *L,char *Tense);
struct List_Str  *RefineNouns(struct List_Str *Clause,int Passive);
int              DetermineNounLogic(struct List_Str *Clause);


/************************************************************* 
                            Words
*************************************************************/
char *ConvertVerbTense(char *Verb,char *Tense,int ActiveVoice);
struct List_Str  *ListSimilarVerbs(struct List_Str *L);

/************************************************************* 
                          Conversion
*************************************************************/
struct List_Str  *SentenceConvertTense(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SentenceConvertBase(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SentenceConvertMood(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *NegateSentence(struct List_Str *Sentence);
struct List_Str  *ModSenAddAdv(struct List_Str *Sentence,char *Adverb);
struct List_Str  *ModSenInd2Imp(struct List_Str *Sentence);
struct List_Str  *ModSenImp2Ind(struct List_Str *Sentence);
struct List_Str  *ModSenAct2Pas(struct List_Str *Sentence);
struct List_Str  *ModSenPas2Act(struct List_Str *Sentence);
struct List_Str  *Convert2Sentence(struct Sentence *Sentence);
struct List_Str  *NounRefine2Clause(struct List_Str *Refined,int Logic); /* opposite of RefineNouns */
struct List_Str  *VerbRefine2Clause(struct List_Str *Refined); 
struct Sentence  *CreateSentenceStruct(struct List_Str *Subj,int SLogic,struct List_Str *Pred,int PLogic,struct List_Str *Verbs,int Tense,char *Mood);

#endif

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
