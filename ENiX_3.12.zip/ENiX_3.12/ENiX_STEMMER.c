/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ENiX_Globals.h"
#include "ENiX_LIST.h"
#include "ENiX_WMS.h"
#include "ENiX_SETTHEORY.h"
#include "ENiX_OUTPUT.h"
#include "ENiX_STEMMER.h"

/*! \brief Set up the Porter Stemming algorithm.
 * - Classifies the words by their suffixes.
 */
struct List_Str  *StemClass(struct List_Str *Word_List,struct List_Str *L){
  char *Classification=NULL,*Found=NULL,*Old=NULL,*New=NULL;
  struct List_Str *Seg1=NULL,*Seg2=NULL,*Buffer1=NULL,*Buffer2=NULL;
  struct Datablock *DB=Goto_DB_Entry(Database[1],":STEM"),*Marker=NULL;
  if(DB){
    Seg2=DB->DS[2];
    for(Seg1=DB->DS[1];Seg1;Seg1=Seg1->Next){
      Classification=Seg1->Str;
      for(Buffer1=Str2List(Seg2->Str);Buffer1;Buffer1=Buffer1->Next)
	for(Buffer2=Word_List;Buffer2;Buffer2=Buffer2->Next)
	  if((Found=strstr(Buffer2->Str,Buffer1->Str)))
	    if(strlen(Found)==strlen(Buffer1->Str)){
	      New=Old=Get_DB_Entry(Marker=Goto_DB_Entry(Database[1],Buffer2->Str),0,1);
	      if(strcmp(Old,"?"))
		New=List2Str(Add2Set(Str2List(Old),Classification));
	      else
		New=Classification;
	      Rep_DB_Entry(Marker,0,1,New);
	    }
      Seg2=Seg2->Next;
    }
  }
  else
    if(ThinkOutLoud)
      puts("ERROR :STEMCLASS stemming not set up!");
  return L;
}

/*! \brief Associates meanings between similar words.
 *
 */
struct List_Str  *StemMeld(struct List_Str *Word_List,struct List_Str *L){
  char *BaseWord=NULL,*Classification=NULL,*Found=NULL,*Old=NULL,*New=NULL;
  struct List_Str *Buffer1=NULL,*Buffer2=NULL,*Buffer3=NULL,*Buffer4=NULL,*RelatedWords=NULL;
  struct Datablock *DB=Goto_DB_Entry(Database[1],":STEM"),*Current=NULL;
  if(DB){
    StemBase(Word_List,NULL);
    BaseWord=ANSWER->Str;
    StemFind(Word_List,NULL);
    RelatedWords=ANSWER;
    AddWRef(RelatedWords,Str2List(BaseWord));
    Buffer3=DB->DS[1];
    for(Buffer2=DB->DS[2];Buffer2;Buffer2=Buffer2->Next){
      Classification=Buffer3->Str;
      for(Buffer1=Str2List(Buffer2->Str);Buffer1;Buffer1=Buffer1->Next)
	for(Buffer4=RelatedWords;Buffer4;Buffer4=Buffer4->Next){
	  Found=strstr(Buffer4->Str,Buffer1->Str);
	  if(Found)
	    if(strlen(Found)==strlen(Buffer1->Str)){
	      New=Old=Get_DB_Entry(Current=Goto_DB_Entry(Database[1],Buffer4->Str),0,1);
	      if(strcmp(Old,"?"))
		New=List2Str(Add2Set(Str2List(Old),Classification));
	      else
		New=Classification;
	      Rep_DB_Entry(Current,0,1,New);
	    }
	}
      Buffer3=Buffer3->Next;
    }
  }
  else
    if(ThinkOutLoud)
      puts("STEMMELD: STEM not setup!");
  return L;
}

/*! \brief Saves a list of stems from words "Word_List" to ANSWER.
 *
 */
struct List_Str  *StemBase(struct List_Str *Word_List,struct List_Str *L){
  int Size=0,_=0;
  char *Data=NULL;
  struct List_Str *Buffer1=NULL,*Buffer2=NULL,*Result=NULL;
  for(Buffer1=Word_List;Buffer1;Buffer1=Buffer1->Next){
    Size=0; Data=NULL;
    StemFind(Str2List(Buffer1->Str),NULL);
    for(Buffer2=ANSWER;Buffer2;Buffer2=Buffer2->Next){
      _=strlen(Buffer2->Str);
      if(Size){
	if(_<Size){
	  Size=_;
	  Data=Buffer2->Str;
	}
      }
      else{
	Size=_;
	Data=Buffer2->Str;
      }
    }
    if(Data)
      Result=Add2Set(Result,Data);
  }
  if(!Result){
    if(ThinkOutLoud)
      puts("Warning no stembases found!");
  }
  else
    ANSWER=Result;
  return L;
}

/*! \brief Find the word stem. 
 *
 */
struct List_Str  *StemFind(struct List_Str *Word_List,struct List_Str *L){
  int _=0,Length=0,A=0,B=0,Flag=0;
  char *Name1=NULL,*Name2=NULL,*Ext=NULL,*Base=NULL;
  struct List_Str *Buffer=NULL,*Found=NULL,*Suffixes=NULL,*Buffer2=NULL;
  struct Datablock *DB=Goto_DB_Entry(Database[1],":STEM"),*Search=NULL;
  if(DB){
    for(Buffer=DB->DS[2];Buffer;Buffer=Buffer->Next)
      Suffixes=Ins_List_List(Suffixes,Str2List(Buffer->Str),0);
    for(Buffer=Word_List;Buffer;Buffer=Buffer->Next){
      Name1=Buffer->Str;
      Flag=0;
      for(Buffer2=Suffixes;Buffer2;Buffer2=Buffer2->Next){
	Name2=Buffer2->Str;
	Ext=strstr(Name1,Name2);
	if(Ext){
	  Flag=1;
	  if((_=strlen(Ext))==strlen(Name2)){
	    Base=(char *)malloc((Length=strlen(Name1)-_)*sizeof(char));
	    memset(Base,'\0',Length);
	    snprintf(Base,Length-1,"%s",Name1);
	    for(Search=Database[1];Search;Search=Search->Next){
	      _=(A=strlen(Search->DS[0]->Str))<(B=strlen(Base))?A:B;
	      if(!strncmp(Search->DS[0]->Str,Base,_))
		Found=Add2Set(Found,Search->DS[0]->Str);
	    }
	  }
	}
      }
      if(!Flag){
	Base=Name1;
	for(Search=Database[1];Search;Search=Search->Next){
	  _=(A=strlen(Search->DS[0]->Str))<(B=strlen(Base))?A:B;
	  if(!strncmp(Search->DS[0]->Str,Base,_))
	    Found=Add2Set(Found,Search->DS[0]->Str);
	}
      }
    }
  }
  else
    if(ThinkOutLoud)
      puts("Stemming not setup.");
  if(Found)
    ANSWER=Found;
  return L;
}

/*! \brief Add a word stem.
 *
 */
struct List_Str  *StemAdd(struct List_Str *Word_List,struct List_Str *L){
  struct Datablock *DB=Goto_DB_Entry(Database[1],":STEM");
  if(!DB){
    Database[1]=Add_DB_Entry(Database[1],":STEM");
    DB=Database[1];
  }
  Rep_DB_Pair(DB,L->Str,List2Str(Word_List));
  return L->Next;
}

/*! \brief Show a word stem.
 *
 */
struct List_Str *StemShow(struct List_Str *Word_List,struct List_Str *L){
  struct Datablock *DB=Goto_DB_Entry(Database[1],":STEM");
  if(DB)
    Print_DB_Entry(DB,0);
  else
    if(ThinkOutLoud)
      puts("Stemming not setup.");
  return L;
}



/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
