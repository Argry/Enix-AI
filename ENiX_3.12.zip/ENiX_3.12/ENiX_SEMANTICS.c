/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include "ENiX_Globals.h"
#include "ENiX_STRING.h"
#include "ENiX_LIST.h"
#include "ENiX_WMS.h"
#include "ENiX_NLP.h"
#include "ENiX_REASON.h"
#include "ENiX_SEMANTICS.h"
#include "ENiX_SPLINE.h"
#include "ENiX_WMS_COMPAT.h"
#include "ENiX_SETTHEORY.h"
#include "ENiX_CS.h"
#include "ENiX_OUTPUT.h"
#include "ENiX_EXEC.h"
#include "ENiX_VirtualDB.h"

int VERBPOSTPROC;
struct Meanings  *Last_Thoughts=NULL;

/*! \brief Add references to the verb table.
 * - The verb table is a lookup system which invokes ENiX commands when certain verbs are in the sentence.
 */
struct List_Str *VerbTableAdd(struct List_Str *Word_List,struct List_Str *L){
  int Size;
  char *Verb=NULL,*Mood=NULL,*RecordName=NULL,*Qualifier=NULL,*Value=NULL;
  struct Datablock *DB=NULL;
  Size=Size_of_List(Word_List);
  if(Size==3){
    Mood=Word_List->Str;
    Word_List=Word_List->Next;
    Verb=Word_List->Str;
    Word_List=Word_List->Next;
    Qualifier=Word_List->Str;
    Value=List2Str(L);
    Size=strlen(Mood)+strlen(Verb)+5;
    RecordName=(char *)malloc(Size*sizeof(char));
    snprintf(RecordName,Size-1,":%s_%s",Mood,Verb);
    if((!(DB=Goto_DB_Entry(Database[0],RecordName))))
      DB=Database[0]=Add_DB_Entry(Database[0],RecordName);
    Rep_DB_Pair(DB,Qualifier,Value);
  }
  else
    printf("Error, %s:%d, Need 3 args to :VerbTableAdd. Aborting.\n",__FILE__,__LINE__);
  return NULL;
}

/*! \brief Get the action in a verb table entry.
 * - The verb table is a lookup system which invokes ENiX commands when certain verbs are in the sentence.
 */
char *VerbTableGetAct(char *Mood,char *Verb,char *Qualifier){
  int Size=0;
  char *Return=NULL,*RecordName=NULL;
  struct Datablock *DB=NULL;
  Size=strlen(Mood)+strlen(Verb)+5;
  RecordName=(char *)malloc(Size*sizeof(char));
  snprintf(RecordName,Size-1,":%s_%s",Mood,Verb);
  if((DB=Goto_DB_Entry(Database[0],RecordName)))
    Return=Lookup_DB_Attr(DB,Qualifier,NULL);
  return Return;
}

/*! \brief Process the verb table entry.
 * - The verb table is a lookup system which invokes ENiX commands when certain verbs are in the sentence.
 */
struct List_Str *VerbPostProc(struct List_Str *Word_List,struct List_Str *L){
  char *Command=NULL;
  struct List_Str *Original_Sentence=NULL,*PredVerbs=NULL;
  struct Sentence *Sentence=ConvertSentence(Word_List,0,0);
  VERBPOSTPROC=0;
  Original_Sentence=Word_List;
  if(Sentence->Understood){
    PredVerbs=ExtractArticles(RootVerb(PutAdverbsLast(Sentence->PredicateVerbBlock)),"verb");
    if(!PredVerbs){
      if(ThinkOutLoud)
	printf("VerbPostProc (%s:%d) No predicate verbs!\n",__FILE__,__LINE__);
      return L;
    }
    if((Command=VerbTableGetAct(Sentence->Mood,PredVerbs->Str,"?"))){
      ANSWER=Str2List(Command);
      Execute(Original_Sentence,ANSWER);
    }
    else
      if(ThinkOutLoud)
	printf("Note: %s:%d, no verb post processing.\n",__FILE__,__LINE__);
  }
  else{
    if(ThinkOutLoud)
      printf("Error: %s:%d, sentence doesnt make sense!\n",__FILE__,__LINE__);
  }
  return L;
}

/*! \brief Assign meaning to a sentence.
 * 
 */
struct List_Str  *SentenceAssign(struct List_Str *Word_List,struct List_Str *L){
  char *Noun=NULL,*RecordName=NULL,*AdjStr=NULL;
  struct List_Str *Predicates=NULL,*Adjectives=NULL,*Nouns=NULL;
  struct List_Str *Buffer,*Buffer2,*Buffer3,*TMP=NULL;
  struct Datablock *DB=NULL;
  struct Sentence *Sentence=ConvertSentence(Word_List,0,0);
  VERBPOSTPROC=0;
  Predicates=Sentence->RefinedPredicate;
  for(Buffer=Sentence->RefinedSubject;Buffer;Buffer=Buffer->Next){
    RecordName=(char *)malloc((strlen(Buffer->Str)+4)*sizeof(char));
    sprintf(RecordName,"sem_%s",Buffer->Str);
    if((Adjectives=ExtractArticles(Str2List(List2Str(Predicates)),"adjective"))){
      for(Buffer2=Predicates;Buffer2;Buffer2=Buffer2->Next){
	TMP=Str2List(Buffer2->Str);
	Noun=List2Str(ExtractArticles(TMP,FILTERNOUNSONLY));
	Adjectives=ExtractArticles(TMP,"adjective");
	for(Buffer3=Adjectives;Buffer3;Buffer3=Buffer3->Next){
	  if(ThinkOutLoud)
	    printf("Creating %s:%s->%s\n",RecordName,Buffer3->Str,Noun);
	  if(!(DB=Goto_DB_Entry(Database[0],RecordName)))
	    DB=Database[0]=Add_DB_Entry(Database[0],RecordName);
	  Rep_DB_Pair(DB,Buffer3->Str,Noun); 
	  if(ThinkOutLoud)
	    Print_DB_Entry(DB,0);
	}
      }
    }
    else{
      /* if we are in here it means that there are no adjectives and the nouns are describing each other */
      /* only handle situations where there are noun parings */
      Nouns=ExtractArticles(Predicates,FILTERNOUNSONLY);
      if(Size_of_List(Nouns)!=2){
	if(ThinkOutLoud)
	  printf("WARNING: %s:%s():L%d, Possible incorrect processing of predicate.\n",__FILE__,__func__,__LINE__);
	return L;
      }
      AdjStr=Nouns->Str;
      Noun=Nouns->Next->Str;
      if(ThinkOutLoud)
	printf("Creating %s:%s->%s\n",RecordName,AdjStr,Noun);
      if(!(DB=Goto_DB_Entry(Database[0],RecordName)))
	DB=Database[0]=Add_DB_Entry(Database[0],RecordName);
      Rep_DB_Pair(DB,AdjStr,Noun); 
      if(ThinkOutLoud)
	Print_DB_Entry(DB,0);
    }
  }
  return L;
}

/*! \brief Derive meaning from a sentence.
 * 
 */
struct List_Str *SentenceExplain(struct List_Str *Word_List,struct List_Str *L){
  int Toggle=0;
  char *RecordName=NULL;
  struct List_Str *SubNouns=NULL,*Qualifiers=NULL,*Values=NULL,*Buffer=NULL;
  struct Datablock *DB=NULL;
  struct Sentence *Sentence=ConvertSentence(Word_List,0,0);
  VERBPOSTPROC=1;
  if((!strcmp(Sentence->Mood,"imperative"))||(!Sentence->Subject))
    SubNouns=ExtractArticles(Sentence->PredicateNounBlock,FILTERNOUNSONLY);
  else
    SubNouns=ExtractArticles(Sentence->Subject,FILTERNOUNSONLY);
  for(Buffer=SubNouns;Buffer;Buffer=Buffer->Next){
    RecordName=(char *)malloc((strlen(Buffer->Str)+4)*sizeof(char));
    sprintf(RecordName,"sem_%s",Buffer->Str);    
    if((DB=Goto_DB_Entry(Database[0],RecordName))){
      for(Qualifiers=DB->DS[1],Values=DB->DS[2];Qualifiers&&Values;Qualifiers=Qualifiers->Next,Values=Values->Next){
	Toggle=Suppress_ANSWER;
	Suppress_ANSWER=0;
	OutputAnswer("",AssembleSentence(Str2List(Buffer->Str),Str2List("is"),Str2List(Qualifiers->Str),Str2List(Values->Str))," "," ",NULL,0);
	Suppress_ANSWER=Toggle;
      } 
    } 
  }
  return L;
}

/*! \brief Find the semantic pathways between source and target. 
 * - Internal function.
 */
struct List_Str **QualifierPaths(char *Source,char *Target,struct List_Str *Used){
  int Position=0,Size=0,_=0;
  char *RecordName=NULL;
  struct List_Str **R=NULL,**Returned=NULL,*Qualifiers=NULL,*Values=NULL,*Buffer1=NULL,*Buffer2=NULL,*TempUsed=NULL;
  struct Datablock *DB=NULL;
  RecordName=(char *)malloc((strlen(Source)+4)*sizeof(char));
  sprintf(RecordName,"sem_%s",Source);
  R=(struct List_Str **)malloc(sizeof(struct List_Str *));
  if((DB=Goto_DB_Entry(Database[0],RecordName))){
    Qualifiers=DB->DS[1];
    Values=DB->DS[2];
    if(Qualifiers&&Values){
      for(Buffer1=Qualifiers,Buffer2=Values;Buffer1&&Buffer2;Buffer1=Buffer1->Next,Buffer2=Buffer2->Next){
	if(!Is_List_Element(Used,Buffer2->Str)){
	  if(!strcmp(Buffer2->Str,Target)){
	    R=(struct List_Str **)realloc(R,(Position+1)*sizeof(struct List_Str *));
	    R[Position++]=Str2List(Buffer1->Str);
	  }
	  TempUsed=Ins_List_Element(Used,Buffer1->Str,0);
	  if((Returned=QualifierPaths(Buffer2->Str,Target,TempUsed))){
	    Size=sizeof(Returned)/sizeof(struct List_Str *);
	    R=(struct List_Str **)realloc(R,(Position+Size)*sizeof(struct List_Str *));
	    for(_=0;_<Size;_++)
	      if(Returned[_]){
		R[Position]=Ins_List_Element(Returned[_],Buffer1->Str,0);
		Position++;
	      }
	  }
	}
      }
    }
    else{
      free(RecordName);
      return NULL;
    }
  }
  else{
    free(RecordName);
    return NULL;
  }
  free(RecordName);
  return R;
}

/*! \brief Find the semantic pathways between source and target. 
 * 
 */
struct List_Str *SemPath(struct List_Str *Word_List,struct List_Str *L){
  int _=0,Size=0,Pos=0;
  char *Source=NULL,*Target=NULL;
  struct List_Str **Buffer=NULL;
  Source=Word_List->Str;
  Target=Get_List_Element(Word_List,1);
  if((Buffer=QualifierPaths(Source,Target,NULL))){
    ANSWER=NULL;
    Size=sizeof(Buffer)/sizeof(struct List_Str *);
    for(_=0;_<Size;_++)
      if(Buffer[_])
	ANSWER=Ins_List_Element(ANSWER,List2Str(Buffer[_]),Pos++);
  }
  return L;
}

/*! \brief Create a list of similar meanings to a word.
 * 
 */
struct List_Str *AtomMeanList(char *Word,struct List_Str *Used){
  struct List_Str *R=NULL,*Buffer=NULL,*Returned=NULL;
  struct Datablock *DB=NULL;
  R=Ins_List_Element(R,Word,0);
  if(!Is_List_Element(Used,Word)){
    if((DB=Goto_DB_Entry(Database[0],StrCat("sem_",Word)))){
      for(Buffer=DB->DS[2];Buffer;Buffer=Buffer->Next){
	Returned=AtomMeanList(Buffer->Str,Ins_List_Element(Used,Word,0));
	R=Ins_List_List(R,Returned,0);
      }
    }
    else
      return R;
  }
  return R;
}

/*! \brief Return how the "Word1" and "Word2" relate.
 * 
 */
struct List_Str *AtomMeanLike(char *Word1,char *Word2){
  struct List_Str *Buffer1=NULL,*Buffer2=NULL;
  if(!(Word1&&Word2))
    return NULL;
  if(!strcmp(Word1,Word2))
    return Str2List("same");
  Buffer1=AtomMeanList(Word1,NULL);
  Buffer2=AtomMeanList(Word2,NULL);
  return IntIntersect(Buffer1,Buffer2);
}

/*! \brief Find if words are the same.
 * 
 */
struct List_Str *AtomMeanSame(char *Word1,char *Word2){
  return AtomMeanGeneric(Word1,Word2,"like");
}

/*! \brief Find if words are the opposite.
 * 
 */
struct List_Str *AtomMeanOppo(char *Word1,char *Word2){
  return AtomMeanGeneric(Word1,Word2,"opposite");
}

/*! \brief Determine a list of opposites to both words.
 * 
 */
struct List_Str *AtomMeanGeneric(char *Word1,char *Word2,char *Type){
  struct List_Str *BufferA=NULL,*BufferB=NULL,*Opposites1=NULL,*Opposites2=NULL,*AllOpposites=NULL;
  struct Datablock *DB1=NULL,*DB2=NULL;
  /* check the opposite of Word1 */
  if((DB1=Goto_DB_Entry(Database[0],StrCat("sem_",Word1))))
    for(BufferA=DB1->DS[0],BufferB=DB1->DS[1];(BufferA&&BufferB);BufferA=BufferA->Next,BufferB=BufferB->Next)
      if(!strcmp(BufferA->Str,Type))
	if(!strcmp(BufferB->Str,Word2))
	  Opposites1=Ins_List_Element(Opposites1,BufferB->Str,0);
  /* check the opposite of Word2 */
  if((DB2=Goto_DB_Entry(Database[0],StrCat("sem_",Word2))))
    for(BufferA=DB2->DS[0],BufferB=DB2->DS[1];(BufferA&&BufferB);BufferA=BufferA->Next,BufferB=BufferB->Next)
      if(!strcmp(BufferA->Str,Type))
	if(!strcmp(BufferB->Str,Word1))
	  Opposites2=Ins_List_Element(Opposites2,BufferB->Str,0);
  AllOpposites=IntUnion(Opposites1,Opposites2);
  return AllOpposites;
}

/*! \brief List all semantically associated words.
 * 
 */
struct List_Str *ListAllSemWords(){
  struct List_Str *R=NULL;
  struct Datablock *DB=NULL;
  for(DB=Database[0];DB;DB=DB->Next)
    if(!strncmp(DB->DS[0]->Str,"sem_",4))
      R=Ins_List_Element(R,DB->DS[0]->Str+4,0);
  return R;
}

/*! \brief List all semantically similar words to "Word".
 * 
 */
struct List_Str *ListSimilarWords(char *Word){
  struct List_Str *R=NULL,*SemWordList=NULL,*Buffer=NULL,*OriginalMeaning=NULL,*NewMeaning=NULL,*CommonMeaning=NULL;
  SemWordList=ListAllSemWords();
  OriginalMeaning=AtomMeanList(Word,NULL);
  for(Buffer=SemWordList;Buffer;Buffer=Buffer->Next){
    NewMeaning=AtomMeanList(Buffer->Str,NULL);
    CommonMeaning=IntIntersect(OriginalMeaning,NewMeaning);
    if(CommonMeaning)
      R=Ins_List_Element(R,Buffer->Str,0);
  }
  return R;
}

/*! \brief Determine if two verbs are similar.
 * 
 */
struct List_Str *IsVerbSimilar(char *V1,char *V2){
  /* to be expanded */
  if(!strcmp(V1,V2))
    return Ins_List_Element(NULL,V1,0);
  return NULL;
}

/*! \brief Perform a causuality analysis.
 * - This is for determining how to cause an event.
 */
struct List_Str *NLPCauseWrap(struct List_Str *Word_List,struct List_Str *L){
  int ReturnedDim=0,_=0;
  char *SentenceStr=NULL;
  struct List_Str *SentenceList=NULL,*ThisSentence=NULL,*R=NULL,*Buffer=NULL;
  struct List_Str **Returned=NULL;
  ListSentences(CSList(),NULL);
  SentenceList=ANSWER;
  for(;L&&(L->Str[0]!=':');L=L->Next)
    ThisSentence=Ins_List_Element(ThisSentence,L->Str,_++);
  Returned=NLPCauseO2O(Word_List,ThisSentence,SentenceList,&ReturnedDim);
  /* not sure what to do with this yet */
  for(_=0;_<ReturnedDim;_++){
    for(Buffer=Returned[_];Buffer;Buffer=Buffer->Next){
      ThisSentence=Str2List(Buffer->Str);
      if(ThisSentence){
	SentenceConvertTense(ModSenInd2Imp(ThisSentence),Str2List("present"));
	SentenceStr=List2Str(ANSWER);
	R=Add2Set(R,SentenceStr);
      }
    }
  }
  ANSWER=R;
  return L;
}

/*! \brief Perform a causuality analysis.
 * - This is for determining how to avoid an event.
 */
struct List_Str *NLPAvoidWrap(struct List_Str *Word_List,struct List_Str *L){
  /* it seems sensible to look at the reasoning first before we try and eliminate steps */
  int ReturnedDim=0,_=0;
  char *SentenceStr=NULL;
  struct List_Str *SentenceList=NULL,*ThisSentence=NULL,*Buffer=NULL,*R=NULL;
  struct List_Str **Returned=NULL,*Buffer2=NULL,*Sentence2Neg=NULL,*NegatedSentence=NULL;
  ListSentences(CSList(),NULL);
  SentenceList=ANSWER;

  for(;L&&(L->Str[0]!=':');L=L->Next)
    ThisSentence=Ins_List_Element(ThisSentence,L->Str,_++);
  Returned=NLPCauseM2M(Word_List,ThisSentence,SentenceList,&ReturnedDim);
  for(_=0;_<ReturnedDim;_++){
    for(Buffer=Returned[_];Buffer;Buffer=Buffer->Next){
      /* determine alternative event (negation?) and if it makes sense */
      Sentence2Neg=Str2List(Buffer->Str);
      NegatedSentence=NegateSentence(Sentence2Neg);
      /* determine if a negation would be beneficial in preventing the event occurring */
      Buffer2=ModSenInd2Imp(NegatedSentence);
      if(Buffer2){
	SentenceConvertTense(Buffer2,Str2List("present"));
	SentenceStr=List2Str(ANSWER);

	R=Add2Set(R,SentenceStr);
      }
    }    
  }
  ANSWER=R;
  return L;
}

/*! \brief Are sentences similar?
 * 
 */
int IsSentenceSimilar(struct List_Str *Source,struct List_Str *Target){
  char *SourceVerb=NULL,*TargetVerb=NULL;
  struct List_Str *SourceSub=NULL,*SourcePred=NULL,*TargetSub=NULL,*TargetPred=NULL;
  struct Sentence *SourceS=ConvertSentence(Source,0,0),*TargetS=ConvertSentence(Target,0,0);
  SourceSub=SourceS->RefinedSubject;
  SourcePred=SourceS->RefinedPredicate;
  SourceVerb=List2Str(SourceS->RefinedVerb);
  TargetSub=TargetS->RefinedSubject;
  TargetPred=TargetS->RefinedPredicate;
  TargetVerb=List2Str(SourceS->RefinedVerb);
  if(!AtomMeanLike(List2Str(SourceSub),List2Str(TargetSub)))
    return 0;
  if(!AtomMeanLike(List2Str(SourcePred),List2Str(TargetPred)))
    return 0;
  if(!IsVerbSimilar(SourceVerb,TargetVerb))
    return 0;
  return 1;
}

/*! \brief What sentences have related meaning?
 * 
 */
struct Related *ListRelatedSentences(struct List_Str *Last_Sentence){
  int Flag=0;
  char *FreeMe=NULL;
  struct List_Str *S=NULL,*PN=NULL,*Buffer=NULL;
  struct List_Str *B1=NULL,*B2=NULL,*B3=NULL,*D1=NULL,*D2=NULL,*D3=NULL,*A1=NULL,*A2=NULL;
  struct Related *New=(struct Related *)malloc(sizeof(struct Related));
  struct Datablock *DB=NULL;
  struct Sentence *SenStruct=NULL;

  /* Populate the new record */
  New->AffectedSentences=NULL;
  New->Targets=NULL;
  New->CanonicalTargets=NULL;
  New->CSVerbs=GenerateCSVerbs();
  New->CSNouns=GenerateCSNouns(New->CSVerbs);

  /* breaks up the sentence into subject and predicate */
  SenStruct=ConvertSentence(Last_Sentence,1,1);
  S=SenStruct->RefinedSubject;
  PN=SenStruct->RefinedPredicate;

  /* Extracts a list of affected Sentences */
  for(Buffer=New->CSVerbs;Buffer;Buffer=Buffer->Next){
    FreeMe=StrCat("_examples_",Buffer->Str);
    DB=Goto_DB_Entry(Database[0],FreeMe);
    free(FreeMe);
    for(B2=DB->DS[2],B3=DB->DS[1];B3;B3=B3->Next,B2=B2->Next){
      for(B1=Str2List(B3->Str);B1;B1=B1->Next){
	D2=IntCSRecon(B1->Str);
	D1=IntCSRecon(B2->Str);
	D3=IntCSRecon(Buffer->Str);
	Flag=0;
	if(Comp_Sem_Subject(D1,S)||Comp_Sem_Subject(D2,S)){
	  New->CanonicalTargets=Add2Set(New->CanonicalTargets,List2Str(S));
	  Flag=1;
	}
	if(Comp_Sem_Subject(D1,PN)||Comp_Sem_Subject(D2,PN)){
	  New->CanonicalTargets=Add2Set(New->CanonicalTargets,List2Str(PN));
	  Flag=1;
	}
	if(Flag){
	  New->Targets=Add2Set(New->Targets,List2Str(ExtractArticles(D1,FILTERNOUNSONLY)));
	  New->Targets=Add2Set(New->Targets,List2Str(ExtractArticles(D2,FILTERNOUNSONLY)));
	  A1=Ins_List_Element(NULL,List2Str(D1),0);
	  A2=Ins_List_Element(NULL,List2Str(D2),0);
	  New->AffectedSentences=Add2Set(New->AffectedSentences,List2Str(Convert2Sentence(CreateSentenceStruct(A1,0,A2,0,D3,SenStruct->Tense,"indicative"))));
	}
      }
    }
  }
  return New;
}

/*! \brief Go through all the sentences and find those relevent to the current conversation topic.
 * 
 */
struct List_Str *SenOutTopic(){
  int Found=0;
  struct List_Str *Buffer=NULL,*ThisSentence=NULL,*TopicList=NULL,*Buffer2=NULL,*FoundSentences=NULL;
  ENABLEOUT=0;
  Topic(NULL,NULL);
  ENABLEOUT=1;
  TopicList=ANSWER;
  ListSentences(CSList(),NULL);
  for(Buffer=ANSWER;Buffer;Buffer=Buffer->Next){
    CS2Sentence(Str2List(Buffer->Str),NULL);
    for(ThisSentence=ANSWER;ThisSentence;ThisSentence=ThisSentence->Next){
      Found=0;
      for(Buffer2=TopicList;Buffer2;Buffer2=Buffer2->Next)
	if(strstr(ThisSentence->Str,Buffer2->Str)){
	  Found=1;
	  break;
	}
      if(!Found)
	FoundSentences=Add2Set(FoundSentences,ThisSentence->Str);
    }
  }
  return FoundSentences;
}

/*! \brief Find the semantic pathways between two words using sentences from ENiX.
 * 
 */
struct List_Str *SPath(struct List_Str *Word_List,struct List_Str *L){
   int _=0;
   char *Start=NULL,*Finish=NULL;
   struct List_Str *CSVerbs=NULL,*CSNouns=NULL;
   struct Meanings *Thoughts=NULL;
   Start=Word_List->Str;
   if(Word_List->Next){
      Finish=Word_List->Next->Str;
      CSNouns=GenerateCSNouns(CSVerbs=GenerateCSVerbs());
      Thoughts=Optimise_Spline(S_Spline(Start,Finish,Ins_List_Element(NULL,"?",0),CSVerbs,CSNouns));
      if(Thoughts){
	for(_=0;_<Thoughts->Size;_++){
	  printf("Chain of thoughts %d:\n",_);
	  PrintListSpecial("",Thoughts->Conversations[_],"\n","\n","\n");
	}
      }
      Last_Thoughts=Thoughts;
   }      
   else
      if(ThinkOutLoud) puts("SPATH: Needs two input parameters!");
   return L;
}

/*! \brief Find the shortest semantic pathways between two words using sentences from ENiX.
 * 
 */
struct List_Str *ShortPath(struct List_Str *Word_List,struct List_Str *L){
   int _=0,C=0,Size=0;
   struct List_Str *Shortest=NULL;
   if(Last_Thoughts)
     for(_=0;_<Last_Thoughts->Size;_++){
	if(Shortest){
	   if((C=Size_of_List(Last_Thoughts->Conversations[_]))<Size){
	      Size=C;
	      Shortest=Last_Thoughts->Conversations[_];
	   }
	}
	else{
	   Size=Size_of_List(Last_Thoughts->Conversations[_]);
	   Shortest=Last_Thoughts->Conversations[_];
	}
     }
   ANSWER=Shortest;
   return L;
}

/*! \brief Return a virtual database of records semantically related to Cond.
 *  - Does not handle semantic simularities yet.
 */
struct Datablock *ConditionallyRelated(struct Conditional *Cond){
  int Found=0;
  struct List_Str *CauseList=NULL,*EffectList=NULL,*ExpandedCause=NULL;
  struct Datablock *VirtualDB=NULL,*DB=NULL;
  for(DB=Database[0];DB;DB=DB->Next){
    if(!strncmp(DB->DS[0]->Str,":observ_",8)){
      /* has to many:one wrt cause:effect */
      for(CauseList=Cond->CauseSymbols;CauseList;CauseList=CauseList->Next)
	for(ExpandedCause=DB->DS[1];ExpandedCause;ExpandedCause=ExpandedCause->Next)
	  if(Is_List_Element(Str2List(ExpandedCause->Str),CauseList->Str))
	    Found=1;
      for(EffectList=Cond->EffectSymbols;EffectList;EffectList=EffectList->Next)
	if((!strcmp(DB->DS[0]->Str+8,EffectList->Str))||(!strcmp(DB->DS[0]->Str+8,EffectList->Str+1)))
	  Found=1;
    }
    if(Found){
      VirtualDB=Add2VirtDB(VirtualDB,DB);
      Found=0;
    }
  }
  return VirtualDB;
}

/*! \brief Return a virtual database of records semantically related to the Cond cause.
 *  - Does not handle semantic simularities yet.
 */
struct Datablock *ConditionallyCauseRelated(struct Conditional *Cond){
  struct List_Str *CauseBuffer=NULL,*RecCauses=NULL;
  struct Datablock *VDB=NULL,*DB=NULL;
  if(!Cond->CauseSymbols)
    return NULL;
  for(DB=Database[0];DB;DB=DB->Next){
    if(!strncmp(DB->DS[0]->Str,":observ_",8))
      for(CauseBuffer=Cond->CauseSymbols;CauseBuffer;CauseBuffer=CauseBuffer->Next)
	for(RecCauses=DB->DS[1];RecCauses;RecCauses=RecCauses->Next)
	  if(Is_List_Element(Str2List(RecCauses->Str),CauseBuffer->Str)){
	    VDB=Add2VirtDB(VDB,DB);
	    goto WhyDoesntCHaveABreakN;
	  }
    WhyDoesntCHaveABreakN:;
  }
  return VDB;
}

/*! \brief Return a virtual database of records semantically related to the Cond effect.
 *  - Does not handle semantic simularities yet.
 */
struct Datablock *ConditionallyEffectRelated(struct Conditional *Cond){
  char *EffectSymbol=NULL;
  struct List_Str *EffectBuffer=NULL;
  struct Datablock *VDB=NULL,*DB=NULL;
  if(!Cond->EffectSymbols)
    return NULL;
  for(EffectBuffer=Cond->EffectSymbols;EffectBuffer;EffectBuffer=EffectBuffer->Next)
    for(DB=Database[0];DB;DB=DB->Next)
      if(!strncmp(DB->DS[0]->Str,":observ_",8)){
	if(EffectBuffer->Str[0]=='n')
	  EffectSymbol=EffectBuffer->Str+1;
	else
	  EffectSymbol=EffectBuffer->Str;
	if(!strcmp(EffectSymbol,DB->DS[0]->Str+8)){
	  VDB=Add2VirtDB(VDB,DB);
	  break;
	}
      }
  return VDB;
}


/*! \brief Check if all the sentences in Source semantically equivalent to Target sentences
 * - Note inputs need to be a list of context addressible memory representations of sentences.
 */
int AreAllSentSimilar(struct List_Str *Source,struct List_Str *Target){
  int FoundHere=0;
  struct List_Str *Buffer1=NULL,*Buffer2=NULL,*SRC=NULL,*DST=NULL;
  for(Buffer1=Source;Buffer1;Buffer1=Buffer1->Next){
    SRC=IntCSRecon(Buffer1->Str);
    FoundHere=0;
    for(Buffer2=Target;Buffer2;Buffer2=Buffer2->Next){
      DST=IntCSRecon(Buffer2->Str);
      if(IsSentenceSimilar(SRC,DST))
	FoundHere=1;
    }
    if(!FoundHere)
      return 0;
  }  
  for(Buffer1=Target;Buffer1;Buffer1=Buffer1->Next){
    SRC=IntCSRecon(Buffer1->Str);
    FoundHere=0;
    for(Buffer2=Source;Buffer2;Buffer2=Buffer2->Next){
      DST=IntCSRecon(Buffer2->Str);
      if(IsSentenceSimilar(SRC,DST))
	FoundHere=1;
    }
    if(!FoundHere)
      return 0;
  }
  return 1;
}


/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


*/
