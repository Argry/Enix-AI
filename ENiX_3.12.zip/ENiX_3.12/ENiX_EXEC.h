/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#ifndef ENiXEXEC
#define ENiXEXEC

#include "ENiX_BDEFS.h"

extern struct List_Str  *(*InstructionSet[])(struct List_Str *ContextPrefix,struct List_Str *ContextSuffix);

struct List_Str  *Answer(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Chocky(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Execute(struct List_Str *Pipe,struct List_Str *List);
struct List_Str  *Expand_Exp(char *Word);
struct List_Str  *Force(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Foreach(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Help(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *HelpExample(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *If(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Interpreter(struct List_Str *Com);
struct List_Str  *Math(struct List_Str *Word_List,struct List_Str *L); /* Paradigm Shifting */
struct List_Str  *Mutate(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Nothing(struct List_Str *Word_List,struct List_Str *L);
int              Paradox(char *Word,struct List_Str *Used,int Flags);
struct List_Str  *Read(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *RUN(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Swap(struct List_Str *Word_List,struct List_Str *L);
void             Save_Answer(struct List_Str *L);
struct List_Str  *Translate(struct List_Str *List);
struct List_Str  *Version(struct List_Str *Word_List,struct List_Str *L);

struct List_Str  *Unwrap(struct List_Str *WordList,struct List_Str *L);
struct List_Str  *Wrap(struct List_Str *WordList,struct List_Str *L);
struct List_Str  *SIGNAL(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Do(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Trans_First(struct List_Str *List,int Position);





#endif

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
