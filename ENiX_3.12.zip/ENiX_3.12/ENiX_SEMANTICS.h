/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#ifndef ENiXSEMANTICS
#define ENiXSEMANTICS

extern int VERBPOSTPROC;

struct List_Str *VerbTableAdd(struct List_Str *Word_List,struct List_Str *L);
char            *VerbTableGetAct(char *Mood,char *Verb,char *Qualifier);
struct List_Str *VerbPostProc(struct List_Str *Word_List,struct List_Str *L);
struct List_Str *SentenceAssign(struct List_Str *Word_List,struct List_Str *L);
struct List_Str *SentenceExplain(struct List_Str *Word_List,struct List_Str *L);
struct List_Str **QualifierPaths(char *Source,char *Target,struct List_Str *Used);
struct List_Str *SemPath(struct List_Str *Word_List,struct List_Str *L);

struct Related  *ListRelatedSentences(struct List_Str *Last_Sentence);

/* find sentences that arent in the topic */
struct List_Str *SenOutTopic();

/* Atomic Processing */
struct List_Str *AtomMeanList(char *Word, struct List_Str *Used);
struct List_Str *AtomMeanSame(char *Word1,char *Word2);
struct List_Str *AtomMeanLike(char *Word1,char *Word2);
struct List_Str *AtomMeanOppo(char *Word1,char *Word2);
struct List_Str *AtomMeanGeneric(char *Word1,char *Word2,char *Type);
struct List_Str  *SPath(struct List_Str *Word_List,struct List_Str *L);

/* Midlevel Processing */
struct List_Str *ListAllSemWords();
struct List_Str *ListSimilarWords(char *Word);
struct List_Str *IsVerbSimilar(char *V1,char *V2);
struct List_Str  *ShortPath(struct List_Str *Word_List,struct List_Str *L);

/* High Level Processing */
int             IsSentenceSimilar(struct List_Str *Source,struct List_Str *Target);
int             AreAllSentSimilar(struct List_Str *Source,struct List_Str *Target);

struct List_Str *NLPCauseWrap(struct List_Str *Word_List,struct List_Str *L);
struct List_Str *NLPAvoidWrap(struct List_Str *Word_List,struct List_Str *L);

struct Datablock *ConditionallyRelated(struct Conditional *Cond);
struct Datablock *ConditionallyCauseRelated(struct Conditional *Cond);
struct Datablock *ConditionallyEffectRelated(struct Conditional *Cond);

#endif

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
