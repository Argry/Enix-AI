/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/
       
#ifndef ENiXREASON
#define ENiXREASON

struct ReasonTree {
  int NodeSize;
  struct List_Str *Sentence;
  struct List_Str *Common;
  struct ReasonTree *Prev;
  struct ReasonTree **Next;
};

struct ReasonTree *NewTreeSentence();
struct ReasonTree *AddTreeSentence(struct ReasonTree *Tree,struct List_Str *Sentence,struct List_Str *Common);
struct ReasonTree *AddTreeNext(struct ReasonTree *Root,struct ReasonTree *Leaf);

struct ReasonTree *TreeRecurse(struct ReasonTree *Leaf,struct List_Str *SentenceList);

struct List_Str   *TreeGenerate(struct List_Str *Word_List,struct List_Str *L);
void              TreeDebug(struct ReasonTree *Leaf,int Level);


/* Top level new reasoning */
struct List_Str *ProcessReasoning(struct List_Str *Sentence);
struct List_Str *DeductiveReasoning(struct Conditional *ConvertedSentence);
struct List_Str *ReductiveReasoning(struct Conditional *ConvertedSentence);
struct List_Str *YNReasoning(struct Conditional *ConvertedSentence);

/* OLD PROCESSING BELOW - WARNING: NOT CORRECT */

/* 
**************************************************************************************************************
   This function lists possible routes from source to targets based on MEANING not just literal symbols

   - Available       = List of all csvalues of sentences.
   - ReturnSize      = Size of struct List_Str ** returned.
   - Source / Target = these have to be sentences. 

   This is a many to many function, so is best used in avoiding situation, as it optimistically avoids
   as many causes as possible!
**************************************************************************************************************
*/

struct List_Str **NLPCauseM2M(struct List_Str *Source,struct List_Str *Target,struct List_Str *Available,int *ReturnSize);


/* 
**************************************************************************************************************
   This function lists exact, known routes from source to target based on word matches

   - Available       = List of all csvalues of sentences.
   - ReturnSize      = Size of struct List_Str ** returned.
   - Source / Target = these have to be sentences. 

   This is a one to one function, so is a prefered method in seeking situations and finding causes.
**************************************************************************************************************
*/

struct List_Str **NLPCauseO2O(struct List_Str *Source,struct List_Str *Target,struct List_Str *Available,int *ReturnSize);

/* 
**************************************************************************************************************
   This function lists known and likely routes from source to target based on word matches

   - Available       = List of all csvalues of sentences.
   - ReturnSize      = Size of struct List_Str ** returned.
   - Source / Target = these have to be sentences. 

   This is a one to many function, so is a prefered method in creating novel ways to solve problems.
**************************************************************************************************************
*/

struct List_Str **NLPCauseO2M(struct List_Str *Source,struct List_Str *Target,struct List_Str *Available,int *ReturnSize);

/* 
**************************************************************************************************************
   This function lists likely routes from source to target based on word matches excluding the known ones

   - Available       = List of all csvalues of sentences.
   - ReturnSize      = Size of struct List_Str ** returned.
   - Source / Target = these have to be sentences. 

   This function subtracts the O2O results from the M2M, thereby providing alternative methods for solving.
**************************************************************************************************************
*/

struct List_Str **NLPCauseAlt(struct List_Str *Source,struct List_Str *Target,struct List_Str *Available,int *ReturnSize);

#endif

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
