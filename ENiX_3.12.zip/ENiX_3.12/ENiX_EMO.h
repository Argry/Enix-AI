/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#ifndef EMO
#define EMO

/* Emotional Emulation */
struct Feeling{
   struct List_Str *EmotionList;
   char *DominantName;
   int DominantEmo;
};

extern struct Feeling FeelingTemplate;

struct ConceptE{
  /* Cardinalities */
   int BeforeSize;
   int AfterSize;
   int UnchangedSize;
  /* Overall Emotional Value */
   struct List_Str *EmoTB;
   struct List_Str *EmoTA;
   struct List_Str *EmoTU;
   struct List_Str *EmoTD;
  /* Conversations */
   struct List_Str **BConcepts;
   struct List_Str **AConcepts;
   struct List_Str **UConcepts;
  /* Emotion Data for Conversations */
   struct List_Str **EmoBConcepts;
   struct List_Str **EmoAConcepts;
   struct List_Str **EmoUConcepts;
};

extern struct ConceptE CETemplate;

struct EmoReady{
  int Empathetic_Targets;      /* Cardinalities */
  struct List_Str *Sentence;   /* Newly added sentence */
  /*
    Emotion Concepts
    (vector)
  */
  struct ConceptE **Empathetic_Target_List;
  /*
    Empathetic Summary Vectors 
    (each is a list of numbers not a list of vectors)
  */
  struct List_Str *EmoTB;
  struct List_Str *EmoTA;
  struct List_Str *EmoTU;
  struct List_Str *EmoTD;
};

extern struct EmoReady ERTemplate;

struct ConceptE  *Empathy(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SentenceEmotion(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *NormalizedEmo(struct List_Str *EmoVector);
struct ConvList  *ReconFromEmotion(struct EmoReady *EmpData,char *EmotionName,int Bitfield);
struct List_Str  *EmotionPathway(char *Start,char *Finish,struct List_Str *AvailableMoods,struct List_Str *Visited);
struct List_Str  *EmpathyWrapper(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *EmpathyPost(struct List_Str *Word_List,struct List_Str *L);
char             *EmotionCPU(int Type,struct EmoReady *E);
void             Associate_Emo(struct List_Str *L,struct Feeling *Dominant);
struct Feeling   *Detect_Dominant_Emo(struct List_Str *L);
void             ParseSentenceEmotion(struct List_Str *L);
void             InputFeedback(struct Feeling *Dominant);
void             AwarenessFeedback(int Understanding);
struct List_Str  *FindEmoSentence(struct List_Str *Word_List,struct List_Str *L);

/* Structure I/O */
void             FlushEmoDB(struct EmoReady *E);
void             FlushConceptE(char *Name,struct ConceptE *E);
struct ConceptE  *LoadConceptE(char *Name);
void             LoadEmoDB();
struct ConceptE  *ZeroConceptE();
struct EmoReady  *ZeroEmoReady();
struct ConceptE  *PopConceptE(struct ConceptE *Blank,struct List_Str *LastSentence);
struct EmoReady  *PopEmoReady(struct EmoReady *Blank,struct List_Str *LastSentence,struct List_Str *Topic);

/* Vector and Emotion Name Conversion */
struct List_Str  *Vec2Emo(struct List_Str *Word_List,struct List_Str *L);
char             *ReportEmotionName(struct List_Str *EmotionVector);

/* Top-Level Emotion Processing Functions */
/* Calculates the nature of the response required */
void             EvalResponse(struct EmoReady *EmpData,char *EmoResponse);
void             ComputeEmoResp(struct EmoReady *EmpData,struct List_Str *EmoDiff);

/* Sees if there are reassuring things to say from LTM */
struct List_Str  *ComputeOOa(char *EmotionName);
struct List_Str  *EmoUnderstanding(struct EmoReady *EmpData,struct List_Str *EmoData);
struct List_Str  *EmoMorality(struct EmoReady *EmpData,struct List_Str *EmoData);
struct List_Str  *EmoMortality(struct EmoReady *EmpData,struct List_Str *EmoData);
struct List_Str  *EmoAction(struct EmoReady *EmpData,struct List_Str *EmoData);
struct List_Str  *EmoDetermination(struct EmoReady *EmpData,struct List_Str *EmoData);

/* Debugging */
struct List_Str  *EmpathyDebug(struct List_Str *Word_List,struct List_Str *L);
void             DebugCE(struct ConceptE *E);
struct List_Str  *DebugEmotionCache(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *EmoDebugVec(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *EmpathyInj(struct List_Str *Word_List,struct List_Str *L);

void             DisplayEmotion();

/* New Emotion Concepts */
struct List_Str  *EmotionMapper(struct List_Str *Word_List,struct List_Str *L);


#endif

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
