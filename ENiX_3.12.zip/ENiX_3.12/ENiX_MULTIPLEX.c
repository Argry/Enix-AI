/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2015.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "ENiX_Globals.h"
#include "ENiX_STRING.h"
#include "ENiX_MULTIPLEX.h"
#include "ENiX_NLP.h"
#include "ENiX_WMS.h"
#include "ENiX_LIST.h"
#include "ENiX_WMS_COMPAT.h"
#include "ENiX_SETTHEORY.h"
#include "ENiX_CS.h"
#include "ENiX_ANALYSER.h"
#include "ENiX_APPLICATIONS.h"
#include "ENiX_SEMANTICS.h"
#include "ENiX_VirtualDB.h"

extern char *LogicNLPStartStr[];
extern char *LogicNLPEndStr[];

/*! \brief Create an array of functions to handle understanding responses.
 *
 */
struct List_Str *(*UnderstandingResponses[])(struct Sentence *SData)={Confused,Curious,Understood};

/*! \brief Multiplex indicative sentences.
 *
 */
void MultiplexIndicative(struct Sentence *SData){
 int Negation=0,SubExists=0,PredExists=0,InitialVerbosity=0;
 char *RecordName=NULL,*LearntName=NULL,*QualStr=NULL,*NullOutcome=NULL;
 struct List_Str *Qualifiers=NULL,*Values=NULL,*Buffer=NULL;
 struct Datablock *DB=NULL;

 InitialVerbosity=DetectVerbosity();

 /* determine the record name and create the record if necessary */
 RecordName=StrCat("_examples_",SData->VerbCSNum);
 LearntName=StrCat("_enix_",SData->VerbCSNum);
 if(!(DB=Goto_DB_Entry(Database[0],RecordName)))
   DB=Database[0]=Add_DB_Entry(Database[0],RecordName);
 /* determine if there are any nothing operators */
 SubExists=!Is_List_Element(Str2List(List2Str(SData->RefinedSubject)),"nothing");
 PredExists=!Is_List_Element(Str2List(List2Str(SData->RefinedPredicate)),"nothing");
 /* convert the subject and predicatenoun data into CS records */
 if(SubExists){
   for(Buffer=SData->RefinedSubject;Buffer;Buffer=Buffer->Next)
     Qualifiers=Ins_List_Element(Qualifiers,CSCreate(Str2List(Buffer->Str)),0);
   Qualifiers=SortList(Qualifiers);
 }
 else
   Qualifiers=Ins_List_Element(Qualifiers,":NULL",0);
 if(PredExists){
   for(Buffer=SData->RefinedPredicate;Buffer;Buffer=Buffer->Next)
     Values=Ins_List_Element(Values,CSCreate(Str2List(Buffer->Str)),0);
   Values=SortList(Values);
 }
 else
   Values=Ins_List_Element(Values,":NULL",0);
 /* determine if there is negation at work */
 Negation=(SData->Negation)?1:(SData->SubjectLogic==2)?1:0;
 /* populate the data */
 QualStr=List2Str(Qualifiers);
 for(Buffer=Values;Buffer;Buffer=Buffer->Next){
   /* delete negated pairings */
   NullOutcome=StrCat(":NULL_",Buffer->Str);
   if(Negation){
     if(Is_DB_Pair(DB,QualStr,Buffer->Str)){
       /* need to implement argue here */
       Del_DB_Pair(DB,QualStr,Buffer->Str);
     }
     if(Is_DB_Pair(DB,QualStr,NullOutcome))
       if(InitialVerbosity)
	 OutputAnswer("",Str2List("i know")," "," ",".",0);
     Add_DB_Pair(DB,QualStr,NullOutcome);
   }
   else{
     Del_DB_Pair(DB,QualStr,NullOutcome);
     if(Is_DB_Pair(DB,QualStr,Buffer->Str))
       if(InitialVerbosity)
	 OutputAnswer("",Str2List("i know")," "," ",".",0);
     Add_DB_Pair(DB,QualStr,Buffer->Str);
   }
 }
 /* need to multiplex a model */
 /* save the status of the learning process */
 if(Multiplex2ANN(RecordName,LearntName))
   Rep_List_Element(DB->DS[0],"OK",1);
 else
   Rep_List_Element(DB->DS[0],"NOT OK",1);   

 /* recently added */

 GenerateResponse(SData);

}

/*! \brief Convert the multiplexed data into a neural network.
 *
 */
int Multiplex2ANN(char *Examples,char *LearntRec){  
  struct List_Str *Sequence=NULL,*AllCauses=NULL,*AllEffects=NULL;
  struct Datablock *DB=NULL;

  /* open the record, disambiguate, collect the symbols, remove :NULL and duplicates */
  DB=Goto_DB_Entry(Database[0],Examples);
  AllCauses=SortList(RemoveDups(SetExclude(Str2List(List2Str(DB->DS[1])),Str2List(":NULL"))));
  AllEffects=SortList(RemoveDups(ListStripPrefix(SetExclude(Str2List(List2Str(DB->DS[2])),Str2List(":NULL")),":NULL_")));

  /* Multiplex Sequence */
  Sequence=MultiplexedSequence(Examples);
  
  /* learn the sequence */
  Decision_Maker(Ins_List_Element(Sequence,LearntRec,0),NULL);

  /* create a pattern with the learnt NN and store symbols */
  DB=Goto_DB_Entry(Database[0],LearntRec);
  DB->DS[1]=AllCauses;
  DB->DS[2]=AllEffects; 

  return VerifyLearnt(Sequence,LearntRec);
}

/*! \brief Check that the learnt neural network models the multiplexed data.
 *
 */
int VerifyLearnt(struct List_Str *Examples,char *LearntConcept){
  int Size=Size_of_List(Examples),_=0;
  struct List_Str *Domain=NULL;
  struct Datablock *DB=NULL;
  DB=Goto_DB_Entry(Database[0],LearntConcept);
  if(!(DB->DS[1]&&DB->DS[2]))
    return 0;
  for(_=0;_<Size;_++)
    Domain=Append_List_Element(Domain,FloatToString(_));
  Decide(Domain,Str2List(LearntConcept));
  return Same_Examples(Examples,ANSWER);
}

/*! \brief Determine the solution to a yes / no query using the neural network.
 *
 */
int IsMultiplexQuery(struct Sentence *SData){
  int PredExists=0,SubExists=0,NumEffects=0,SameNum=0,_=0,FallbackResult=0;
  int ComputedEffect=0,RequiredEffect=0;
  char *LearntName=NULL,*ExampleRec=NULL;
  struct List_Str *Causes=NULL,*Effects=NULL,*MultiCauses=NULL,*MultiEffects=NULL,*B1=NULL,*B2=NULL;
  struct Datablock *DB=NULL;

  /* Compute fallback logic */
  FallbackResult=YNQueryFallback(SData);
  if(MULTIPLEXSWITCH==0)
    return FallbackResult;
  if(MULTIPLEXSWITCH==1)
    if(FallbackResult)
      return 1;
  if(MULTIPLEXSWITCH==2){}    

  /* locate the stored ANN, quit with a false if not found */
  ExampleRec=StrCat("_examples_",SData->VerbCSNum);
  if(!(DB=Goto_DB_Entry(Database[0],ExampleRec)))
    return 0;
  if(!strcmp(Get_DB_Entry(DB,0,1),"NOT OK"))
    return 0;

  /* locate the stored ANN, quit with a false if not found */
  LearntName=StrCat("_enix_",SData->VerbCSNum);
  if(!(DB=Goto_DB_Entry(Database[0],LearntName)))
    return 0;

  /* determine if there are any nothing operators */
  SubExists=!Is_List_Element(Str2List(List2Str(SData->RefinedSubject)),"nothing");
  PredExists=!Is_List_Element(Str2List(List2Str(SData->RefinedPredicate)),"nothing");

  /* separate out subject logic */
  if(SubExists){
    Causes=MultiplexSymbols(DB->DS[1],SData->RefinedSubject);
    if(SData->SubjectLogic){
      /* this is not an AND so subjects have to be evaluated individually */
      MultiCauses=Causes;
    }
    else{
      /* if one of the subject symbols does not exist and it is and AND */
      if(Is_List_Element(Causes,"0"))
	return 0;
      /* This is an AND so all must match */
      for(_=0,B1=Causes;B1;B1=B1->Next)
	_+=atoi(B1->Str);
      if(!_)
	return 0;
      MultiCauses=Str2List(FloatToString(_));
    }
  }
  else
    MultiCauses=Str2List("0");

  /* calculate causes of which there is only one */
  if(PredExists){
    Effects=MultiplexSymbols(DB->DS[2],SData->RefinedPredicate);
    for(_=0,B1=Effects;B1;B1=B1->Next)
      _+=atoi(B1->Str);
    MultiEffects=Str2List(FloatToString(_));
  }
  else
    MultiEffects=Str2List("0");

  /* evaluate effect(s) from cause(s) */
  Decide(MultiCauses,Str2List(LearntName));

  /* separate out effect logic */
  NumEffects=Size_of_List(ANSWER);
  RequiredEffect=atoi(MultiEffects->Str);
  for(B1=ANSWER,B2=MultiCauses;B1&&B2;B1=B1->Next,B2=B2->Next){
    ComputedEffect=atoi(B1->Str);
    if(atof(B2->Str)||(SubExists==0)){
      /* if the predicate exists in the question */
      if(PredExists){
	/* then there must be a multiplexed effect */
	if(RequiredEffect){
	  /* and if the queried effect is in the computed effect */
	  SameNum+=((ComputedEffect&RequiredEffect)==RequiredEffect);
	}
      }
      /* if the predicate is nothing */
      else
	SameNum+=(ComputedEffect==RequiredEffect);
    }
  }
  if(SData->SubjectLogic==M_AND)
    return SameNum==NumEffects;
  if(SData->SubjectLogic==M_OR)
    return !!SameNum;
  if(SData->SubjectLogic==M_NOR)
    return (SameNum==0);
  if(SData->SubjectLogic==M_XOR)
    return (SameNum==1);
  return 0;
}

/*! \brief In case WH-Question neural network process fails, we have a fallback for retrieving the data from the multiplexor.
 *
 */
struct List_Str *WHQueryFallback(struct Sentence *SData){
  int C=0,Found=0,MatchedCauses=0,MatchedEffects=0;
  char *ExampleName=NULL;
  struct List_Str *R=NULL,*SeekCause=NULL,*SeekEffect=NULL,*B1=NULL,*B2=NULL,*B3=NULL,*B4=NULL;
  struct List_Str *ExamCause=NULL,*ExamEffect=NULL,*Subject=NULL,*Predicate=NULL,*B5=NULL;
  struct Datablock *DB=NULL;

  /* if possible locate causes and effects, else abandon with a don't know */
  ExampleName=StrCat("_examples_",SData->VerbCSNum);  
  DB=Goto_DB_Entry(Database[0],ExampleName);
  free(ExampleName);
  if(!DB)
    return NULL;  
  if(SData->PassiveVoice)
    SeekCause=SData->RefinedSubject;
  else
    SeekEffect=SData->RefinedPredicate;
  B5=SeekCause;
  C=0;
  for(SeekCause=NULL;B5;B5=B5->Next){
    if(!strcmp(B5->Str,"nothing"))
      SeekCause=Ins_List_Element(SeekCause,":NULL",C++);
    else
      SeekCause=Ins_List_Element(SeekCause,B5->Str,C++);
  }
  B5=SeekEffect;
  C=0;
  for(SeekEffect=NULL;B5;B5=B5->Next){
    if(!strcmp(B5->Str,"nothing"))
      SeekEffect=Ins_List_Element(SeekEffect,":NULL",C++);
    else
      SeekEffect=Ins_List_Element(SeekEffect,B5->Str,C++);
  }

  /* go through all the example pairs */
  for(B1=DB->DS[1],B2=DB->DS[2];B1&&B2;B1=B1->Next,B2=B2->Next){
    MatchedCauses=0;
    MatchedEffects=0;
    Found=0;
    if(SeekCause){
      /* Go through the known causes */
      for(B3=Str2List(B1->Str);B3;B3=B3->Next){
	/* expand them out */
	ExamCause=IntCSRecon(B3->Str);
	for(B4=SeekCause;B4;B4=B4->Next)
	  MatchedCauses+=IntSubset(Str2List(B4->Str),ExamCause);
      }
      /* added to narrow down the search */
      if(Size_of_List(Str2List(B1->Str))==MatchedCauses)
	MatchedEffects=Size_of_List(SData->RefinedPredicate);
      else
	MatchedEffects=Size_of_List(SData->RefinedPredicate)-1;
    }
    if(SeekEffect){
      /* Go through the known effects */
      for(B3=Str2List(B2->Str);B3;B3=B3->Next){
	/* expand them out */
	ExamEffect=IntCSRecon(B3->Str);
	for(B4=SeekEffect;B4;B4=B4->Next)
	  MatchedEffects+=IntSubset(Str2List(B4->Str),ExamEffect);
      }
    }
    /* add the sentence data to answers, R */
    if(Size_of_List(SData->RefinedPredicate)==MatchedEffects){
      /* check the subject */
      if(SData->SubjectLogic==M_AND)
	Found=(MatchedCauses==Size_of_List(SeekCause));
      if(SData->SubjectLogic==M_OR)
	Found=(!!MatchedCauses);
      if(SData->SubjectLogic==M_NOR)
	Found=(MatchedCauses==0);
      if(SData->SubjectLogic==M_XOR)
	Found=(MatchedCauses==1);
    }
    if(Found){
      Subject=Predicate=NULL;
      for(B3=Str2List(B1->Str);B3;B3=B3->Next)
	Subject=Add2Set(Subject,List2Str(IntCSRecon(B3->Str)));
      for(B3=Str2List(B2->Str);B3;B3=B3->Next)
	Predicate=Add2Set(Predicate,List2Str(IntCSRecon(B3->Str)));
      B5=Subject;
      C=0;
      for(Subject=NULL;B5;B5=B5->Next){
	if(!strcmp(B5->Str,":NULL"))
	  Subject=Ins_List_Element(Subject,"nothing",C++);
	else
	  Subject=Ins_List_Element(Subject,B5->Str,C++);
      }
      B5=Predicate;
      C=0;
      for(Predicate=NULL;B5;B5=B5->Next){
	if(!strcmp(B5->Str,":NULL"))
	  Predicate=Ins_List_Element(Predicate,"nothing",C++);
	else
	  Predicate=Ins_List_Element(Predicate,B5->Str,C++);
      }
      R=Add2Set(R,List2Str(Convert2Sentence(CreateSentenceStruct(Subject,0,Predicate,0,SData->RefinedVerb,SData->Tense,"indicative"))));
    } 
  }
  return R;
}

/*! \brief In case YN-Question neural network process fails, we have a fallback for retrieving the data from the multiplexor.
 *
 */
int YNQueryFallback(struct Sentence *SData){
  int AllFound=0,SubFound=0,PredFound=0,C=0;
  char *ExampleName=NULL;
  struct List_Str *B1=NULL,*B2=NULL,*Subj=NULL,*Pred=NULL,*Buffer=NULL,*ExpSub=NULL,*KnownSub=NULL;
  struct List_Str *ExpPred=NULL,*KnownPred=NULL,*SearchCause=NULL,*SearchEffect=NULL;
  struct Datablock *DB=NULL;
  ExampleName=StrCat("_examples_",SData->VerbCSNum);  
  if(!(DB=Goto_DB_Entry(Database[0],ExampleName)))
    return 0;
  /* Substitute nothings */
  for(B1=SData->RefinedSubject,C=0;B1;B1=B1->Next){
    if(!strcmp(B1->Str,"nothing"))
      SearchCause=Ins_List_Element(SearchCause,":NULL",C++);
    else
      SearchCause=Ins_List_Element(SearchCause,B1->Str,C++);
  }
  for(B1=SData->RefinedPredicate,C=0;B1;B1=B1->Next){
    if(!strcmp(B1->Str,"nothing"))
      SearchEffect=Ins_List_Element(SearchEffect,":NULL",C++);
    else
      SearchEffect=Ins_List_Element(SearchEffect,B1->Str,C++);
  }
  /* for each example pair */
  for(B1=DB->DS[1],B2=DB->DS[2];B1&&B2;B1=B1->Next,B2=B2->Next){
    SubFound=0;
    PredFound=0;
    /* for each subject in the question */
    for(Subj=SearchCause;Subj;Subj=Subj->Next){
      ExpSub=Str2List(Subj->Str);
      /* for each element in the subject */
      for(Buffer=Str2List(B1->Str);Buffer;Buffer=Buffer->Next){
	/* expand it out */
	KnownSub=IntCSRecon(Buffer->Str);
	/* if ALL the elements in the ExpSub are in KnownSub */
	SubFound+=IntSubset(ExpSub,KnownSub);
      }
    }
    for(Pred=SearchEffect;Pred;Pred=Pred->Next){
      ExpPred=Str2List(Pred->Str);
      /* for each element in the predicate */
      for(Buffer=Str2List(B2->Str);Buffer;Buffer=Buffer->Next){
	/* expand it out */
	KnownPred=IntCSRecon(Buffer->Str);
	/* if ALL the elements in the ExpPred are in KnownPred */
	PredFound+=IntSubset(ExpPred,KnownPred);
      }      
    }
    if(PredFound){
      if(SData->SubjectLogic==M_AND)
	if((SubFound==Size_of_List(Str2List(B1->Str)))&&(SubFound==Size_of_List(SData->RefinedSubject)))
	  AllFound++;
      if(SData->SubjectLogic==M_OR)
	if(!!SubFound)
	  AllFound++;
      if(SData->SubjectLogic==M_NOR)
	if(SubFound==0)
	  AllFound++;
      if(SData->SubjectLogic==M_XOR)
	if(SubFound==1)
	  AllFound++;
    }
  }
  if(AllFound==Size_of_List(SData->RefinedPredicate))
    return 1;
  return 0;
}

/*! \brief Multiplex WH-Query and process the solution.
 *
 */
struct List_Str *MultiplexQuery(struct Sentence *SData){
  int _=0,Max=0,C=0,Num=0,Flag=0,Required=0;
  char *LearntName=NULL,*ExampleRec=NULL,*EffectStr=NULL,*CauseStr=NULL;
  struct List_Str *Cause=NULL,*UnfoundCause=NULL,*Effect=NULL,*Multiplex=NULL,*B1=NULL,*B2=NULL,*Result=NULL;
  struct List_Str *FallbackResult=NULL;
  struct Datablock *DB=NULL;
  FallbackResult=WHQueryFallback(SData);
  if(MULTIPLEXSWITCH==0)
    return FallbackResult;
  if(MULTIPLEXSWITCH==1)
    if(FallbackResult)
      return FallbackResult;
  if(MULTIPLEXSWITCH==2){}    

  /* locate the stored ANN, quit with a false if not found */
  ExampleRec=StrCat("_examples_",SData->VerbCSNum);
  if(!(DB=Goto_DB_Entry(Database[0],ExampleRec)))
    return NULL;
  if(!strcmp(Get_DB_Entry(DB,0,1),"NOT OK"))
    return NULL;

  /* see if the DB record can be located */
  LearntName=StrCat("_enix_",SData->VerbCSNum);  
  if(!(DB=Goto_DB_Entry(Database[0],LearntName)))
    return NULL;
  /* Multiplex the cause or effect appropriately */
  if(SData->PassiveVoice){
    /* if the outcome is specified (i.e. is passive voice) compute effect from cause */
    Multiplex=MultiplexSymbols(DB->DS[1],SData->RefinedSubject);
    if(!Is_List_Element(SData->RefinedSubject,"nothing"))
      if(Is_List_Element(Multiplex,"0"))
	return NULL;
    for(_=0,B1=Multiplex;B1;B1=B1->Next)
      _+=atoi(B1->Str);
    UnfoundCause=Str2List(FloatToString(_));
    Decide(UnfoundCause,Str2List(LearntName));
    /* work out the effect */
    Num=atoi(ANSWER->Str);
    if(!Num)
      Effect=Ins_List_Element(Effect,"nothing",0);
    for(C=0,B2=DB->DS[2];Num;C++,B2=B2->Next)      
      if((Num>>C)&1){
	EffectStr=List2Str(IntCSRecon(Get_List_Element(DB->DS[2],C)));
	Effect=Ins_List_Element(Effect,EffectStr,0);
	Num-=(1<<C);
      }
    Cause=SData->RefinedSubject;
    /* convert to sentences */
    Result=Add2Set(Result,List2Str(Convert2Sentence(CreateSentenceStruct(Cause,0,Effect,1,SData->RefinedVerb,SData->Tense,"indicative"))));
  }
  else{
    /* if the effect is specified (i.e. is active voice) list all causes that can cause the effect */
    Multiplex=MultiplexSymbols(DB->DS[2],SData->RefinedPredicate);
    if(!Multiplex)
      Multiplex=Str2List("0");
    /* go through all effects */
    for(B1=SData->RefinedPredicate;B1;B1=B1->Next){
      /* for each effect work out go through every combination of input */
      Max=1<<Size_of_List(DB->DS[1]);
      for(_=0;_<Max;_++){
	UnfoundCause=Str2List(FloatToString(_));
	Decide(UnfoundCause,Str2List(LearntName));
	/* work out if the output of the ANN matches the multiplexed value */
	Flag=0;
	if((Required=atoi(Multiplex->Str)))
	  Flag=((atoi(ANSWER->Str)&Required)==Required);
	else
	  Flag=(atoi(ANSWER->Str)==Required);
	if(Flag){
	  /* need to add the causes to a list */
	  Num=_;
	  UnfoundCause=NULL;
	  for(C=0,B2=DB->DS[1];Num;C++,B2=B2->Next)      
	    if((Num>>C)&1){
	      CauseStr=List2Str(IntCSRecon(Get_List_Element(DB->DS[1],C)));
	      UnfoundCause=Ins_List_Element(UnfoundCause,CauseStr,0);
	      Num-=(1<<C);
	    }
	  if(UnfoundCause)
	    Cause=Add2Set(Cause,List2Str(UnfoundCause));
	  else
	    Cause=Add2Set(Cause,"nothing");
	}
      }
    }
    Effect=SData->RefinedPredicate;
    /* if the are more than one causes then create many sentences */
    for(B1=Cause;B1;B1=B1->Next){
      Result=Add2Set(Result,List2Str(Convert2Sentence(CreateSentenceStruct(Str2List(B1->Str),0,Effect,0,SData->RefinedVerb,SData->Tense,"indicative"))));
    }
  }
  return Result;
}

/*! \brief Multiplex symbols into scalars.
 * - Symbols are articles of grammar such as nouns, pronouns, proper nouns etc.
 */
struct List_Str *MultiplexSymbols(struct List_Str *Symbols,struct List_Str *Clauses){
  int _=0,Pos=0,Found=0;
  struct List_Str *B1=NULL,*B2=NULL,*Causes=NULL,*ExpandedSub=NULL,*ExpandedSym=NULL;
  /* go through the subject data */
  for(B1=Clauses;B1;B1=B1->Next){
    ExpandedSub=Str2List(B1->Str);
    /* find these elements in the symbol table */
    Found=0;
    for(Pos=0,B2=Symbols;B2;B2=B2->Next,Pos++){
      ExpandedSym=IntCSRecon(B2->Str);
      /* do a partial multiplex */
      if(IntSubset(ExpandedSub,ExpandedSym)){
	Causes=Ins_List_Element(Causes,FloatToString(1<<Pos),_++);
	Found=1;
	break;
      }
    }
    if(!Found)
      Causes=Ins_List_Element(Causes,"0",_++);
  }
  return Causes;
}

/*! \brief Multiplex symbols into number sequences.
 * - Symbols are articles of grammar such as nouns, pronouns, proper nouns etc.
 */
struct List_Str *MultiplexedSequence(char *ExampleRec){
  int C=0,NumExamples=0,Cause=0,Effect=0;
  struct List_Str *AllCauses=NULL,*AllEffects=NULL,*Sequence=NULL,*B1=NULL,*B2=NULL,*B3=NULL;
  struct Datablock *DB=NULL;

  /* open the record, disambiguate, collect the symbols, remove :NULL and duplicates */
  DB=Goto_DB_Entry(Database[0],ExampleRec);
  AllCauses=SortList(RemoveDups(SetExclude(Str2List(List2Str(DB->DS[1])),Str2List(":NULL"))));
  AllEffects=SortList(RemoveDups(ListStripPrefix(SetExclude(Str2List(List2Str(DB->DS[2])),Str2List(":NULL")),":NULL_")));

  /* create a sequence of ?s */ 
  NumExamples=1<<Size_of_List(AllCauses);
  for(C=NumExamples;C;C--)
    Sequence=Ins_List_Element(Sequence,"?",0);

  /* multiplex the sequence */
  for(B1=RemoveDups(DB->DS[1]);B1;B1=B1->Next){
    Cause=Effect=0;
    for(B2=Str2List(B1->Str);B2;B2=B2->Next)
      if(Is_List_Element(AllCauses,B2->Str))
	if(Is_List_Element(AllCauses,B2->Str))
	  Cause+=1<<Find_List_Element(AllCauses,B2->Str);
    for(B2=DB->DS[1],B3=DB->DS[2];B2&&B3;B2=B2->Next,B3=B3->Next)
      if((!strcmp(B2->Str,B1->Str))&&(strncmp(":NULL_",B3->Str,6)))
	if(Is_List_Element(AllEffects,B3->Str))
	  Effect+=1<<Find_List_Element(AllEffects,B3->Str);
    Sequence=Rep_List_Element(Sequence,FloatToString(Effect),Cause);
  }  
  return Sequence;
}

/*! \brief Create a sequence of unknowns.
 * 
 */
struct List_Str *UnknownSequence(char *ExampleRec){
  int _=0;
  struct List_Str *Unknowns=NULL,*Buffer=NULL;
  for(_=0,Buffer=MultiplexedSequence(ExampleRec);Buffer;Buffer=Buffer->Next,_++)
    if(!strcmp(Buffer->Str,"?"))
      Unknowns=Append_List_Element(Unknowns,FloatToString(_));
  return Unknowns;
}

/*! \brief Create a Yes / No question from the neural network at scenerio "TPI".
 * 
 */
struct List_Str *FormYNQuestion(char *LearntRec,int TPI){
  int _=0,Effect=0;
  struct List_Str *Question=NULL,*Causes=NULL,*Buffer=NULL,*VerbData=NULL,*Predicate=NULL;
  struct Datablock *DB=NULL;
  
  /* first check that the verb concept is understood (i.e. Exists) */
  if(!(DB=Goto_DB_Entry(Database[0],LearntRec)))
    return NULL;

  /* need to calculate the output of the neural network at time parameterisation index (TPI) */
  Decide(Str2List(FloatToString(TPI)),Str2List(LearntRec));
  Effect=atoi(ANSWER->Str);

  /* dereference the context address of the verb (for sentence reconstruction) */
  VerbData=IntCSRecon(LearntRec+6);

  /* generate causation list for the TPI:
     list the corresponding causes associated with each bit of the TPI bytes */
  for(_=1,Buffer=DB->DS[1];TPI&&Buffer;_<<=1,Buffer=Buffer->Next)
    if(TPI&_){
      Causes=Append_List_Element(Causes,List2Str(IntCSRecon(Buffer->Str)));
      TPI-=_;
    }

  /* generate the effect list for the NN effect evaluated at the cause, TPI 
     list the corresponding causes associated with each bit of the effect bytes */
  for(_=1,Buffer=DB->DS[2];Effect&&Buffer;_<<=1,Buffer=Buffer->Next)
    if(Effect&_){
      Predicate=Append_List_Element(Predicate,List2Str(IntCSRecon(Buffer->Str)));
      Effect-=_;
    }

  /* if there are no articles add a zero article */
  if(!Causes)
    Causes=Append_List_Element(Causes,"nothing");
  if(!Predicate)
    Predicate=Append_List_Element(Predicate,"nothing");  

  /* generate and return the present tense yes / no question from the data */
  Question=Convert2Sentence(CreateSentenceStruct(Causes,0,Predicate,0,VerbData,1,"ynq"));
  return Question;
}

/*! \brief Create a WH question from the neural network at scenerio "TPI".
 * 
 */
struct List_Str *FormWHQuestion(char *LearntRec,int TPI){
  int _=0;
  struct List_Str *Question=NULL,*Causes=NULL,*Buffer=NULL,*VerbData=NULL,*Predicate=NULL;
  struct Datablock *DB=NULL;

  /* check that the concept is learnt */
  if(!(DB=Goto_DB_Entry(Database[0],LearntRec)))
    return NULL;
  
  VerbData=IntCSRecon(LearntRec+6);

  /* generate causation list */
  for(_=1,Buffer=DB->DS[1];TPI&&Buffer;_<<=1,Buffer=Buffer->Next)
    if(TPI&_){
      Causes=Append_List_Element(Causes,List2Str(IntCSRecon(Buffer->Str)));
      TPI-=_;
    }

  /* past = 0, present = 1, future = 2 */
  if(!Causes)
    Causes=Append_List_Element(Causes,"nothing");
  if(!Predicate)
    Predicate=Append_List_Element(Predicate,"nothing");  

  Question=Add2Set(Question,List2Str(Convert2Sentence(CreateSentenceStruct(Causes,0,Predicate,0,VerbData,1,"whq"))));
  
  return Question;
}

/*! \brief Determine the level of understanding of a neural network model and respond appropriately.
 * 
 */
struct List_Str *GenerateResponse(struct Sentence *SData){
  int UnderstandingLevel=0;
  UnderstandingLevel=IsConceptUnderstood(SData);
  /* this can be uncommented for Curious / Confused / Understood debugging
     do not leave this bypass in finished code */
  /* UnderstandingLevel=0; */
  return UnderstandingResponses[UnderstandingLevel](SData);
}

/*! \brief Determine the level of understanding of a neural network model.
 * 
 */
int IsConceptUnderstood(struct Sentence *SData){
  char *LearntName=NULL,*ExampleName=NULL;
  struct Datablock *DB=NULL;
  /* load the record data */
  ExampleName=StrCat("_examples_",SData->VerbCSNum);
  LearntName=StrCat("_enix_",SData->VerbCSNum);
  if(!(DB=Goto_DB_Entry(Database[0],ExampleName))){
    if(ThinkOutLoud)
      printf("ERROR GenerateResponse:%s:%d, unable to find %s\n",__FILE__,__LINE__,ExampleName);
    return 0;
  }
  /* first check if the concept has been correctly learnt */
  if(strcmp(Get_DB_Entry(DB,0,1),"OK"))
    return 0;
  /* formulate an understanding of the concept and execute */
  Understand(NULL,Str2List(LearntName));
  return atoi(ANSWER->Str);
}

/*! \brief Process curiousity.
 *  - The purpose of curiousity is to obtain data that will complete the neural networks understanding.
 */
struct List_Str *Curious(struct Sentence *SData){
  int TPI=0,C=0,Score=0,HighScore=0,TPIReg=0;
  struct List_Str *R=NULL,*Unknowns=NULL,*Buffer=NULL,*Question=NULL;
  char *LearntName=NULL,*ExampleName=NULL;
  /* need to formulate examples record name */
  ExampleName=StrCat("_examples_",SData->VerbCSNum);
  LearntName=StrCat("_enix_",SData->VerbCSNum);
  Unknowns=UnknownSequence(ExampleName);
  if(Unknowns){
    /* Cherry pick the most interesting question to ask */
    for(Buffer=Unknowns;Buffer;Buffer=Buffer->Next){
      for(Score=0,C=TPIReg=atoi(Buffer->Str);C;C>>=1)
	Score+=(C&1);
      if(Score>HighScore){
	HighScore=Score;
	TPI=TPIReg;
      }
    }
    /* need to formulate the question using FormQuestion() */
    Question=FormWHQuestion(LearntName,TPI);
    R=Add2Set(R,List2Str(Question));
    
    switch(DetectArgue()){
    case 2:
      OutputAnswer("",Question," "," ","",0);
      break;
    case 1:
      OutputAnswer("",Question," "," ","",1);
      break;
    case 0:
      break;
    }
  }
  return R;
}

/*! \brief Process confused.
 *  - The purpose of confused is to determine what additional data is required to understand the neural network concept.
 */
struct List_Str *Confused(struct Sentence *SData){
  char *LearntName=NULL,*ExampleName=NULL;
  struct List_Str *R=NULL,*Buffer=NULL,*Question=NULL;
  /* need to explain the method so far */
  ExampleName=StrCat("_examples_",SData->VerbCSNum);
  LearntName=StrCat("_enix_",SData->VerbCSNum);
  if(!Goto_DB_Entry(Database[0],LearntName))
    return NULL;  
  switch(DetectArgue()){
  case 2:
    puts("I am confused; if I understand correctly:");
    for(Buffer=ListExamples(ExampleName);Buffer;Buffer=Buffer->Next)
      OutputAnswer("",Str2List(Buffer->Str)," "," ",".",0);
    puts(" \nThe simplest explanation is:");
    Reason(Str2List(LearntName),NULL);
    puts(" \nIs this correct?");
    break;
  case 1:
    /* need to compute the oddman out */
    ODDMAN(NULL,Str2List(LearntName));
    if(isdigit(ANSWER->Str[0])){
      Question=FormYNQuestion(LearntName,atoi(ANSWER->Str));
      R=Add2Set(R,List2Str(Question));
      /* need to pose this as a question */    
      OutputAnswer("",Question," "," ","",0);
    }
    break;
  case 0:
    break;
  }
  return R;
}

/*! \brief Process understood.
 *  - The purpose of understood is to confirm that the neural network understands the information.
 */
struct List_Str *Understood(struct Sentence *SData){
  struct List_Str *R=NULL;
  /* not sure what to put here */
  switch(DetectArgue()){
  case 2:
    OutputAnswer("",Str2List("ok")," "," ",".",0);
    break;
  case 1:
    break;
  case 0:
    break;
  }
  return R;  
}

/*! \brief List the examples in the multiplexor that ENiX knows about.
 *  
 */
struct List_Str *ListExamples(char *ExampleRec){
  char *Cause=NULL,*Effect=NULL;
  struct List_Str *R=NULL,*B1=NULL,*B2=NULL,*VerbBlock=NULL;
  struct Datablock *DB=Goto_DB_Entry(Database[0],ExampleRec);
  if(DB){
    for(B1=DB->DS[1],B2=DB->DS[2];B1&&B2;B1=B1->Next,B2=B2->Next){
      if(strcmp(B1->Str,":NULL"))
	Cause=B1->Str;
      else
	Cause="nothing";
      if(strcmp(B2->Str,":NULL"))
	Effect=B2->Str;
      else
	Effect="nothing";
      VerbBlock=IntCSRecon(ExampleRec+10);
      R=Add2Set(R,List2Str(Convert2Sentence(CreateSentenceStruct(Str2List(Cause),0,Str2List(Effect),0,VerbBlock,1,"indicative"))));      
    }
  }
  return R;
}

/*! \brief Store conditional data ready for multiplexing or lookup
 *  
 */
void CacheConditional(struct Conditional *Cond){
  int Found=0,Observer=0,_=0,IsNeg=0;
  char *RecordTarget=NULL;
  struct List_Str *EffectList=NULL;
  struct Datablock *DB=NULL,*Lang=GetLang(),*VirtualDB=NULL,*RecordUpdate=NULL;
  if(Lang){
    /* Get a list of records we need to write to */
    VirtualDB=ConditionallyRelated(Cond);
    for(EffectList=Cond->EffectSymbols;EffectList;EffectList=EffectList->Next){
      Found=0;
      for(DB=VirtualDB;DB;DB=DB->Next){
	if(!strcmp(DB->DS[0]->Str+8,EffectList->Str)){
	  RecordUpdate=Goto_DB_Entry(Database[0],DB->DS[0]->Str);
	  if((_=Find_List_Element(DB->DS[1],List2Str(Cond->CauseSymbols)))+1){
	    if(!strcmp(Get_List_Element(DB->DS[2],_),"no"))
	      DB->DS[2]=Rep_List_Element(DB->DS[2],"yes",_);
	  }
	  else{
	    RecordUpdate->DS[1]=Append_List_Element(RecordUpdate->DS[1],List2Str(Cond->CauseSymbols));
	    RecordUpdate->DS[2]=Append_List_Element(RecordUpdate->DS[2],"yes");
	  }
	  Found=1;
	}
	else if(!strcmp(DB->DS[0]->Str+8,EffectList->Str+1)){
	  RecordUpdate=Goto_DB_Entry(Database[0],DB->DS[0]->Str);
	  if((_=Find_List_Element(DB->DS[1],List2Str(Cond->CauseSymbols)))+1){
	    if(!strcmp(Get_List_Element(DB->DS[2],_),"yes"))
	      DB->DS[2]=Rep_List_Element(DB->DS[2],"no",_);
	  }
	  else{
	    RecordUpdate->DS[1]=Append_List_Element(RecordUpdate->DS[1],List2Str(Cond->CauseSymbols));
	    RecordUpdate->DS[2]=Append_List_Element(RecordUpdate->DS[2],"no");
	  }
	  Found=1;
	}
      }
      if(!Found){
	/* add a record to the database */
	IsNeg=(EffectList->Str[0]=='n');
	RecordTarget=StrCat(":observ_",EffectList->Str+IsNeg);
	Database[0]=Add_DB_Entry(Database[0],RecordTarget);
	Database[0]->DS[1]=Append_List_Element(Database[0]->DS[1],List2Str(Cond->CauseSymbols));
	if(IsNeg)
	  Database[0]->DS[2]=Append_List_Element(Database[0]->DS[2],"no");
	else
	  Database[0]->DS[2]=Append_List_Element(Database[0]->DS[2],"yes");
	Observer++;
      }
    }
  }
  else{
    if(ThinkOutLoud)
      printf("ERROR %s %s:%d language not setup\n",__func__,__FILE__,__LINE__);
    return ;
  }
}

/*! \brief Lookup data directly from multiplexor cache
 *  - This also calls neural network processing
 *  - Does not handle negation
 */
int LookupYNQConditional(struct Conditional *Cond){  
  int Found=0,NumFound=0,NegatedSymbol=0;
  char *SortedCause=NULL,*SentenceSymbol=NULL;
  struct List_Str *EffectBuffer=NULL,*Buffer=NULL,*Causes=NULL,*Effects=NULL;
  struct Datablock *VDB=NULL,*DB=NULL;
  if(!Cond)
    return 0;

  VDB=ConditionallyRelated(Cond);
  SortedCause=List2Str(Cond->CauseSymbols);
  for(EffectBuffer=Cond->EffectSymbols;EffectBuffer;EffectBuffer=EffectBuffer->Next){
    
    if(!strncmp(EffectBuffer->Str,"ncs",3)){
      NegatedSymbol=1;
      SentenceSymbol=EffectBuffer->Str+1;
    }
    else{
      NegatedSymbol=0;
      SentenceSymbol=EffectBuffer->Str;
    }

    Found=0;
    for(DB=VDB;DB;DB=DB->Next)
      if((!strcmp(SentenceSymbol,DB->DS[0]->Str+8))){	
	for(Causes=DB->DS[1],Effects=DB->DS[2];Causes&&Effects;Causes=Causes->Next,Effects=Effects->Next){
	  if(!strcmp(Causes->Str,SortedCause)){
	    if((!strcmp(Effects->Str,"yes"))&&(!NegatedSymbol))
	      Found=1;
	    if((!strcmp(Effects->Str,"no"))&&(NegatedSymbol))
	      Found=1;
	    break;
	  }
	}
      }

    if(!Found){
      /* multiplex the symbols using the neural network */
      Buffer=Cond->EffectSymbols;
      Cond->EffectSymbols=NULL;
      WrapWHQConditional(Cond);
      Cond->EffectSymbols=Buffer;
      if(Buffer&&Cond->Answer){
	Found=Is_List_Element(Buffer,Cond->Answer->Str);
      }
    }
    NumFound+=Found;
  }

  /* *LogicTypes[]={"AND","OR","NOR","XOR","ERROR"}; */
  if(Cond->EffectLogic==0)
    if(Cond->NumEffects==Found)
      return 1;
  if(Cond->EffectLogic==1)
    if(Found)
      return 1;
  if(Cond->EffectLogic==2)
    if(Found==0)
      return 1;
  if(Cond->EffectLogic==3)
    if(Found==1)
      return 1;
  
  return 0;
}

/*! \brief Lookup data directly from multiplexor cache
 *  - Warning: incomplete
 */
struct Conditional *LookupWHQConditional(struct Conditional *Cond){
  char *CauseStr=NULL,*EffectStr=NULL,*Exists=NULL;
  struct List_Str *AnswerSet=NULL,*CauseList=NULL,*EffectList=NULL,*YesNo=NULL;
  struct Datablock *DB=NULL,*VDB=NULL;
  VDB=ConditionallyRelated(Cond);
  if(Cond->CauseSymbols){
    CauseStr=List2Str(Cond->CauseSymbols);      
    for(DB=VDB;DB;DB=DB->Next){
      for(CauseList=DB->DS[1],YesNo=DB->DS[2];CauseList&&YesNo;CauseList=CauseList->Next,YesNo=YesNo->Next)
	if(!strcmp(CauseList->Str,CauseStr))
	  if(!strcmp(YesNo->Str,"yes")){
	    AnswerSet=Add2Set(AnswerSet,DB->DS[0]->Str+8);
	    break;
	  }
    }
  }
  if(Cond->EffectSymbols){
    for(EffectList=Cond->EffectSymbols;EffectList;EffectList=EffectList->Next){
      if(!strncmp("ncs",EffectList->Str,3)){
	EffectStr=EffectList->Str+1;
	Exists="no";
      }
      else{
	EffectStr=EffectList->Str;
	Exists="yes";
      }
      for(DB=VDB;DB;DB=DB->Next)
	if(!strcmp(DB->DS[0]->Str+8,EffectStr))
	  for(CauseList=DB->DS[1],YesNo=DB->DS[2];CauseList&&YesNo;CauseList=CauseList->Next,YesNo=YesNo->Next)
	    if(!strcmp(YesNo->Str,Exists))
	      AnswerSet=Add2Set(AnswerSet,CauseList->Str);
    }
  }
  Cond->AnswerLogic=1;
  Cond->Answer=AnswerSet;
  return Cond;
}

/*! \brief General purpose conditional multiplexing.
 * 
 */
struct Datablock *MultiplexConditional(struct Datablock *DB){
  int _=0,Nothingness=0;
  char *EffectSymbol=NULL,*MultiplexRecName=NULL,*EncodeNothingAs=NULL;
  struct List_Str *CauseSymbols=NULL,*Buffer=NULL,*Causes=NULL,*Effects=NULL,*FinalSeq=NULL;
  struct Datablock *MultiplexedRecord=NULL;
  if(!DB)
    return NULL;
  EffectSymbol=DB->DS[0]->Str+8;
  MultiplexRecName=StrCat(":ms_",EffectSymbol);

  if((_=Find_List_Element(DB->DS[1],"nothing"))+1){
    Nothingness=1;
    EncodeNothingAs=(!!strcmp(Get_List_Element(DB->DS[2],_),"no"))?"1":"0";
  }

  for(Causes=DB->DS[1];Causes;Causes=Causes->Next)
    for(Buffer=Str2List(Causes->Str);Buffer;Buffer=Buffer->Next)
      if(strcmp(Buffer->Str,"nothing"))
	CauseSymbols=Add2Set(CauseSymbols,Buffer->Str);

  CauseSymbols=SortList(CauseSymbols);
  for(_=(1<<Size_of_List(CauseSymbols));_;--_)
    FinalSeq=Ins_List_Element(FinalSeq,"?",0);
  for(Causes=DB->DS[1],Effects=DB->DS[2];Causes&&Effects;Causes=Causes->Next,Effects=Effects->Next){
    _=0;
    for(Buffer=Str2List(Causes->Str);Buffer;Buffer=Buffer->Next)
      _+=(1<<Find_List_Element(CauseSymbols,Buffer->Str));
    if(!strcmp(Effects->Str,"yes"))
      FinalSeq=Rep_List_Element(FinalSeq,"1",_);
    else
      FinalSeq=Rep_List_Element(FinalSeq,"0",_);
  }

  if(Nothingness){
    FinalSeq=Rep_List_Element(FinalSeq,EncodeNothingAs,0);
  }

  FinalSeq=Ins_List_Element(FinalSeq,MultiplexRecName,0);
  Decision_Maker(FinalSeq,NULL);
  MultiplexedRecord=Goto_DB_Entry(Database[0],MultiplexRecName);
  MultiplexedRecord->DS[1]=CauseSymbols;
  MultiplexedRecord->DS[2]=Str2List(EffectSymbol);
  return MultiplexedRecord;
}

/*! \brief Creates a multiplexed number sequence from the conditional data Cond.
 * - Note forward multiplexing only use with deductive logic!
 */
struct Conditional *ForwardMultiplexConditional(struct Conditional *Cond){
  int _=0,Encoded=0;
  struct List_Str *FoundList=NULL,*CauseSymbols=NULL,*Buffer=NULL;
  struct Datablock *VDB=NULL,*MultiplexedRecords=NULL,*DB=NULL;

  VDB=ConditionallyCauseRelated(Cond); 
  if(!VDB)
    return Cond;

  for(DB=VDB;DB;DB=DB->Next){
    MultiplexedRecords=Add2VirtDB(MultiplexedRecords,MultiplexConditional(DB));
    CauseSymbols=MultiplexedRecords->DS[1];
    Encoded=0;
    for(Buffer=Cond->CauseSymbols;Buffer;Buffer=Buffer->Next){
      _=Find_List_Element(CauseSymbols,Buffer->Str);
      if(_+1)
	Encoded+=(1<<_);
    }
    Decide(Str2List(FloatToString(Encoded)),Str2List(StrCat(":ms_",DB->DS[0]->Str+8)));
    if(atoi(ANSWER->Str)==1)
      FoundList=Ins_List_Element(FoundList,DB->DS[0]->Str+8,0);
  }
  
  Cond->Answer=FoundList;
  Cond->AnswerLogic=0;

  return Cond;
}


/*! \brief Creates a multiplexed number sequence from the conditional data Cond.
 * - Note backward multiplexing only!
 */
struct Conditional *BackwardMultiplexConditional(struct Conditional *Cond){
  int i=0,_=0,SizeofCauseList=0;
  struct List_Str *FoundEffects=NULL,*EffectList=NULL,*CauseSymbols=NULL,*Buffer=NULL;
  struct Datablock *VDB=NULL,*MultiplexedRecords=NULL,*DB=NULL;
  
  VDB=ConditionallyEffectRelated(Cond);
  if(!VDB)
    return Cond;

  for(DB=VDB;DB;DB=DB->Next){
    MultiplexedRecords=Add2VirtDB(MultiplexedRecords,MultiplexConditional(DB));
    CauseSymbols=MultiplexedRecords->DS[1];
  
    if(Is_List_Element(Cond->EffectSymbols,DB->DS[0]->Str+8)){      
      SizeofCauseList=Size_of_List(MultiplexedRecords->DS[1]);
      Domain(Ins_List_Element(Str2List("0"),FloatToString((1<<SizeofCauseList)-1),1),NULL);
      Decide(ANSWER,Str2List(StrCat(":ms_",DB->DS[0]->Str+8)));
      i=0;

      /*
      if(atoi(ANSWER->Str)==1)
	EffectList=Append_List_Element(EffectList,"nothing");
      */

      for(Buffer=ANSWER;Buffer;Buffer=Buffer->Next){
	FoundEffects=NULL;
	if(atoi(Buffer->Str)==1)
	  for(_=0;i>>_;_++)
	    if((i>>_)&1)
	      FoundEffects=Append_List_Element(FoundEffects,Get_List_Element(CauseSymbols,_));
	i++;
	if(FoundEffects)
	  EffectList=Append_List_Element(EffectList,List2Str(FoundEffects));
      }
    }
  }
  Cond->Answer=EffectList;
  Cond->AnswerLogic=1;
  return Cond;
}

/*! \brief Wraps the multiplexors and lookup functions
 *
 */
struct Conditional *WrapWHQConditional(struct Conditional *Cond){
  int Deduction=0,Reduction=0;
  struct List_Str *LookedUpAnswer=NULL;
  if(MULTIPLEXSWITCH<2){
    Cond=LookupWHQConditional(Cond);
  }
  if(MULTIPLEXSWITCH){ 
    LookedUpAnswer=Cond->Answer;
    Deduction=(Size_of_List(Cond->CauseSymbols)>0);
    Reduction=(Size_of_List(Cond->EffectSymbols)>0)||(!Deduction);      
    if(Deduction&&Reduction){
      /* incomplete: in this section we need the indeterminate logic. */
      
	
    }
    else{
      Cond=Deduction?ForwardMultiplexConditional(Cond):BackwardMultiplexConditional(Cond);
    }
    Cond->Answer=IntUnion(Cond->Answer,LookedUpAnswer);
  }
  return Cond;
}

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
