/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#ifndef ENiXWMSCOMPAT
#define ENiXWMSCOMPAT

struct List_Str  *AddEmotions(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *AssignEmotions(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Attribute(struct List_Str *Word_List,struct List_Str *L,int Attribute_ID);
struct List_Str  *CContext(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *EndPunct(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *PPronouns(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Pronouns(struct List_Str *Word_List,struct List_Str *L);
void             New_Relate(int Mode, char *Description);
struct List_Str  *SetBias(struct List_Str *Word_List,struct List_Str *L);

struct List_Str  *SetCondCause(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SetCondEffect(struct List_Str *Word_List,struct List_Str *L);

struct List_Str  *SetGender(struct List_Str *Word_List,struct List_Str *L);
void             SetGrammarAttr(struct List_Str *Word_List,char *Qualifier);
struct List_Str  *Statistics(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *TOL(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Verbosity(struct List_Str *Word_List,struct List_Str *L);

/* Emotion data */
void             SetEmotionAttr(struct List_Str *Word_List,char *Qualifier);
int              DetectEmoAttr(char *Attribute);
int              DetectVerbosity();
void             SetVerbosity(int Verbosity);
int              DetectArgue();
void             SetArgue(int Verbosity);
int              DetectUnderstood();
void             SetUnderstood(int Verbosity);
int              DetectEmpathise();
void             SetEmpathise(int Verbosity);
int              DetectDeadline();
void             SetDeadline(int Verbosity);
struct List_Str  *SetEmoMode(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *EmoDebug(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SystemMood(struct List_Str *Word_List,struct List_Str *L);
void             TriggerEmoAttr(char *Attribute,int Value);

struct List_Str  *WHQEvent(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *YNQEvent(struct List_Str *Word_List,struct List_Str *L);

struct List_Str  *Forget(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Unstore(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Prepend(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Sentiency(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Tense(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Tenses(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Subj(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SetWH(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SetYN(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SPA(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SetNULL(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SetPassive(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SetQuestion(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SAVF(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SMVF(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Emotion(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Grammar(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Purpose(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *AAVF(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *APVF(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Argue(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Graphs(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Nouns(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *PredVerbs(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *ImpEvent(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *InfoEvent(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Limits(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Locklang(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *AVF(struct List_Str *WordList,struct List_Str *L,int Type); /* Type 0 = APVF Type 1 = AAVF */
int              IsGrammarAttribute(char *Qualifier,char *Value);
struct List_Str  *MeldVF(struct List_Str *WordList,struct List_Str *L);
struct List_Str  *GetGraphs(struct List_Str *WordList,struct List_Str *L);
int              IsAttribof(char *Concept,char *Value);
struct List_Str  *Memory(struct List_Str *WordList,struct List_Str *L);
struct List_Str  *SentenceUnity(struct List_Str *WordList,struct List_Str *L);
struct List_Str  *Personality(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Cache(struct List_Str *L);
struct List_Str  *Saveset(struct List_Str *WordList,struct List_Str *L);
struct List_Str  *Copy(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *All(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Delete(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Like(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Qualify(struct List_Str *Word_List,struct List_Str *L);
char             *Find_Grammar_Example(char *Type);
struct List_Str  *Store(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Mode(struct List_Str *Word_List,struct List_Str *List);
struct List_Str  *Define(struct List_Str *Word_List,struct List_Str *Command_List);
struct List_Str  *Definition(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Append(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *VerbBaseFinder(struct List_Str *L);
/* Finds if Word is an article of types Articles */
int              IsArticle(char *Word,char *Articles); 
struct List_Str  *ExtractArticles(struct List_Str *Word_List,char *Articles);
struct List_Str  *DiscardAuxVerbs(struct List_Str *VerbData);
struct List_Str  *AuxVerbs(struct List_Str *Word_List,struct List_Str *L);
int              Comp_Sem_Subject(struct List_Str *Locate,struct List_Str *In); /* 1= match 0= different -1= partial */
struct List_Str  *Recall_Prev_Answer();
struct Datablock *Recognise(struct Datablock *LS,struct List_Str *Com);
struct List_Str  *CoreSubjMtr(struct List_Str *S);
struct List_Str  *Topic(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Hook(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *ClrEmoDebug(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *PopEmoDebug(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *GetEmoDebug(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *SetMood(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *EmoList(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *Emo2Vec(struct List_Str *Word_List,struct List_Str *L);
char             *EmoTableLookup(char *SourceEmo,char *ModifierEmo,char *TargetEmo);
struct List_Str  *CreateGraph(struct List_Str *Word_List,struct List_Str *L);

int              AreAnyGAttributes(char *Qualifier,struct List_Str *Values);

struct List_Str  *Setup(struct List_Str *Word_List,struct List_Str *L);

struct List_Str  *SPVF(struct List_Str *WordList,struct List_Str *L);

int              IsSentence(struct List_Str *List);

struct List_Str  *AddEmoDebug(struct List_Str *Word_List,struct List_Str *L);
void             SetEmotionRoot(int Understanding,int Internal);
char             *DirectedGraphStr(char *Concept,char *Qualifier,char *DirectedGraph);

struct List_Str  *Similar(struct List_Str *WordList,struct List_Str *L);
struct List_Str  *Described(struct List_Str *Word_List,struct List_Str *L);

struct List_Str  *SetRandSeed(struct List_Str *Word_List,struct List_Str *L);

#endif

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
