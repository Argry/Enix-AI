/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#ifndef ENiXLDEFS
#define ENiXLDEFS

/* MISC */
struct Related{
  struct List_Str *Targets;
  struct List_Str *AffectedSentences;
  struct List_Str *CanonicalTargets;
  struct List_Str *CSNouns;
  struct List_Str *CSVerbs;
};

extern struct Related RelatedTemplate;

struct Meanings{
   int Size;
   struct List_Str **Conversations;
};

extern struct Meanings MeaningTemplate;

struct ConvList{
   int Size;
   struct Meanings **Conversations;
};

extern struct ConvList CLTemplate;

struct Sentence{
  struct List_Str  *Sentence;
  char             *Mood;
  int              Sentiency;
  int              PassiveVoice;
  int              InterceptedSpirit;
  int              Tense;
  int              Negation;
  struct List_Str  *SentenceStructure;
  struct List_Str  *Subject;
  struct List_Str  *PredicateNounBlock;
  struct List_Str  *PredicateVerbBlock;
  /* Refined */
  /* Logic = 0:AND,1:OR,2:NOR,3:XOR,4:ERROR */
  int              SubjectLogic;
  int              PredicateLogic;
  struct List_Str  *RefinedSubject;   /* The adjective and nouns - no articles */
  struct List_Str  *RefinedPredicate;
  struct List_Str  *RefinedVerb;
  char             *VerbCSNum;
  struct List_Str  *CSVerbRef;
  struct List_Str  *S;
  struct List_Str  *PV;
  struct List_Str  *PN;
  /* Plurals */
  int              SIsPlural;
  int              SContainsGroup;
  int              SContainsPlurals;
  int              PIsPlural;
  int              PContainsGroup;
  int              PContainsPlurals;
  /* These are the basic components of the sentence */
  struct List_Str  *BasicSubject;
  struct List_Str  *BasicPredicate;
  struct List_Str  *PassiveVerbPrepositions;
  /* Internal */
  struct List_Str  *Predicate;        /* This is the complete predicate with verb */
  struct List_Str  *Disambiguated;
  int              Understood;
  int              ComplexSentence;
  struct Datablock *Language;
};

struct Conditional {
  /* New layout */
  struct List_Str *OriginalData;
  int IsQuestion;
  int IsActive;
  int IsConditional;
  /*
  struct List_Str *ConditionalsFound;
  struct List_Str *NounList;
  struct List_Str *VerbList;
  */
  int NumCauses;
  struct List_Str **CauseSentences;
  struct List_Str *CauseSymbols;
  int NumEffects;
  struct List_Str **EffectSentences;
  struct List_Str *EffectSymbols;
  /* Logic = 0:AND,1:OR,2:NOR,3:XOR,4:ERROR */
  int CauseLogic;
  int EffectLogic;
  /* ANSWER */
  int AnswerLogic;
  struct List_Str *Answer;
};

struct CombinedSentence {
  int Size;
  struct List_Str **Sentences;
  /* Logic = 0:AND,1:OR,2:NOR,3:XOR,4:ERROR */
  int Logic;
};

struct SentenceLogic {
  int Cause;
  struct List_Str *SentenceSymbols;
  int LogicType;
  struct Datablock *Ref;
};

#endif

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
