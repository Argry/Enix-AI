/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include "ENiX_Globals.h"
#include "ENiX_STRING.h"
#include "ENiX_WMS.h"
#include "ENiX_WMS_COMPAT.h"
#include "ENiX_TIME.h"
#include "ENiX_LIST.h"
#include "ENiX_OUTPUT.h"
#include "ENiX_SETTHEORY.h"
#include "ENiX_NLP.h"


char *Levels[]={"low","medium","high"};

/*! \brief Gets a list of directed graphs.
 *  
 */
char *DirectedGraphStr(char *Concept,char *Qualifier,char *DirectedGraph){
  int _=0;
  struct List_Str *L=NULL;
  struct Datablock *DB=Goto_DB_Entry(Database[1],Concept);
  if((_=Find_List_Element(DB->DS[1],Qualifier))+1)
    if(!strcmp(((L=Str2List(Get_List_Element(DB->DS[2],_)))->Str),"?"))
      L=NULL;
  L=Add2Set(L,DirectedGraph);
  return List2Str(L);
}

/*! \brief Sets a seed for a random number generator.
 *  
 */
struct List_Str *SetRandSeed(struct List_Str *Word_List,struct List_Str *L){
  struct Datablock *DB=NULL;
  DB=GetLang();
  if(DB){
    if(Word_List)
      Rep_DB_Pair(DB,":randseed",Word_List->Str);
  }
  else
    puts("Language not setup!");
  return L;
}

/*! \brief Turn on think out loud debugging.
 *
 */
struct List_Str *TOL(struct List_Str *Word_List,struct List_Str *L){
  SetGrammarAttr(Word_List,":tol");
  return L;
}

/*! \brief Determine the current emotion state of ENiX.
 *
 */
struct List_Str  *SystemMood(struct List_Str *Word_List,struct List_Str *L){
  struct Datablock *DB=Goto_DB_Entry(Database[1],":emomode");
  if(DB)
    ANSWER=Str2List(Lookup_DB_Attr(DB,"systemmood",NULL));
  else
    if(ThinkOutLoud)
      printf("ERROR %s(%s:%d) cannot find :emomode.\n",__func__,__FILE__,__LINE__);
  return L;
}

/*! \brief Specify the emotional processing parameters of ENiX.
 *
 */
struct List_Str  *SetEmoMode(struct List_Str *Word_List,struct List_Str *L){
  char *Attribute=L->Str;
  SetEmotionAttr(Word_List,Attribute);
  return L->Next;
}

/*! \brief Display the database record containing all the emotion parameters of ENiX.
 *
 */
struct List_Str  *EmoDebug(struct List_Str *Word_List,struct List_Str *L){
  struct Datablock *DB=Goto_DB_Entry(Database[1],":emomode");
  Print_DB_Entry(DB,0);
  return L;
}

/*! \brief Specify the verbosity behaviour of ENiX.
 *
 */
struct List_Str *Verbosity(struct List_Str *Word_List,struct List_Str *L){
  SetEmotionAttr(Word_List,"verbosity");
  return L;
}

/*! \brief Determine the value emotion attribute "Attribute" from ENiX emotion configuration.
 *
 */
int DetectEmoAttr(char *Attribute){
  int _=0;
  char *VerbositySetting=NULL;
  struct Datablock *DB=Goto_DB_Entry(Database[1],":emomode");  
  if(DB){
    if(((_=Find_List_Element(DB->DS[1],Attribute))+1))
      VerbositySetting=Get_List_Element(DB->DS[2],_);
    else
      return 1;
  }
  else{
    if(ThinkOutLoud)
      printf("ERROR DetectEmoAttr[%s](%s:%d): Emotion data not setup!\n",Attribute,__FILE__,__LINE__);
    return 1;
  }
  if(!strcasecmp(VerbositySetting,"low"))
    return 0;
  if(!strcasecmp(VerbositySetting,"medium"))
    return 1;
  if(!strcasecmp(VerbositySetting,"high"))
    return 2;
  return 1;
}

/*! \brief Set ENiX emotion attribute "Attribute" as trigger value "Value".
 * - "Value" is one of 0, 1 or 2.
 */
void TriggerEmoAttr(char *Attribute,int Value){
  char *AttribValues[]={"low","medium","high"};
  SetEmotionAttr(Str2List(AttribValues[Value]),Attribute);
}

/*! \brief Detect ENiX verbosity attribute.
 * - Return is one of 0, 1 or 2.
 */
int DetectVerbosity(){
  return DetectEmoAttr("verbosity");
}

/*! \brief Set ENiX verbosity attribute.
 * - "Verbosity" is one of 0, 1 or 2.
 */
void SetVerbosity(int Verbosity){
  SetEmotionAttr(Str2List(Levels[Verbosity]),"verbosity");
}

/*! \brief Detect ENiX argue attribute.
 * - Return is one of 0, 1 or 2.
 */
int DetectArgue(){
  return DetectEmoAttr("argue");
}

/*! \brief Set ENiX argue attribute.
 * - "Argue" is one of 0, 1 or 2.
 */
void SetArgue(int Argue){
  SetEmotionAttr(Str2List(Levels[Argue]),"argue");
}

/*! \brief Detect ENiX understood attribute.
 * - Return is one of 0, 1 or 2.
 */
int DetectUnderstood(){
  return DetectEmoAttr("understood");
}

/*! \brief Set ENiX understood attribute.
 * - "Understanding" is one of 0, 1 or 2.
 */
void SetUnderstood(int Understanding){
  SetEmotionAttr(Str2List(Levels[Understanding]),"understood");
}

/*! \brief Detect ENiX empathise attribute.
 * - Return is one of 0, 1 or 2.
 */
int DetectEmpathise(){
  return DetectEmoAttr("empathise");
}

/*! \brief Set ENiX understood attribute.
 * - "Empathy" is one of 0, 1 or 2.
 */
void SetEmpathise(int Empathy){
  SetEmotionAttr(Str2List(Levels[Empathy]),"understood");
}

/*! \brief Detect ENiX deadline attribute.
 * - Return is one of 0, 1 or 2.
 */
int DetectDeadline(){
  return DetectEmoAttr("deadline");
}

/*! \brief Set ENiX deadline attribute.
 * - "Deadline" is one of 0, 1 or 2.
 */
void SetDeadline(int Deadline){
  SetEmotionAttr(Str2List(Levels[Deadline]),"deadline");
}

/*! \brief Displays the ENiX learning metrics since last sleep.
 * 
 */
struct List_Str *Statistics(struct List_Str *Word_List,struct List_Str *L){
  printf("Datablocks: %d, relationships: %d. Since last sleep: %d.\n",DB_Size,RB_Size,Newly_Learnt);
  return L;
}

/*! \brief Specifies grammar attributes within the :mode record of the database.
 * 
 */
void SetGrammarAttr(struct List_Str *Word_List,char *Qualifier){
  int Found=0;
  char *Lang=NULL;
  struct Datablock *DB=Database[1];
  if(!(DB=Goto_DB_Entry(Database[1],":mode")))
    puts("Error: language not setup correctly.");
  else{
    Lang=Get_DB_Entry(DB,0,1);
    if(!(DB=Goto_DB_Entry(Database[1],Lang)))
      puts("Error: language not setup correctly.");
    else{
      Found=Find_List_Element(DB->DS[1],Qualifier);
      if(Found<0){
	DB->DS[1]=Ins_List_Element(DB->DS[1],Qualifier,0);
	DB->DS[2]=Ins_List_Element(DB->DS[2],List2Str(Word_List),0);
      }
      else
	DB->DS[2]=Rep_List_Element(DB->DS[2],List2Str(Word_List),Found);
    }
  }
}

/*! \brief Specifies emotion attributes within the :emomode record of the database.
 * 
 */
void SetEmotionAttr(struct List_Str *Word_List,char *Qualifier){
  int Found=0;
  struct Datablock *DB=Database[1];
  if(!(DB=Goto_DB_Entry(Database[1],":emomode")))
    DB=Database[1]=Add_DB_Entry(Database[1],":emomode");    
  Found=Find_List_Element(DB->DS[1],Qualifier);
  if(Found<0){
    DB->DS[1]=Ins_List_Element(DB->DS[1],Qualifier,0);
    DB->DS[2]=Ins_List_Element(DB->DS[2],List2Str(Word_List),0);
  }
  else
    DB->DS[2]=Rep_List_Element(DB->DS[2],List2Str(Word_List),Found);
}

/*! \brief Sets Wh-Question event parameters.
 * 
 */
struct List_Str *WHQEvent(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":whqevent");
   return L;   
}

/*! \brief Sets YN-Question event parameters.
 * 
 */
struct List_Str *YNQEvent(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":ynqevent");
   return L;   
}

/*! \brief Specifies personal pronouns.
 * 
 */
struct List_Str  *PPronouns(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":ppronouns");
   return L;
}

/*! \brief Registers a list of emotion names within ENiX.
 * 
 */
struct List_Str *AssignEmotions(struct List_Str *Word_List,struct List_Str *L){
   struct Datablock *DB=GetLang();
   if(!DB){
     printf("AssignEmotions (%s:%d) Language not setup!\n",__FILE__,__LINE__);
     return NULL;
   }
   Rep_DB_Pair(DB,":assignemo",List2Str(L));
   return NULL;
}

/*! \brief Specifies ENiX bias in the :setbias attribute.
 * 
 */
struct List_Str  *SetBias(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":setbias");
   return L;
}

/*! \brief Specifies ENiX emotion in the :emotion attribute.
 * 
 */
struct List_Str *AddEmotions(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":emotion");
   return L;
}

/*! \brief Specifies the gender of a noun in the 3rd attribute of the header.
 * 
 */
struct List_Str *SetGender(struct List_Str *Word_List,struct List_Str *L){
   return Attribute(Word_List,L,2);   
}

/*! \brief Specifies ENiX pronouns in the :pronouns attribute.
 * 
 */
struct List_Str *Pronouns(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":pronouns");   
   return L;
}

/*! \brief Specifies ENiX conversation context.
 * 
 */
struct List_Str *CContext(struct List_Str *Word_List,struct List_Str *L){
   struct Datablock *DB;
   if((DB=Goto_DB_Entry(Database[1],":mode")))
     Rep_DB_Entry(DB,0,3,Word_List->Str);
   return L;
}

/*! \brief Specifies the attribute of a record in header attribute "Attribute_ID".
 * 
 */
struct List_Str *Attribute(struct List_Str *Word_List,struct List_Str *L,int Attribute_ID){
   char *Word=NULL,*Value=NULL,*Buffer=NULL;
   struct List_Str *Input=NULL,*Alpha=NULL;
   struct Datablock *Start=NULL;
   Input=Word_List;
   Value=L->Str;
   L=L->Next;
   New_Relate(Attribute_ID,Value);
   PrintListSpecial("Setting: \"",Input,"\", \"","\" and \"","\" to ");
   printf("%s.\n",Value);
   while(Input){
      Word=Input->Str;
      Start=Goto_DB_Entry(Database[1],Word);
      if(strcmp(Buffer=Get_DB_Entry(Start,0,Attribute_ID),"?")){
	 if(!Is_List_Element(Alpha=Str2List(Buffer),Value))
	   Rep_DB_Entry(Start,0,Attribute_ID,List2Str(Ins_List_Element(Alpha,Value,0)));
      }
      else
	Rep_DB_Entry(Start,0,Attribute_ID,Value);
      Input=Input->Next;
   }
   return L;
}

/*! \brief Creates a new relationship between records called "Description" with mode "Mode".
 *  - not to be confused with creating a new relationship record.
 */
void New_Relate(int Mode, char *Description){
   char *Variable=NULL;
   struct Datablock *DB=Database[1];
   struct List_Str *List=NULL;
   Variable=Get_DB_Entry(Goto_DB_Entry(Database[1],":mode"),0,Mode);
   if(!strcmp(Variable,"?")){
      if(ThinkOutLoud)
	puts(" * WARNING * You need to specify the communication entity grammar|emotion|purpose. New relationship not be completed.");
   }
   else{
      List=Str2List(Get_List_Element((DB=Goto_DB_Entry(Database[1],Variable))->DS[0],7));
      if(!Is_List_Element(List,Description)){
	 List=Ins_List_Element(List,Description,0);
	 Rep_DB_Entry(DB,0,7,List2Str(List));
      }
   }
}

/*! \brief Set a conditional cause sentence parameters in attribute :setcond of the language record.
 *  
 */
struct List_Str  *SetCondCause(struct List_Str *Word_List,struct List_Str *L){
  struct Datablock *DB=GetLang();
  if(DB){
    Rep_DB_Pair(DB,":setcondcause",List2Str(Word_List));
  }
  else{
    printf("SetCondCause: (%s:%d) Language not setup!\n",__FILE__,__LINE__);
  }
  return L;
}

/*! \brief Set a conditional effect sentence parameters in attribute :setcond of the language record.
 *  
 */
struct List_Str  *SetCondEffect(struct List_Str *Word_List,struct List_Str *L){
  struct Datablock *DB=GetLang();
  if(DB){
    Rep_DB_Pair(DB,":setcondeffect",List2Str(Word_List));
  }
  else{
    printf("SetCondEffect: (%s:%d) Language not setup!\n",__FILE__,__LINE__);
  }
  return L;
}



/*! \brief Specify end punctuation marks in attribute :endpunct of the language record.
 *  
 */
struct List_Str  *EndPunct(struct List_Str *Word_List,struct List_Str *L){
   Rep_DB_Pair(GetLang(),":endpunct",List2Str(Word_List));
   return L;
}

/*! \brief Insert "Word_List" before the data held at position "L".
 *  
 */
struct List_Str *Prepend(struct List_Str *Word_List,struct List_Str *L){
   struct List_Str *PREPEND=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],L->Str),0,7));
   L=L->Next;
   ANSWER=Ins_List_List(Word_List,PREPEND,0);
   return L;
}

/*! \brief Dereference all concepts and store them in ANSWER.
 *  
 */
struct List_Str *Unstore(struct List_Str *Word_List,struct List_Str *L){
   ANSWER=NULL;
   for(;Word_List;Word_List=Word_List->Next)
      ANSWER=Ins_List_List(ANSWER,Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],Word_List->Str),0,7)),Size_of_List(ANSWER));
   return L;
}

/*! \brief Delete the associations formed under a concept.
 *  
 */
struct List_Str *Forget(struct List_Str *Word_List,struct List_Str *L){
   for(;Word_List;Word_List=Word_List->Next)
      Rep_DB_Entry(Goto_DB_Entry(Database[1],Word_List->Str),0,7,"?");
   return L;
}

/*! \brief Sentiency kill switch.
 *  
 */
struct List_Str *Sentiency(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":sentiency");
   return L;   
}

/*! \brief Specify the tenses record in grammar attribute :tenses.
 *  
 */
struct List_Str *Tenses(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":tenses");
   return L;   
}

/*! \brief Specify a verb's tense.
 *  
 */
struct List_Str *Tense(struct List_Str *Word_List,struct List_Str *L){
  char *TenseName=L->Str;
  struct List_Str *Buffer=NULL;
  for(Buffer=Word_List;Buffer;Buffer=Buffer->Next)
    Rep_DB_Entry(Goto_DB_Entry(Database[1],Buffer->Str),0,2,TenseName);
  return L->Next;
}

/*! \brief Specify subjunctive sentence configuration.
 *  
 */
struct List_Str *Subj(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":subj");
   return L;
}

/*! \brief Specify WH-Question sentence configuration.
 *  
 */
struct List_Str *SetWH(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":wh");
   return L;   
}

/*! \brief Specify YN-Question sentence configuration.
 *  
 */
struct List_Str *SetYN(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":yn");
   return L;   
}

/*! \brief Specify :spa parameter.
 *  
 */
struct List_Str *SPA(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":spa");
   return L;   
}

/*! \brief Specify :question parameter.
 *  
 */
struct List_Str *SetQuestion(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":question");
   return L;   
}

/*! \brief Specify :setpassive parameter.
 *  
 */
struct List_Str *SetPassive(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":setpassive");
   return L;   
}

/*! \brief Specify :setnull parameter.
 *  
 */
struct List_Str *SetNULL(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":setnull");
   return L;   
}

/*! \brief Specify passive verb forms.
 *  
 */
struct List_Str *SPVF(struct List_Str *Word_List,struct List_Str *L){
   Print_DB_Entry(Goto_DB_Entry(Database[1],":pvf"),0);
   return L;
}

/*! \brief Specify active verb forms.
 *  
 */
struct List_Str  *SAVF(struct List_Str *Word_List,struct List_Str *L){
   Print_DB_Entry(Goto_DB_Entry(Database[1],":avf"),0);
   return L;
}

/*! \brief Meld the active and passive verb forms together.
 *  
 */
struct List_Str  *SMVF(struct List_Str *Word_List,struct List_Str *L){
   Print_DB_Entry(Goto_DB_Entry(Database[1],":meldvf"),0);
   return L;
}

/*! \brief Specify the emotion attribute of a concept in the database.
 *  
 */
struct List_Str  *Emotion(struct List_Str *Word_List,struct List_Str *L){
   return Attribute(Word_List,L,3);
}

/*! \brief Specify the grammar attribute of a concept in the database.
 *  
 */
struct List_Str  *Grammar(struct List_Str *Word_List,struct List_Str *L){
   return Attribute(Word_List,L,1);
}

/*! \brief Specify the purpose attribute of a concept in the database.
 *  
 */
struct List_Str  *Purpose(struct List_Str *Word_List,struct List_Str *L){
   return Attribute(Word_List,L,2);
}

/*! \brief Determine active verb form.
 *  
 */
struct List_Str *AAVF(struct List_Str *Word_List,struct List_Str *L){
   return AVF(Word_List,L,1);
}

/*! \brief Determine passive verb form.
 *  
 */
struct List_Str *APVF(struct List_Str *Word_List,struct List_Str *L){
   return AVF(Word_List,L,0);
}

/*! \brief Enable or disable argue.
 *  
 */
struct List_Str *Argue(struct List_Str *Word_List,struct List_Str *L){
   SetEmotionAttr(Word_List,"argue");
   return L;
}

/*! \brief Specify predicate verbs in attribute called :predverbs.
 *  
 */
struct List_Str *PredVerbs(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":predverbs");
   return L;
}

/*! \brief Specify markov models in attribute called :graphs.
 *  
 */
struct List_Str *Graphs(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":graphs");
   return L;
}

/*! \brief Specify nouns in attribute called :nouns.
 *  
 */
struct List_Str *Nouns(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":nouns");
   return L;
}

/*! \brief Specify information event triggers in attribute called :infoevent.
 *  
 */
struct List_Str *InfoEvent(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":infoevent");
   return L;
}

/*! \brief Specify imperative event triggers in attribute called :impevent.
 *  
 */
struct List_Str *ImpEvent(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":impevent");
   return L;
}

/*! \brief Specify limits of NN learning in attribute called :limits.
 *  
 */
struct List_Str *Limits(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":limits");
   return L;
}

/*! \brief Specify a read only lock in attribute called :locklang preventing further language configuration.
 *  
 */
struct List_Str *Locklang(struct List_Str *Word_List,struct List_Str *L){
   SetGrammarAttr(Word_List,":locklang");
   return L;
}

/*! \brief Change active or passive verb forms.
 *  
 */
struct List_Str *AVF(struct List_Str *WordList,struct List_Str *L,int Type){
  struct List_Str *Input=WordList;
  struct Datablock *DB=NULL;
  if(IsGrammarAttribute(":locklang","on")) 
    puts("ERROR: language locked.");
  else{
    if(Type){
      if(!(DB=Goto_DB_Entry(Database[1],":avf")))
	DB=Database[1]=Add_DB_Entry(Database[1],":avf");
      Rep_DB_Pair(DB,List2Str(Input),List2Str(L));
    }
    else{
      if(!(DB=Goto_DB_Entry(Database[1],":pvf")))
	DB=Database[1]=Add_DB_Entry(Database[1],":pvf");
      Rep_DB_Pair(DB,List2Str(Input),List2Str(L));
    }
  }
  return NULL;
}

/*! \brief Check if "Qualifier" and "Value" are specified as a grammar configuration pair.
 *  
 */
int IsGrammarAttribute(char *Qualifier,char *Value){
  struct Datablock *DB1=NULL,*DB2=NULL;
  if(!(DB1=Goto_DB_Entry(Database[1],":mode"))){
    if(ThinkOutLoud)
      printf("IsGrammarAttribute (%s:%d) No :mode set.\n",__FILE__,__LINE__);
    return 0;
  }
  if(!(DB2=Goto_DB_Entry(Database[1],DB1->DS[0]->Next->Str))){
    if(ThinkOutLoud)
      printf("IsGrammarAttribute (%s:%d) No %s attribute.\n",__FILE__,__LINE__,DB1->DS[0]->Next->Str);
    return 0;
  }
  return Is_List_Element(Str2List(Get_List_Element(DB2->DS[2],Find_List_Element(DB2->DS[1],Qualifier))),Value);
}

/*! \brief Meld verb forms of active and passive together.
 *  
 */
struct List_Str *MeldVF(struct List_Str *WordList, struct List_Str *L){
   struct List_Str *First=NULL,*Second=NULL;
   struct Datablock *Active=Goto_DB_Entry(Database[1],":avf"),*Passive=Goto_DB_Entry(Database[1],":pvf"),*DB=NULL;
   if((Active)&&(Passive)){
      if(ThinkOutLoud) puts("Melding verb forms, passive and active exist.");
      if(!(DB=Goto_DB_Entry(Database[1],":meldvf")))
	DB=Database[1]=Add_DB_Entry(Database[1],":meldvf");
      First=Active->DS[1]; Second=Active->DS[2];
      while(First){
	 Rep_DB_Pair(DB,First->Str,Second->Str); First=First->Next; Second=Second->Next;
      }
      First=Passive->DS[1]; Second=Passive->DS[2];
      while(First){
	 Rep_DB_Pair(DB,First->Str,Second->Str); First=First->Next; Second=Second->Next;
      }
   }
   else
     puts("Error: cannot meld verb forms, either passive or active verb forms are not defined.");
   return L;
}

/*! \brief Obtain a list of hidden markov model names.
 *  
 */
struct List_Str *GetGraphs(struct List_Str *WordList,struct List_Str *L){
   int _=0;
   struct List_Str *R=NULL;
   struct Datablock *DB=GetLang();
   if(DB)
     if(((_=Find_List_Element(DB->DS[1],":graphs"))+1))
       R=Str2List(Get_List_Element(DB->DS[2],_));
   ANSWER=R;
   return L;
}

/*! \brief True if "Value" is an attribute of record "Concept".
 *  
 */
int IsAttribof(char *Concept,char *Value){
  return Is_List_Element(Str2List(Goto_DB_Entry(Database[1],Concept)->DS[0]->Next->Str),Value);
}

/*! \brief Displays to contents of the :memory record.
 *  
 */
struct List_Str *Memory(struct List_Str *WordList,struct List_Str *L){
   Print_DB_Entry(Goto_DB_Entry(Database[1],":memory"),0);
   return L;
}

/*! \brief Specify sentence unity. This is the element that needs to occur once within a sentence, normally the verb.
 *  
 */
struct List_Str *SentenceUnity(struct List_Str *WordList,struct List_Str *L){
   int _=0;
   char *Unit=NULL;
   struct Datablock *DB=NULL;
   Unit=L->Str;
   L=L->Next;
   if(!(DB=GetLang())){
     printf("SentenceUnity (%s,%d) Language object does not exist!\n",__FILE__,__LINE__);
     return L;
   }
   _=Find_List_Element(DB->DS[1],":sentenceunit");
   if(_<0){
      DB->DS[1]=Ins_List_Element(DB->DS[1],":sentenceunit",0);
      DB->DS[2]=Ins_List_Element(DB->DS[2],Unit,0);
   }
   else{
     Rep_DB_Entry(DB,2,_,Unit);
   }
   return L;
}

/*! \brief Saves the name of the personality profile currently running in ENiX.
 *  
 */
struct List_Str *Personality(struct List_Str *Word_List,struct List_Str *L){
   int _=0;
   char *Name=NULL;
   struct Datablock *Q=NULL;
   struct List_Str *Buffer=NULL;
   Buffer=(Q=Goto_DB_Entry(Database[1],":mode"))->DS[1];
   for(_=0;Buffer;_++)
     Buffer=Buffer->Next;
   if(_<7) 
     Name=StrCat("","?");
   else Name=StrCat("",Get_List_Element(Q->DS[2],6));
   Name[0]=toupper(Name[0]);
   ANSWER=Ins_List_Element(Ins_List_Element(Ins_List_Element(Ins_List_Element(NULL,"ENiX",0),"3",1),"Incarnation",2),Name,3);
   return L;
}

/*! \brief Returns the literal contents of a record in "L".
 *  
 */
struct List_Str *Cache(struct List_Str *L){ /* module is shit needs recoding */
   char *Data=NULL;
   L=L->Next;
   if(L){
     Data=L->Str;
   }
   else{
     puts("Syntax: NULL :CACHE B");
     return L;
   }
   if(Data[0]!=':'){
      ANSWER=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],Data),0,7));
      L=L->Next;
   }
   else{
     puts("Syntax: NULL :CACHE B");
   }
   return L;
}

/*! \brief Saves "WordList" to a record in "L".
 *  
 */
struct List_Str *Saveset(struct List_Str *WordList,struct List_Str *L){
   char *Data=NULL;
   struct List_Str *List1=WordList;
   Data=L->Str;
   Rep_DB_Entry(Goto_DB_Entry(Database[1],Data),0,7,List2Str(List1));
   L=L->Next;
   return L;
}

/*! \brief Retrieves a list of all record names in the database data segment.
 *  
 */
struct List_Str *All(struct List_Str *Word_List,struct List_Str *L){
  struct Datablock *DB1=Database[1];
   ANSWER=NULL;
   while(DB1){
      ANSWER=Ins_List_Element(ANSWER,DB1->DS[0]->Str,0);
      DB1=DB1->Next;
   }
   return L;
}

/*! \brief Copy record header information from one database record to another.
 *  
 */
struct List_Str *Copy(struct List_Str *Word_List,struct List_Str *L){
   int Loc_From=0;
   char *To=NULL,*From=NULL;
   struct Datablock *RelFrom=Database[0],*RelTo=Database[0],*DBFrom=Database[1],*DBTo=Database[1];
   L=L->Next;
   if(Word_List){
      if(L){
	 From=L->Str;
	 L=L->Next;
	 DBFrom=Goto_DB_Entry(Database[1],From);
	 RelFrom=Goto_DB_Entry(Database[1],From);
	 while(Word_List){
	    DBTo=Database[1];
	    To=Word_List->Str;
	    Word_List=Word_List->Next; 
	    DBTo=Goto_DB_Entry(Database[1],To);
	    DBTo->DS[0]=Cpy_List(DBFrom->DS[0]);
	    DBTo->DS[1]=Cpy_List(DBFrom->DS[1]);
	    DBTo->DS[2]=Cpy_List(DBFrom->DS[2]);
	    DBTo->DS[0]->Str=StrCat("",To);
	    if(Loc_From>-1){
	       RelTo=Goto_DB_Entry(Database[1],To);
	       RelTo->DS[0]=Cpy_List(RelFrom->DS[0]);
	       RelTo->DS[1]=Cpy_List(RelFrom->DS[1]);
	       RelTo->DS[2]=Cpy_List(RelFrom->DS[2]);
	       RelTo->DS[0]->Str=StrCat("",To);
	    }
	 }
      }
      else{
	 puts("Syntax, [A] :COPY [B].");
      }
   }
   else{
      puts("Syntax, [A] :COPY [B].");
   }
  return L;
}

/*! \brief Associate database records.
 *  
 */
struct List_Str *Like(struct List_Str *Word_List,struct List_Str *L){
   char *To=NULL,*From=L->Str;
   struct Datablock *DBFrom=NULL,*DBTo=NULL;
   DBFrom=Goto_DB_Entry(Database[1],From);
   while(Word_List){
      DBTo=Goto_DB_Entry(Database[1],To=Word_List->Str);
      Word_List=Word_List->Next;
      (DBTo->DS[0]=Cpy_List(DBFrom->DS[0]))->Str=StrCat("",To);
   }
   return L->Next;
}

/*! \brief Specify a database attribute value.
 *  
 */
struct List_Str *Qualify(struct List_Str *Word_List,struct List_Str *L){
   int Suitable=1,Counter=0,C=0,LP=0; 
   char *Qualifier=NULL,*Analogies=NULL;
   struct List_Str *Buffer=NULL,*AnalogyParts=NULL,*ListPosition=NULL;
   struct Datablock *Node=NULL;
   Buffer=L->Next;
   Qualifier=L->Str;
   while((Buffer->Next)&&(Buffer->Str[0]!=':')){
      AnalogyParts=Ins_List_Element(AnalogyParts,Buffer->Str,Counter);
      Counter++;
      Buffer=Buffer->Next;
   }
   if(Buffer)
     if(Buffer->Str[0]!=':'){
	AnalogyParts=Ins_List_Element(AnalogyParts,Buffer->Str,Counter);
	Counter++;
     }
   if(Counter<1)
     Suitable=0;
   if(Suitable){
      Analogies=List2Str(AnalogyParts);
      while(Word_List){
	 Node=Goto_DB_Entry(Database[1],Word_List->Str);
	 if((LP=Find_List_Element(Node->DS[1],Qualifier))>-1){
	    ListPosition=Node->DS[2];
	    for(C=0;C<LP;C++)
	      ListPosition=ListPosition->Next;
	    ListPosition->Str=Analogies;
	 }
	 else{
	    Node->DS[1]=Ins_List_Element(Node->DS[1],Qualifier,0);
	    Node->DS[2]=Ins_List_Element(Node->DS[2],Analogies,0);
	 }
	 Word_List=Word_List->Next;
      }
   }
   return L;
}

/*! \brief Remove all database record of a name from the database.
 *  
 */
struct List_Str *Delete(struct List_Str *Word_List,struct List_Str *L){
   char *STR=NULL;
   if(ThinkOutLoud)
     printf("Deleting: ");
   for(;Word_List;Word_List=Word_List->Next){
      STR=Word_List->Str;
      if(ThinkOutLoud)
	printf("%s ",STR);
      Database[1]=Del_DB_Entry(Database[1],Find_DB_Entry(Database[1],STR)); 
      Database[0]=Del_DB_Entry(Database[0],Find_DB_Entry(Database[0],STR));
   }
   if(ThinkOutLoud)
     puts("");
   return L;
}

/*! \brief Return a record with the same grammar attribute as "type".
 *  - should be recoded.
 */
char *Find_Grammar_Example(char *Type){
  struct Datablock *DB=NULL;
  for(DB=Database[1];DB;DB=DB->Next)
    if(!strcmp(Get_DB_Entry(DB,0,1),Type))
      return Get_DB_Entry(DB,0,0);
  return Type;
}

/*! \brief Find a list of records with similar value characteristics to another record.
 *  
 */
struct List_Str *Similar(struct List_Str *WordList,struct List_Str *L){
  int _=0;
  char *Buffer=L->Str;
  struct List_Str *Inp1=NULL,*Inp2=NULL,*Inp3=NULL, *ListBuffer=NULL;
  ANSWER=NULL;
  ListBuffer=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],Buffer),0,7));
  for(Inp1=WordList;Inp1;Inp1=Inp1->Next)
    for(Inp3=Goto_DB_Entry(Database[1],Inp1->Str)->DS[2];Inp3;Inp3=Inp3->Next)
      for(Inp2=ListBuffer;Inp2;Inp2=Inp2->Next)
	if(strcmp(Inp3->Str,Inp2->Str)==0)
	  ANSWER=Ins_List_Element(ANSWER,Inp1->Str,_++);
  return L->Next;
}

/*! \brief Find a list of records with similar attribute characteristics to another record.
 *  
 */
struct List_Str *Described(struct List_Str *Word_List,struct List_Str *L){
  int _=0;
  char *Buffer=L->Str;
  struct List_Str *Inp1=NULL,*Inp2=NULL,*Inp3=NULL, *ListBuffer=NULL;
  ANSWER=NULL;
  ListBuffer=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],Buffer),0,7));
  for(Inp1=Word_List;Inp1;Inp1=Inp1->Next)
    for(Inp3=Goto_DB_Entry(Database[1],Inp1->Str)->DS[1];Inp3;Inp3=Inp3->Next)
      for(Inp2=ListBuffer;Inp2;Inp2=Inp2->Next)
	if(strcmp(Inp3->Str,Inp2->Str)==0)
	  ANSWER=Ins_List_Element(ANSWER,Inp1->Str,_++);
  return L->Next;
}

/*! \brief Save data in a record for literal evaluation.
 *  
 */
struct List_Str  *Store(struct List_Str *Word_List,struct List_Str *L){
   char *V2=L->Str;
   Rep_DB_Entry(Goto_DB_Entry(Database[1],V2),0,7,List2Str(ANSWER=Word_List));
   return L->Next;
}

/*! \brief Retrieve the evaluation of a concept "L".
 *  
 */
struct List_Str *Definition(struct List_Str *Word_List,struct List_Str *L){
   PrintList(L);
   return NULL;
}

/*! \brief Retrieve the evaluation of a concept "L".
 *  - similar to Store()
 */
struct List_Str *Define(struct List_Str *Word_List,struct List_Str *Command_List){
   for(;Word_List;Word_List=Word_List->Next)
      Rep_DB_Entry(Goto_DB_Entry(Database[1],Word_List->Str),0,7,List2Str(Command_List));
   return NULL;
}

/*! \brief This function specifies the parameters of the WMS database so that it can automatically manage its contents.
 * 
 */
struct List_Str *Mode(struct List_Str *Word_List,struct List_Str *List){
   int _=0,Prev=0,WordLength=0,Index=0,NotNumber=0; 
   double Number=0; 
   char *Word=NULL;
   struct List_Str *R=List;
   struct Datablock *TMP=Goto_DB_Entry(Database[1],":mode");
   if(R&&(strcmp(Word=R->Str,":end"))){
      while(R&&(strcmp(Word=R->Str,":end"))){
	 _=0;
	 if(!strcmp(Word,":mode"))
           _=6;
	 if(!strcmp(Word,":memlimit")){
	   printf("Maximum concepts                     : %g\n",MemoryLimit);
	   _=1;
	 }
	 if(!strcmp(Word,":memexp")){
	   printf("Minimum time duration for forgetting : %g\n",MemoryExp);
	   _=2;
	 }
	 if(!strcmp(Word,":memprob")){
	   printf("Geometric ratio of memory decay      : %g\n",MemoryProbability);
	   _=3;
	 }
	 if(!strcmp(Word,":memrate")){
	   printf("Rate of forgetting to learning       : %g\n",MemoryRate);
	   _=4;
	 }
	 if(!strcmp(Word,":memthresh")){
	   printf("Critical probability                 : %g\n",MemoryThreshold);
	   _=5;
	 }
	 WordLength=StrLen(Word);
	 NotNumber=0;
	 for(Index=0;Index<WordLength;Index++) 
	   if(!isdigit(Word[Index])&&!(Word[Index]=='.')&&!(Word[Index]=='-'))
	     NotNumber=1;
	 if(!_){
	    if(NotNumber){
	       if(Prev==6)
		 Print_DB_Entry(TMP,0);
	       return R;
	    }
	    if(!Prev)
	      return R;
	    if(Prev==6){
	       Print_DB_Entry(TMP,0);
	       return R;
	    }
	 }
	 if(!NotNumber){
	    Number=atof(Word); 
	    if(Prev>0&&Prev<6){
	       printf("Reset to                             : %g\n",Number); 
	       Rep_DB_Entry(TMP,2,Prev-1,FloatToString(Number));
	    }
	    if(Prev==1)
	      MemoryLimit=Number;
	    else if(Prev==2)
	      MemoryExp=Number;
	    else if(Prev==3)
	      MemoryProbability=Number;
	    else if(Prev==4)
	      MemoryRate=Number;
	    else if(Prev==5)
	      MemoryThreshold=Number;
	 } 
	 R=R->Next;
	 Prev=_;
      }
   }
   else
     Print_DB_Entry(TMP,0); 
   return R;
}

/*! \brief Appends the contents of "L" to the list "Word_List".
 * 
 */
struct List_Str *Append(struct List_Str *Word_List,struct List_Str *L){
   struct List_Str *APPEND=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],L->Str),0,7));
   L=L->Next;
   ANSWER=Ins_List_List(Word_List,APPEND,Size_of_List(Word_List));
   return L;
}

/*! \brief Finds the base verb of another verb.
 * 
 */
struct List_Str *VerbBaseFinder(struct List_Str *L){
  int _=0;
  struct List_Str *Input=NULL;
  struct Datablock *DB=NULL;
  for(Input=L;Input;Input=Input->Next)
    if(IsArticle(Input->Str,"verb")){
      DB=Goto_DB_Entry(Database[1],Input->Str);
      if((_=Find_List_Element(DB->DS[1],":baseword"))+1)
	Input->Str=Get_DB_Entry(DB,2,_);
    }
  return L;
}

/*! \brief Determines if the word "Word" is one of article "Articles".
 * 
 */
int IsArticle(char *Word,char *Articles){
  int Found=0;
  struct List_Str *ArticleList=NULL,*RecoveredArticles=NULL,*Buffer=NULL;
  struct Datablock *DB=NULL;
  if(Word&&Articles){
    if((DB=Goto_DB_Entry(Database[1],Word))){
      RecoveredArticles=Str2List(Get_DB_Entry(DB,0,1));
      ArticleList=Str2List(Articles);
      for(Buffer=ArticleList;Buffer;Buffer=Buffer->Next)
	if(Is_List_Element(RecoveredArticles,Buffer->Str))
	  Found=1;
      FreeList(RecoveredArticles);
      FreeList(ArticleList);
    }
  }
  return Found;
}

/*! \brief Retrieves a list of words from "Word_List" that match article filters "Articles".
 * 
 */
struct List_Str *ExtractArticles(struct List_Str *Word_List,char *Articles){
  int Pos=0;
  struct List_Str *Buffer=NULL,*R=NULL;
  for(Buffer=Word_List;Buffer;Buffer=Buffer->Next){
    if(IsArticle(Buffer->Str,Articles))
      R=Ins_List_Element(R,Buffer->Str,Pos++);
  }
  return R;
}

/*! \brief Filters out any auxillary verbs.
 * 
 */
struct List_Str  *DiscardAuxVerbs(struct List_Str *VerbData){
  int _=0;
  struct List_Str *VerbRemaining=NULL,*AuxVerbs=NULL,*Buffer=NULL;
  struct Datablock *Lang=NULL;
  if((Lang=GetLang())){
    AuxVerbs=Str2List(Lookup_DB_Attr(Lang,":auxverbs",NULL));
    if(Size_of_List(VerbData)>1){
      for(Buffer=VerbData;Buffer;Buffer=Buffer->Next)
	if(!Is_List_Element(AuxVerbs,Buffer->Str))
	  VerbRemaining=Ins_List_Element(VerbRemaining,Buffer->Str,_++);
    }
    else
      VerbRemaining=VerbData;
  }
  else{
    if(ThinkOutLoud)
      printf("ERROR: %s:%d Language not setup!\n",__FILE__,__LINE__);
  }
  return VerbRemaining;
}

/*! \brief Specifies the auxillary verbs.
 * 
 */
struct List_Str *AuxVerbs(struct List_Str *Word_List,struct List_Str *L){
  struct Datablock *Lang=NULL;
  Lang=GetLang();
  if(!Lang){
    printf("ERROR AuxVerbs[%s:%d] language not setup - aborting.\n",__FILE__,__LINE__);
    return L;
  }
  Rep_DB_Pair(Lang,":auxverbs",List2Str(Word_List));
  return L;
}

/*! \brief Do a semantic comparison based on subject.
 *  - if meaning of "Locate" is equivalent to meaning of "In", return true.
 */
int Comp_Sem_Subject(struct List_Str *Locate,struct List_Str *In){
  int NotFoundNoun=0,PartialFind=0;
  struct List_Str *Buffer=NULL,*Buffer1=NULL,*NounClasses=Str2List(Lookup_DB_Attr(GetLang(),":nouns",NULL));
  for(Buffer=Locate;Buffer;Buffer=Buffer->Next){
    for(Buffer1=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],Buffer->Str),0,1));Buffer1;Buffer1=Buffer1->Next){
      if(Is_List_Element(NounClasses,Buffer1->Str)){
	if(!Is_List_Element(In,Buffer->Str))
	  NotFoundNoun=1;
      }
      else{
	if(!strcmp(Buffer1->Str,"adjective"))
	  if(!Is_List_Element(In,Buffer->Str))
	    PartialFind=1;
      }
    }
  }
  if(NotFoundNoun)
    return 0;
  else{
    if(PartialFind)
      return -1;
    else
      return 1;
  }
}

/*! \brief Retrieve the previous answer from ENiX :memory.
 * 
 */
struct List_Str *Recall_Prev_Answer(){
  char *Data=NULL;
  struct List_Str *R=NULL;
  struct Datablock *DB=Goto_DB_Entry(Database[1],":memory");
  if(DB)
    if(strcmp(Data=Get_DB_Entry(DB,0,7),"?"))
      R=Str2List(Data);
  return R;
}

/*! \brief Add any new words that are not in the ENiX database.
 * 
 */
struct Datablock *Recognise(struct Datablock *LS,struct List_Str *Com){ /* Recognise version 2.2 */
  struct List_Str *List1=NULL;
  struct Datablock *R=NULL;
  for(List1=Com;List1;List1=List1->Next)
    if(List1->Str[0]!=':'){
      if((R=Goto_DB_Entry(Database[1],List1->Str))){
	Rep_DB_Entry(R,0,5,Seconds2Str());
	Rep_DB_Entry(R,0,6,FloatToString(1));
      }
      else{
	if(Find_DB_Entry(LS,List1->Str)==-1)
	  LS=Add_DB_Entry(LS,List1->Str);
	DB_Size++;
	Newly_Learnt++;
      }
    }
  return LS;
}

/*! \brief Retrieves articles of clause "S" which contribute to the meaning of the clause, disregarding the rest.
 * 
 */
struct List_Str  *CoreSubjMtr(struct List_Str *S){
  int Flag=0,Position=0;
  struct Datablock *Lang=GetLang();
  struct List_Str *Out=NULL,*Useful=NULL,*Buffer1=NULL,*Buffer3=NULL;
  Useful=Ins_List_Element(Ins_List_Element(Ins_List_Element(Str2List(Get_DB_Entry(Lang,2,Find_List_Element(Lang->DS[1],":nouns"))),"preposition",0),"adjective",0),"conjunction",0);
  Position=0;
  for(Buffer1=S;Buffer1;Buffer1=Buffer1->Next){
    Flag=0; 
    for(Buffer3=Useful;Buffer3;Buffer3=Buffer3->Next)
      if(IsArticle(Buffer1->Str,Buffer3->Str))
	Flag=1;
    if(Flag)
      Out=Ins_List_Element(Out,Buffer1->Str,Position++);
  }
  return Out;
}

/*! \brief Retrieves the conversation topic which is stored in :topic.
 * 
 */
struct List_Str *Topic(struct List_Str *Word_List,struct List_Str *L){
  int Noun=0;
  char *Temp=NULL;
  struct List_Str *R=NULL,*Buffer1=NULL,*Buffer2=NULL;
  struct Datablock *DB=NULL;
  if((DB=Goto_DB_Entry(Database[1],":topic"))){
    for(Buffer1=DB->DS[1];Buffer1;Buffer1=Buffer1->Next){
      Noun=0;
      for(Buffer2=Str2List(Buffer1->Str);Buffer2;Buffer2=Buffer2->Next)
	if(IsArticle(Buffer2->Str,"noun")){
	  Noun=1;
	  break;
	}
      if(Noun)
	Temp=StrCat("the ",Buffer1->Str);
      else
	Temp=Buffer1->Str;
      R=Add2Set(R,Temp);
    }
    if(ENABLEOUT)
      PrintListSpecial("We are currently discussing: ",R,", "," and ",".\n");
    ANSWER=R;
  }
  else{
    if(ThinkOutLoud)
      puts("No conversation specified.");
  }
  return L;
}

/*! \brief Add a emotion hook to execute when emotion is a certain type.
 * 
 */
struct List_Str  *Hook(struct List_Str *Word_List,struct List_Str *L){
  struct List_Str *Buffer=NULL;
  struct Datablock *DB=NULL;
  for(Buffer=Word_List;Buffer;Buffer=Buffer->Next){
    DB=Goto_DB_Entry(Database[1],Buffer->Str);   
    Rep_DB_Pair(DB,":hook",List2Str(L));
  }
  return NULL;
}

/*! \brief Specify emotion data for debugging purposes.
 * 
 */
struct List_Str  *PopEmoDebug(struct List_Str *Word_List,struct List_Str *L){
   char *Mood=NULL,*TPI=NULL,*Value=NULL;
   struct List_Str *Buffer=Word_List;
   struct Datablock *DB=NULL;
   if(Size_of_List(Buffer)>1){
      Mood=L->Str;
      TPI=Buffer->Str;
      Value=Buffer->Next->Str;
      DB=Goto_DB_Entry(Database[0],StrCat(":Cache_",Mood));
      if(DB)
	Rep_DB_Pair(DB,TPI,Value);
      else
	printf("PopEmoDebug (%s:%d) Emotion data not found...\n",__FILE__,__LINE__);
   }
   else
     if(ThinkOutLoud)
     puts("ERROR: Insufficient context prefix for :PopEmoDebug");
   return L->Next;
}

/*! \brief Clear emotion data for debugging purposes.
 * 
 */
struct List_Str  *ClrEmoDebug(struct List_Str *Word_List,struct List_Str *L){
   struct List_Str *Buffer=NULL;
   struct Datablock *DB=NULL;
   for(Buffer=Word_List;Buffer;Buffer=Buffer->Next){
      DB=Goto_DB_Entry(Database[0],StrCat(":Cache_",Buffer->Str));
      if(DB){
	 Rep_DB_Entry(DB,0,1,"?");
	 Rep_DB_Entry(DB,0,2,"?");
	 Rep_DB_Entry(DB,0,3,"?");
	 Rep_DB_Entry(DB,0,7,"?");      
	 DB->DS[1]=NULL;
	 DB->DS[2]=NULL;
      }
      else if(ThinkOutLoud)
	printf("ERROR: no :Cache_%s in DB[0]\n",Word_List->Str);
   }
   return L;
}

/*! \brief Print emotion data for a specific concept.
 * 
 */
struct List_Str  *GetEmoDebug(struct List_Str *Word_List,struct List_Str *L){
   struct List_Str *Buffer=NULL;
   char *CachedData=NULL;
   struct Datablock *DB=NULL;
   for(Buffer=Word_List;Buffer;Buffer=Buffer->Next){
     if((DB=Goto_DB_Entry(Database[0],CachedData=StrCat(":Cache_",Buffer->Str))))
	Print_DB_Entry(DB,0);
   }
   return L;
}

/*! \brief Override the system's emotional mood.
 * 
 */
struct List_Str  *SetMood(struct List_Str *Word_List,struct List_Str *L){
  char *CachedData=NULL;
  SetGrammarAttr(Word_List,":mood");
  if(!Goto_DB_Entry(Database[0],CachedData=StrCat(":Cache_",Word_List->Str)))
    Database[0]=Add_DB_Entry(Database[0],CachedData);
  return L;
}

/*! \brief List the emotions that have names in ENiX.
 * 
 */
struct List_Str *EmoList(struct List_Str *Word_List,struct List_Str *L){
  struct Datablock *DB=Goto_DB_Entry(Database[1],":emotionlist");
  if(DB)
    ANSWER=Str2List(Get_DB_Entry(DB,0,7));
  else
    if(ThinkOutLoud)
      puts("WARNING: is :emotionlist defined?");
  return L;
}

/*! \brief Translate an emotion name into an emotion vector.
 * 
 */
struct List_Str  *Emo2Vec(struct List_Str *Word_List,struct List_Str *L){
  char *EmotionV=NULL;
  struct Datablock *DB=NULL;  
  if((DB=Goto_DB_Entry(Database[1],Word_List->Str))){
    EmotionV=Get_DB_Entry(DB,0,3);
    if(EmotionV[0]!=':')
      ANSWER=Str2List(EmotionV);
  }
  return L;
}

/*! \brief Work out what emotion response is required when the system is "ModifierEmo" to map the user's mood from "SourceEmo" to "TargetEmo".
 * 
 */
char *EmoTableLookup(char *SourceEmo,char *ModifierEmo, char *TargetEmo){
  char *LookedUp=NULL;
  struct Datablock *DB=NULL;
  if((SourceEmo)||(ModifierEmo)){
    if((DB=Goto_DB_Entry(Database[0],StrCat(":Cache_",TargetEmo)))){
      LookedUp=Lookup_DB_Attr(DB,SourceEmo,ModifierEmo);
      if(LookedUp)
	return LookedUp;
      else
	return TargetEmo;
    }
    else
      return TargetEmo;
  }
  else
    return TargetEmo;
}

/*! \brief Create a hidden markov model.
 * 
 */
struct List_Str *CreateGraph(struct List_Str *Word_List,struct List_Str *L){
   int _=0;
   char *GraphID=NULL,*Template=NULL;
   struct Datablock *DB=NULL;
   if(IsGrammarAttribute(":locklang","on")){
      puts("Sorry the language grammar is locked.");
      return L;
   }
   GraphID=L->Str;
   PrintList(Word_List);
   if((DB=Goto_DB_Entry(Database[1],GraphID))){
      Template=List2Str(Word_List);
      if((_=Find_List_Element(DB->DS[2],Template))+1){
	 if(strcmp(Get_List_Element(DB->DS[1],_),":TEMPLATE")){
	    DB->DS[1]=Ins_List_Element(DB->DS[1],":TEMPLATE",0);
	    DB->DS[2]=Ins_List_Element(DB->DS[2],Template,0);
	 }
      }
      else{
	 DB->DS[1]=Ins_List_Element(DB->DS[1],":TEMPLATE",0);
	 DB->DS[2]=Ins_List_Element(DB->DS[2],Template,0);
      }
   }
   else if(ThinkOutLoud) puts("ERROR: Concept does not exist.");
   return L->Next;
}

/*! \brief Returns true if a qualifier "Qualifier" are values "Values".
 * 
 */
int AreAnyGAttributes(char *Qualifier,struct List_Str *Values){
  int R=0;
  while(Values){
    if(IsGrammarAttribute(Qualifier,Values->Str)){
      R=1;
      Values=NULL;
    }
    else
      Values=Values->Next;
  }
  return R;
}

/*! \brief Sets up ENiX to sensible defaults.
 * 
 */
struct List_Str *Setup(struct List_Str *Word_List,struct List_Str *L){ 
   int OK=0;
   struct List_Str *Input=NULL;
   Input=Word_List;
   if(strncmp(Input->Str,"grammar",7)==0) OK=1;
   if(strncmp(Input->Str,"emotion",7)==0) OK=3;
   if(strncmp(Input->Str,"purpose",7)==0) OK=2;
   if(OK>0){      
      Rep_DB_Entry(Goto_DB_Entry(Database[1],":mode"),0,OK,Input->Str); 
      if(!Goto_DB_Entry(Database[1],Input->Str)) 
	Database[1]=Add_DB_Entry(Database[1],Input->Str);
      New_Relate(OK,"startsentence"); 
      New_Relate(OK,"endsentence"); 
      if(!Goto_DB_Entry(Database[1],"startsentence")) 
	Database[1]=Add_DB_Entry(Database[1],"startsentence");
      if(!Goto_DB_Entry(Database[1],"endsentence"))   
	Database[1]=Add_DB_Entry(Database[1],"endsentence");
      if(!Goto_DB_Entry(Database[1],"?"))             
	Database[1]=Add_DB_Entry(Database[1],"?");
   }
   return L;
}

/*! \brief Checks for SentenceUnity in the sentence.
 * 
 */
int IsSentence(struct List_Str *List){
   int _=0,Counter=0;
   char *Lang=NULL,*Unit=NULL;
   struct List_Str *Buffer=List;
   struct Datablock *DB=Database[1];
   Lang=Get_DB_Entry(Goto_DB_Entry(Database[1],":mode"),0,1);
   if(!(DB=Goto_DB_Entry(Database[0],Lang)))
     puts("ERROR: Language not setup properly.");
   _=Find_List_Element(DB->DS[1],":sentenceunit");
   if(_<0)
     puts("ERROR: Language not setup properly.");
   Unit=Get_List_Element(DB->DS[2],_);
   while(Buffer){
      if(!strcmp(Get_DB_Entry(Goto_DB_Entry(Database[1],Buffer->Str),0,1),Unit))
	Counter++;
      Buffer=Buffer->Next;
   }
   if(Counter<2)
     return 1; 
   else
     return 0;      
}

/*! \brief Adds a emotion to a record for debugging purposes.
 * 
 */
struct List_Str  *AddEmoDebug(struct List_Str *Word_List,struct List_Str *L){
   char *Ret=NULL,*CachedData=NULL;
   struct List_Str *Buffer=NULL;
   struct Datablock *DB=Goto_DB_Entry(Database[1],L->Str);
   if(DB)
     Rep_DB_Entry(DB,0,3,List2Str(Word_List));
   if(!(DB=Goto_DB_Entry(Database[1],":emotionlist")))
     DB=Database[1]=Add_DB_Entry(Database[1],":emotionlist");
   if(!Is_List_Element(Buffer=Str2List(Ret=Get_DB_Entry(DB,0,7)),L->Str)){
      if(strcmp(Ret,"?"))
	Rep_DB_Entry(DB,0,7,List2Str(Ins_List_Element(Buffer,L->Str,0)));
      else
	Rep_DB_Entry(DB,0,7,L->Str);
   }
   if(!Goto_DB_Entry(Database[0],CachedData=StrCat(":Cache_",L->Str)))
     Database[0]=Add_DB_Entry(Database[0],CachedData);
   return L->Next;
}

/*! \brief Prints out smilies for emotions.
 * 
 */
void SetEmotionRoot(int Understanding,int Internal){
   int _=3+Internal;
   struct Datablock *Lang=GetLang();
   if(Lang){
      if(!Understanding)
	Rep_DB_Entry(Lang,0,_,":(");
      if(Understanding==1)
	Rep_DB_Entry(Lang,0,_,":/");
      if(Understanding==2)
	Rep_DB_Entry(Lang,0,_,":)");
   }
}





/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
