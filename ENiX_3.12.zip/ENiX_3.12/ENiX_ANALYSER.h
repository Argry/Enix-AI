/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#ifndef ENiXANALYSER
#define ENiXANALYSER

struct Kernel_Problem{
   int Minimal;
   int Size;
   int Inputs;
   int Outputs;
   int Split;
   int *Knowns;
   int *Unknowns;
   int Complexity;
};

extern struct Kernal_Problem K_Problem;

struct Canonical_Problem{
  int Inputs;       /* number of input bits */
  int Size;         /* number of examples */
  int *Positions;   /* symlinks */
  int *Unknowns;    /* */
  int *Knowns;      /* */
  int *Logic_Grid;  /* container for solution */
  int *Input_Route; /* primary inputs   1.5.2008 */
  int G_Max;        /* debugging only */
  int R_Max;        /* debugging only */
  int Complexity;   /* problem complexity */
};

extern struct Canonical_Problem Opt_P;

extern int              Complexity;
extern struct Kernel_Problem    *Sub_Problems;
extern struct Canonical_Problem *Opt_Problems;
extern int Fabricate_Current_Example;


struct List_Str  *Decide(struct List_Str *WordList,struct List_Str *L);
struct List_Str  *Understand(struct List_Str *Word_List,struct List_Str *L);
struct List_Str  *DebugAware(struct List_Str *Word_List,struct List_Str *L);
int              Internal_Execute(struct List_Str *Logic_Grid,int TPI);
int              Single_Input_Gates(int Gate_ID, int Input);        /* Mj */
int              Double_Input_Gates(int Gate_ID, int In1, int In2); /* Mj */
struct List_Str  *Decision_Maker(struct List_Str *Word_List, struct List_Str *L);
void             Thought_Procreator(struct Kernel_Problem P, struct Canonical_Problem *Opt_P);
int              *Add_Number(int *List,int Size, int N);
void             Fabricate(struct Canonical_Problem *Opt_P, struct Kernel_Problem P);
int              Analyse_Pattern(struct Canonical_Problem *Opt_P);
int              Layer_Mutate_Structure(struct Canonical_Problem *Opt_P,int Layer_Inputs,int Layer_Offset);
int              Layer_Gate_Mutation(struct Canonical_Problem *Opt_P);
int              Test_Mutation(struct Canonical_Problem *Opt_P);
int              Execute_Part(struct Canonical_Problem *Opt_P,int TPI);
struct List_Str  *ODDMAN(struct List_Str *WordList,struct List_Str *L);
struct List_Str  *Correct(struct List_Str *WordList,struct List_Str *L);



#endif

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
