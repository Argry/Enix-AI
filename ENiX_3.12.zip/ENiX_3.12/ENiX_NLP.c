/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#include "ENiX_PLURALS.h"
#include "ENiX_MULTIPLEX.h"
#include "ENiX_Globals.h"
#include "ENiX_WMS.h"
#include "ENiX_WMS_COMPAT.h"
#include "ENiX_LIST.h"
#include "ENiX_CS.h"
#include "ENiX_STRING.h"
#include "ENiX_STEMMER.h"
#include "ENiX_EMO.h"
#include "ENiX_EXEC.h"
#include "ENiX_SETTHEORY.h"
#include "ENiX_SEMANTICS.h"
#include "ENiX_APPLICATIONS.h"
#include "ENiX_NLP.h"
#include "ENiX_HLR.h"
#include "ENiX_TIME.h"
#include "ENiX_CONV.h"
#include "ENiX_SPLINE.h"
#include "ENiX_VirtualDB.h"
#include "ENiX_REASON.h"

char             *WHQPrep=NULL;
char             *LogicTypes[]={"AND","OR","NOR","XOR","ERROR"};
char             *TenseTypes[]={"past","present","future"};

/*! \brief This function is the top level function for parsing all written language.
 *
 */
struct List_Str *IntelligentInt(struct List_Str *Word_List,int Save){
  int _=0,Sentient=Detect_Sentiency(),Detect_BI=0,InitialVerbosity=0;
  struct List_Str *R=NULL,*Buffer=NULL,*Buffer2=NULL,*Unknowns=NULL,*ConditionalSymbols=NULL;
  struct Datablock *DB=NULL,*Lang=GetLang();
  struct Sentence *Sentence=NULL;

  /* Recognise needs to be inserted here */
  ThinkOutLoud=IsEnabled(Get_DB_Entry(Goto_DB_Entry(Database[1],":mode"),0,1),":tol");
  Database[1]=Recognise(Database[1],Word_List);
  Buffer=Word_List;
  while(Buffer){
    if(Buffer->Str[0]==':')
      Detect_BI=1;
    if(Detect_BI)
      Buffer=NULL;
    else
      Buffer=Buffer->Next;
  }
  if(Detect_BI){
    Execute(Recall_Prev_Answer(),Interpreter(Ins_List_Element(Word_List,":null",0)));
    return NULL;
  }
  Buffer=NULL;
  if(Sentient){
    Add2ConvBuffer(ConversationSource,List2Str(Word_List));
    ConditionalSymbols=Ins_List_List(Str2List(Lookup_DB_Attr(Lang,":setcondcause",NULL)),Str2List(Lookup_DB_Attr(Lang,":setcondeffect",NULL)),0);
    if(ConditionalSymbols)
      if(IntIntersect(ConditionalSymbols,Word_List)){
	ProcessReasoning(Word_List);
	return R;	
      }
    /* this section processes :verbpostproc which is there to allow the user to override functionality */
    VerbPostProc(Word_List,NULL);
    if(VERBPOSTPROC)
      return NULL;
    if(!Goto_DB_Entry(Database[1],":iibuffer"))
      Database[1]=Add_DB_Entry(Database[1],":iibuffer");
    Buffer=Word_List;

    ParseSentenceEmotion(Buffer);
    Sentence=ConvertSentence(Word_List,1,0);
    if(!Sentence->Understood){
      if(!Sentence->ComplexSentence){
	Execute(Recall_Prev_Answer(),Interpreter(Ins_List_Element(Word_List,":null",0)));
	InitialVerbosity=DetectVerbosity();
	SetVerbosity(0);
	Think1(Word_List,NULL);
	SetVerbosity(InitialVerbosity);
      }
      return R;
    }
    /* this is where we need to classify the words */
    Unknowns=Unknown_Words(Buffer);
    if(Unknowns){
      for(Buffer=Unknowns;Buffer;Buffer=Buffer->Next)
	StemClass(Str2List(Buffer->Str),NULL);
      Unknowns=Unknown_Words(Buffer);
    }
    if( Unknowns && Save ){
      /* short term memory bug saves multiple occurances */
      DB=Goto_DB_Entry(Database[1],":memory");
      if((_=Find_List_Element(DB->DS[2],List2Str(Buffer)))==-1)
	Rep_DB_Pair(DB,":sentence",List2Str(Buffer));
    }
    if((Sentence->InterceptedSpirit==1)||(Sentence->InterceptedSpirit==2)){
      if(Unknowns){
	printf("What is the meaning of: ");
	PrintList(Unknowns);
	return R;
      }
      if(Sentence->InterceptedSpirit==2){
	/* YN Question */
	if(IsMultiplexQuery(Sentence))
	  OutputAnswer("",Ins_List_Element(NULL,"yes",0)," "," ",".",0);
	else
	  OutputAnswer("",Ins_List_Element(NULL,"no",0)," "," ",".",0);
      }
      else{
	/* WH Question */
	if((Buffer=MultiplexQuery(Sentence)))
	  for(Buffer2=Buffer;Buffer2;Buffer2=Buffer2->Next)
	    OutputAnswer("",Str2List(Buffer2->Str)," "," ",".",0);
	else
	  OutputAnswer("",Str2List("i dont know")," "," ",".",0);
      }
    }
    if((Sentence->InterceptedSpirit==0)||(Sentence->InterceptedSpirit==5)||(Sentence->InterceptedSpirit==4))
      Execute(Recall_Prev_Answer(),Interpreter(Ins_List_Element(Word_List,":null",0)));
    if(Sentence->InterceptedSpirit==3){
      /* Indicative */
      if(!Unknowns){
	MultiplexIndicative(Sentence);
      }
    }
  }
  else
    Execute(Recall_Prev_Answer(),Interpreter(Ins_List_Element(Word_List,":null",0)));
  return R;
}

/*! \brief Move the adjectives before the nouns
 * - Note doesnt handle conjunctions
 */
struct List_Str  *PutAdjectivesFirst(struct List_Str *List){
  struct List_Str *Articles=NULL,*Adjectives=NULL,*Nouns=NULL,*Clause=NULL;
  Articles=ExtractArticles(List,"definitearticle indefinitearticle");
  Adjectives=ExtractArticles(List,"adjective");
  Nouns=ExtractArticles(List,"noun propernoun pronoun");
  if(Nouns)
    Clause=Nouns;
  if(Adjectives)
    Clause=Ins_List_List(Clause,SortList(Adjectives),0);
  if(Articles)
    Clause=Ins_List_List(Clause,Articles,0);
  return Clause;
}

/*! \brief List sentences by topic.
 *
 */
struct List_Str  *ListByTopic(struct List_Str *Word_List,struct List_Str *L){
  int OriginalVerbosity=0;
  struct List_Str *AllSentences=NULL,*Sentences=NULL,*ConvTopic=NULL,*Buffer=NULL,*B2=NULL,*B3=NULL,*Found=NULL;
  ListSentences(CSList(),NULL);
  AllSentences=ANSWER;
  OriginalVerbosity=ENABLEOUT;
  ENABLEOUT=0;
  Topic(NULL,NULL);
  ENABLEOUT=OriginalVerbosity;
  ConvTopic=Str2List(List2Str(ANSWER));
  for(Buffer=AllSentences;Buffer;Buffer=Buffer->Next){
    Sentences=CSSentenceRecon(Buffer->Str);
    B3=Str2List(List2Str(Sentences));
    for(B2=Word_List;B2;B2=B2->Next)
      if((Is_List_Element(B3,B2->Str))&&(Is_List_Element(ConvTopic,B2->Str)))
	Found=Ins_List_Element(Found,Buffer->Str,0);
  }
  ANSWER=Found;
  return L;
}

/*! \brief List the sentences in ENiX.
 *
 */
struct List_Str  *ListSentences(struct List_Str *Word_List,struct List_Str *L){
  char *RecordName=NULL;
  struct List_Str *Buffer=NULL,*R=NULL;
  for(Buffer=Word_List;Buffer;Buffer=Buffer->Next){
    RecordName=StrCat("_examples_",Buffer->Str);
    if(Goto_DB_Entry(Database[0],RecordName))
      R=Ins_List_Element(R,Buffer->Str,0);
    free(RecordName);
  }
  ANSWER=R;
  return L;
}

/*! \brief Determine if a sentence is active or passive voice.
 * - Returns -1 if unknown, 0 if active, 1 if passive.
 */
int Active_Passive(struct List_Str *A){
  int R=0,C=0,Error=0,_=0,Found,Form=-1,PVF=0,Size=0,PastParticiple=0,PassiveAgent=0;
  struct List_Str *DA=NULL,*Input=NULL,*Verbs=NULL,*LISTofPVFS=NULL,*ThePVFLIST=NULL,*Buffer=NULL;
  struct Datablock *DB=NULL;
  if(Size_of_List(DA)!=Size_of_List(Input))
    return 0;
  for(DA=Disambiguated,Input=A;Input&&DA;DA=DA->Next,Input=Input->Next){
    if(IsGrammarAttribute(":spa",Input->Str))
      PassiveAgent=1;
    if(!strcmp(DA->Str,"verb"))
      Verbs=Ins_List_Element(Verbs,Input->Str,C++);
  }
  Buffer=Verbs;
  if(!(DB=Goto_DB_Entry(Database[1],":pvf")))
    Error=1;
  else{
    for(LISTofPVFS=DB->DS[2];LISTofPVFS;LISTofPVFS=LISTofPVFS->Next,PVF++){
      for(ThePVFLIST=Str2List(LISTofPVFS->Str),Found=1,_=0;ThePVFLIST;ThePVFLIST=ThePVFLIST->Next,_++){
	if(!Is_List_Element(Buffer,ThePVFLIST->Str))
	  Found=0;
      }
      if((Found)&&(_>Size)){
	Form=PVF;
	Size=_;
      }
    }
  }
  if(Form>-1){
    for(Buffer=Str2List(Get_DB_Entry(DB,2,Form));Buffer;Verbs=Verbs->Next,Buffer=Buffer->Next){}
    if(Verbs)
      /*
	if(!strcmp(Get_DB_Entry(Goto_DB_Entry(Database[1],Verbs->Str),0,2),"past"))
      */
      PastParticiple=1;
  }
  if(PastParticiple&&(Form+1)) R=1;
  if(Error) R=-1;
  if(R&&InterceptedSpirit)
    if(!PassiveAgent)
      R=0;
  if(ThinkOutLoud){
    printf("Sentence        : ");
    PrintList(A);
    printf("PVF             : %d\n",Form);
    printf("PastParticiple  : %d\n",PastParticiple);
    printf("Voice           : ");
    if(R==-1)
      puts("Unknown");
    if(!R)
      puts("Active");
    if(R==1){
      puts("Passive");
      printf("PVF             : %s (%s)\n",Get_DB_Entry(DB,2,Form),Get_DB_Entry(DB,1,Form));
    }
  }
  /*
    emotion processing
    ParseSentenceEmotion(A);
  */
  return R;
}

/*! \brief Extract the root verb of a sentence.
 * 
 */
struct List_Str *RootVerb(struct List_Str *WordList){
  int A=0,B=0,Found=-1,Position=0,MaxSize=0,_,Tense=0; /* Tense=-1 past Tense=0 present Tense=1 future */
  char *VerbPart=NULL,*SimpleTense=NULL,*Stash=NULL;
  struct List_Str *R=NULL,*VerbForms=NULL,*Buffer=NULL,*Buffer2=NULL,*B3=NULL;
  struct Datablock *DB=NULL;
  if((DB=Goto_DB_Entry(Database[1],":meldvf"))){
    VerbPart=List2Str(WordList);
    VerbForms=DB->DS[2];
    while(VerbForms){
      if(!strncmp(VerbPart,VerbForms->Str,_=strlen(VerbForms->Str))){
	if(_>MaxSize){
	  MaxSize=_;
	  Found=Position;
	}
      }
      Position++;
      VerbForms=VerbForms->Next;
    }
    if(Found+1){
      Buffer=Str2List(Get_DB_Entry(DB,2,Found));
      Buffer2=Cpy_List(WordList);
      while(Buffer){
	Buffer2=Buffer2->Next;
	Buffer=Buffer->Next;
      }
      Buffer=Str2List(Get_DB_Entry(DB,1,Found));

      if(Buffer2==NULL)
	Buffer2=Ins_List_Element(Buffer2,"is",0);
      else{
	B3=Buffer2;
	A=0;
	while(B3){
	  if(IsArticle(B3->Str,"verb")){
	    A=1;
	  }
	  B3=B3->Next;
	}
	if(!A)
	  Buffer2=Ins_List_Element(Buffer2,"is",0);
      }
      B3=SortList(Buffer2);
      A=0;
      B=0;
      Buffer2=NULL;
      while(B3){
	if(!IsArticle(B3->Str,"verb")){
	  Buffer2=Ins_List_Element(Buffer2,B3->Str,B++);
	}
	else{
	  if(!(Stash=List2Str(VerbBaseFinder(Str2List(B3->Str))))){
	    Stash=B3->Str;
	  }
	  Buffer2=Ins_List_Element(Buffer2,Stash,A++);
	  B++;
	}
	B3=B3->Next;
      }

      if(Is_List_Element(Buffer,"past")){
	Buffer2=Ins_List_Element(Buffer2,"past",1);
	Tense=-1;
      }
      if(Is_List_Element(Buffer,"present")){
	Buffer2=Ins_List_Element(Buffer2,"present",1);
	Tense=0;
      }
      if(Is_List_Element(Buffer,"future")){
	Buffer2=Ins_List_Element(Buffer2,"future",1);
	Tense=1;
      }
      if(ThinkOutLoud){
	printf("Input         : "); PrintList(WordList);
	printf("Detected      : "); puts(Get_DB_Entry(DB,1,Found));
	printf("Detected      : "); puts(Get_DB_Entry(DB,2,Found));
      }

      R=Buffer2;
    }
    else{
      DB=Goto_DB_Entry(Database[1],WordList->Str);
      Buffer2=Cpy_List(WordList);
      SimpleTense=Get_DB_Entry(DB,0,2);
      if(!strcmp(SimpleTense,"?")){
	if(ThinkOutLoud) 
	  puts("No tense      : Assuming present");
	SimpleTense="present";
      }      
      Buffer=SortList(Buffer2);
      A=0;
      B=0;
      Buffer2=NULL;
      while(Buffer){
	if(!IsArticle(Buffer->Str,"verb")){
	  Buffer2=Ins_List_Element(Buffer2,Buffer->Str,B++);
	}
	else{
	  if(!(Stash=List2Str(VerbBaseFinder(Str2List(Buffer->Str))))){
	    Stash=Buffer->Str;
	  }
	  Buffer2=Ins_List_Element(Buffer2,Stash,A++);
	  B++;
	}
	Buffer=Buffer->Next;
      }

      Buffer2=Ins_List_Element(Buffer2,SimpleTense,1);

      if(ThinkOutLoud){
	printf("Input         : "); PrintList(WordList);
	printf("Detected      : Simple "); puts(Get_DB_Entry(DB,0,2));
	printf("Detected      : "); PrintList(WordList);
      }
    }
    if(ThinkOutLoud){
      printf("Tense         : ");
      if(Tense==-1) puts("past");
      if(Tense==0)  puts("present");
      if(Tense==1)  puts("future");
      printf("Residual Verb : "); PrintList(Buffer2);
      printf("Saving Context: "); PrintList(Buffer2);
    }
    R=Buffer2;
  }
  else{
    if(ThinkOutLoud) puts("Warning: :MELDVF does not exist switching to low level linguistics. Things may be interpretted literally.");
    R=WordList;
  }
  R=DiscardAuxVerbs(R);  
  return R;
}

/*! \brief Determine if the sentence is a complex sentence or not.
 * 
 */
int ComplexSentence(struct Sentence *Sentence){
  int StartPos=0,EndPos=0,_=0,Conditional=0,VerbsFound=0,Size=0,IsQuestion=0,*Flags=NULL,Increase=0,NumberofNothings=0,CausePos=0,EffectPos=0;
   char *Question_Token=NULL,*ContextName=NULL;
   struct List_Str *Buffer=NULL,*Buffer2=NULL,*SubSentence=NULL,*FoundSentence=NULL,*Conditionals=NULL,*First=NULL,*Second=NULL,*Deref=NULL;
   if((Sentence->Language)&&(Sentence->Sentiency)){
     /* Update the topic */
     TouchTopic(Sentence);
     ContextName=Get_DB_Entry(Goto_DB_Entry(Database[1],":mode"),0,3);
     if(!strcmp(ContextName,"?"))
       ContextName="interntest";
     if(((CausePos=Find_List_Element(Sentence->Language->DS[1],":setcondcause"))+1)&&((EffectPos=Find_List_Element(Sentence->Language->DS[1],":setcondeffect"))+1)){
       Conditionals=Str2List(Get_DB_Entry(Sentence->Language,2,CausePos));
       Conditionals=Ins_List_List(Str2List(Get_DB_Entry(Sentence->Language,2,EffectPos)),Conditionals,0);
       for(Buffer=Sentence->Sentence;Buffer;Buffer=Buffer->Next){
	 /* Need to find out if there are conditionals */
	 if(Is_List_Element(Conditionals,Buffer->Str))
	   Conditional++;
	 /* are there more than one verbs ? */
	 if(IsArticle(Buffer->Str,"verb"))
	   VerbsFound++;
       }
     }
     else{
       if(ThinkOutLoud) puts("WARNING :setcond not found!");
       return 0;
     }
     /* First need to determine if the sentence is a question or a statement */
     if((_=Find_List_Element(Sentence->Language->DS[1],":question"))+1)
       Question_Token=Get_DB_Entry(Sentence->Language,2,_);
     else{
       if(ThinkOutLoud) puts("WARNING in ComplexSentence() :question not set!");
       return 0;
     }
     for(Buffer=Sentence->Sentence;Buffer;Buffer=Buffer->Next)
       if(!strcmp(Buffer->Str,Question_Token))
	 IsQuestion=1;
     if((VerbsFound>0)&&(Conditional)){
       for(Buffer=Sentence->Sentence;Buffer;Buffer=Buffer->Next)
	 if(!strcmp(Buffer->Str,Question_Token))
	   IsQuestion=1;
       /* need to go through and look for maximal subsentences */
       Flags=(int *)malloc((Size=Size_of_List(Sentence->Sentence))*sizeof(int));
       memset(Flags,0,Size*sizeof(int));
       if(IsQuestion){
	 Buffer=Sentence->Sentence;
	 for(StartPos=0;StartPos<Size;StartPos++){
	   FoundSentence=NULL;
	   for(EndPos=StartPos;EndPos<Size;EndPos++){
	     SubSentence=NULL;
	     Increase=0;
	     for(_=StartPos;_<EndPos+1;_++)
	       SubSentence=Ins_List_Element(SubSentence,Get_List_Element(Buffer,_),_-StartPos);
	     /*
	       Need to determine if each of these subsentence candidates is a subsentence
	       if it is save it to an array of linked lists.
	     */
	     if(!Is_List_Element(Conditionals,SubSentence->Str)){
	       if(Spirit(SubSentence,0)){
		 for(_=StartPos;_<EndPos+1;_++)
		   if(!Flags[_])
		     Increase=1;
		 if(Increase){
		   for(_=StartPos;_<EndPos+1;_++)
		     Flags[_]=1;
		   FoundSentence=SubSentence;
		 }
	       }
	     }
	   }
	   if(Is_List_Element(Conditionals,Get_List_Element(FoundSentence,_=Size_of_List(FoundSentence)-1)))
	     FoundSentence=Del_List_Element(FoundSentence,_);
	   if(FoundSentence){
	     if(First)
	       Second=CompoundSentence(FoundSentence);
	     else
	       First=CompoundSentence(FoundSentence);
	   }
	 }
	 /*
	   test needs to be specific to appropriate record
	   printf("DEBUG: ComplexSentence 1 [%s]\n",ContextName);
	 */
	 for(Buffer=AbstractComputeEffect(ContextName,First);Buffer;Buffer=Buffer->Next){
	   if(strcmp(Buffer->Str,":null"))
	     Deref=IntCSRecon(Buffer->Str);
	   else
	     Deref=Ins_List_Element(NULL,"nothing",0);
	   Deref=DiscardTense(Deref);
	   OutputAnswer("",Deref," "," ",".",0);
	 }
	 return 1;
       }
       else{
	 Buffer=Sentence->Sentence;
	 for(StartPos=0;StartPos<Size;StartPos++){
	   FoundSentence=NULL;
	   for(EndPos=StartPos;EndPos<Size;EndPos++){
	     SubSentence=NULL;
	     Increase=0;
	     for(_=StartPos;_<EndPos+1;_++)
	       SubSentence=Ins_List_Element(SubSentence,Get_List_Element(Buffer,_),_-StartPos);
	     /*
	       Need to determine if each of these subsentence candidates is a subsentence
	       if it is save it to an array of linked lists.
	     */
	     if(!Is_List_Element(Conditionals,SubSentence->Str)){
	       if(Spirit(SubSentence,0)){
		 for(_=StartPos;_<EndPos+1;_++)
		   if(!Flags[_])
		     Increase=1;
		 if(Increase){
		   for(_=StartPos;_<EndPos+1;_++)
		     Flags[_]=1;
		   FoundSentence=SubSentence;
		 }
	       }
	     }
	   }
	   if(FoundSentence){
	     if(First)
	       Second=CompoundSentence(FoundSentence);
	     else
	       First=CompoundSentence(FoundSentence);
	   }
	 }
	 /* needs sorting out */

	 /*	 printf("DEBUG: ComplexSentence 2 [%s]\n",ContextName); */

	 AbstractThinkingAssociates(ContextName,First,Second);
	 return 1;
       }
     }
     else{
       /* if we are here in the code this means that no verbs have been found. We need to determine if nothing has been defined. */
       if((_=Find_List_Element(Sentence->Language->DS[1],":setnull"))+1){
	 Buffer=Str2List(Get_DB_Entry(Sentence->Language,2,_));
	 for(Buffer2=Sentence->Sentence;Buffer2;Buffer2=Buffer2->Next)
	   if(Is_List_Element(Buffer,Buffer2->Str))
	     NumberofNothings++;
	 if((NumberofNothings==2)&&(!IsQuestion)){
	   /*
	     need to save data in a recognisable format.
	     printf("DEBUG: ComplexSentence 3 [%s]\n",ContextName);
	   */
	   Rep_DB_Pair(Goto_DB_Entry(Database[0],ContextName),":null",":null");
	 }
	 if((IsQuestion)&&(NumberofNothings==1)){
	   /*
	     neet to interrogate based on nothing.
	     printf("DEBUG: ComplexSentence 4 [%s]\n",ContextName);
	   */
	   for(Buffer=AbstractComputeEffect(ContextName,Ins_List_Element(NULL,":null",0));Buffer;Buffer=Buffer->Next){
	     if(strcmp(Buffer->Str,":null"))
	       Deref=IntCSRecon(Buffer->Str);
	     else
	       Deref=Ins_List_Element(NULL,"nothing",0);
	     Deref=DiscardTense(Deref);
	     OutputAnswer("",Deref," "," ",".",0);
	   }
	 }
       }
       else{
	 if(ThinkOutLoud) puts("ComplexSentence :SETNULL not defined.");
	 return 0;
       }
       return 0;
     }
   }
   else{
     if(ThinkOutLoud) puts("Language not set up properly!");
     return 0;
   }
   return 0;
}

/*! \brief Discard the tense of the verb.
 * 
 */
struct List_Str *DiscardTense(struct List_Str *VerbData){
  int C=0;
  struct List_Str *R=NULL,*Buffer=NULL;
  for(Buffer=VerbData;Buffer;Buffer=Buffer->Next)
    if((strcmp(Buffer->Str,"past"))&&(strcmp(Buffer->Str,"present"))&&(strcmp(Buffer->Str,"future")))
      R=Ins_List_Element(R,Buffer->Str,C++);
  return R;
}

/*! \brief Put the adverbs last in the verb clause and sort the adverbs.
 * 
 */
struct List_Str *PutAdverbsLast(struct List_Str *List){
  int C=0,_=0;
  struct List_Str *Buffer4=NULL,*Buffer3=NULL;
  for(Buffer3=List;Buffer3;Buffer3=Buffer3->Next){
    if(IsArticle(Buffer3->Str,"adverb"))
      Buffer4=Ins_List_Element(Buffer4,Buffer3->Str,C++);
    else{
      Buffer4=Ins_List_Element(Buffer4,Buffer3->Str,_++);
      C++;
    }
  }
  return Buffer4;
}

/*! \brief Group the clauses.
 * 
 */
struct List_Str  *GroupClauses(struct List_Str *Word_List){
  int _=0;
  struct List_Str *Buffer=NULL,*Return=NULL,*Data=NULL;
  for(Buffer=Word_List;Buffer;Buffer=Buffer->Next){
    if(IsArticle(Buffer->Str,"noun")){
      Data=Ins_List_Element(Data,Buffer->Str,_++); 
      Return=Add2Set(Return,List2Str(Data));
      Data=NULL;
      _=0;
    }
    else
      Data=Ins_List_Element(Data,Buffer->Str,_++);
  }
  if(Data)
    Return=Add2Set(Return,List2Str(Data));
  return Return;
}

/*! \brief Update the conversation topic with the latest conversation data.
 * 
 */
void TouchTopic(struct Sentence *Sentence){
  int Overlap=0;
  struct List_Str *NounList=NULL,*SubjList=NULL,*Buffer=NULL;
  struct Datablock *DB=NULL;
  /* need to get a list of nouns */
  NounList=ExtractArticles(Sentence->Sentence,"noun");
  /* need to group the clauses together */
  SubjList=GroupClauses(ExtractArticles(Sentence->Sentence,"noun adjective"));
  if(!(DB=Goto_DB_Entry(Database[1],":topic")))
    DB=Database[1]=Add_DB_Entry(Database[1],":topic");
  for(Buffer=DB->DS[1];Buffer;Buffer=Buffer->Next)
    if(IntIntersect(Str2List(Buffer->Str),NounList)){
      Overlap=1;
      break;
    }
  if(!Overlap){
    if(ThinkOutLoud)
      puts("Changing conversation topic...");
    (DB->DS[1])=(DB->DS[2])=NULL;
  }
  for(Buffer=SubjList;Buffer;Buffer=Buffer->Next)
    Add_DB_Pair(DB,Buffer->Str,"?");
}

/*! \brief Process yes / no questions.
 * 
 */
int YNQuest(struct List_Str *S,struct List_Str *PV,struct List_Str *PN){
  /* need to support Smedings conjoined nouns */
  int Flag=0;
  struct Datablock *VerbRec=GetCSRec(PV);
  struct List_Str *Buffer1=NULL,*Buffer2=NULL,*Buffer3=NULL,*Alpha=NULL,*Beta=NULL,*FilteredSubj=NULL,*FilteredPrd=NULL;
  FilteredSubj=CoreSubjMtr(S);
  FilteredPrd=CoreSubjMtr(PN);
  Buffer1=VerbRec->DS[1];
  Buffer2=VerbRec->DS[2];
  while(Buffer1&&Buffer2){
    Flag=1;
    Alpha=IntCSRecon(Buffer1->Str);
    Beta=IntCSRecon(Buffer2->Str);
    for(Buffer3=FilteredSubj;Buffer3;Buffer3=Buffer3->Next)
      if(!Is_List_Element(Beta,Buffer3->Str))
	Flag=0;
    for(Buffer3=FilteredPrd;Buffer3;Buffer3=Buffer3->Next)
      if(!Is_List_Element(Alpha,Buffer3->Str))
	Flag=0;
    if(Flag)
      return 1;
    Buffer1=Buffer1->Next; Buffer2=Buffer2->Next;
  }
  return 0;
}

/*! \brief Process compound sentences.
 * 
 */
struct List_Str *CompoundSentence(struct List_Str *Sentence){
   int C=0,_=1,Size=0,*PartitionPoints=NULL,Position=0,Start,Finish,ArraySize=0,ClausesWithVerb=0,VerbsInClause,*Wibble=NULL,GrammarEventId=0;
   struct List_Str *Buffer,**Data=NULL,*CleanSentence=NULL,*CSList=NULL;
   struct Sentence *SentenceData=NULL;
   /* Calls convertsentence */
   for(Buffer=Sentence;Buffer;Buffer=Buffer->Next)
     if(!strcmp(Buffer->Str,"and"))
       Size++;
   Size+=2;
   PartitionPoints=(int *)malloc((Size+1)*sizeof(int));
   memset(PartitionPoints,0,Size);
   PartitionPoints[0]=0;
   for(Buffer=Sentence;Buffer;Buffer=Buffer->Next){
      if(!strcmp(Buffer->Str,"and"))
	PartitionPoints[_++]=Position;
      Position++;
   }
   PartitionPoints[_++]=Position;
   Start=PartitionPoints[0];
   for(Position=1;Position<Size;Position++){
      Finish=PartitionPoints[Position];
      Buffer=NULL;
      C=0;
      for(_=Start;_<Finish;_++)
	 Buffer=Ins_List_Element(Buffer,Get_List_Element(Sentence,_),C++);
      if(!strcmp(Buffer->Str,"and"))
	 Buffer=Buffer->Next;
      Data=Add_To_Array(Data,Buffer,ArraySize++);
      Start=Finish;
   }
   Wibble=(int *)malloc(ArraySize*sizeof(int *));
   memset(Wibble,0,ArraySize);
   for(Position=0;Position<ArraySize;Position++){
      VerbsInClause=0;
      for(Buffer=Data[Position];Buffer;Buffer=Buffer->Next)
	VerbsInClause+=IsArticle(Buffer->Str,"verb");
      if(VerbsInClause){
	 Wibble[Position]=1;
	 ClausesWithVerb++;
      }
   }
   if((ArraySize-ClausesWithVerb)&&(ClausesWithVerb>1)){
      puts("This sentence is ambiguous.");
      return NULL;
   }
   else{
     /* if not a compound sentence */
      if(ArraySize-ClausesWithVerb){
	/*
	  we need to do some more magic to break up the sentence with conjoined subject material into separate sentences
	  if its got a verb in it this section is a sentence
	 */
	 for(Position=0;Position<ArraySize;Position++){
	    if(!Position)
	      CleanSentence=Data[Position];
	    else
	      CleanSentence=Ins_List_List(CleanSentence,Ins_List_Element(Data[Position],"and",0),Size_of_List(CleanSentence));
	 }
	 
	 SentenceData=ConvertSentence(CleanSentence,1,1);
	 GrammarEventId=SentenceData->InterceptedSpirit;
	 if(GrammarEventId==3){
	   /* need to separate the sentence into an array of subjects and an array of predicates */
	    CSList=ParallelSimples(SentenceData->Subject,SentenceData->PredicateVerbBlock,SentenceData->PredicateNounBlock);
	 }
      }
      else{
	 _=0;
	 for(Position=0;Position<ArraySize;Position++){
	    CSList=Ins_List_Element(CSList,IndicativeComponent(Data[Position]),_++);
	 }
      }
   }
   return CSList;
}

/*! \brief Process indicative sentences.
 * 
 */
char *IndicativeComponent(struct List_Str *Sentence){
  int GrammarEventId=0;
  struct List_Str *Reconstructed=NULL;
  struct Datablock *DB=NULL;
  struct Sentence *SentenceData=NULL;
  SentenceData=ConvertSentence(Sentence,1,1);
  GrammarEventId=SentenceData->InterceptedSpirit;
  if(GrammarEventId==3){
    Reconstructed=SentenceData->S;
    Reconstructed=Ins_List_List(Reconstructed,SentenceData->PV,Size_of_List(Reconstructed));
    Reconstructed=Ins_List_List(Reconstructed,SentenceData->PN,Size_of_List(Reconstructed));
    if(!(DB=GetCSRec(Reconstructed))){
      CSCreate(Reconstructed);
      DB=GetCSRec(Reconstructed);
    }
  }
  if(!DB){
    return NULL;
  }
  return DB->DS[0]->Str;
}

/*! \brief Reduce to canonical form.
 * 
 */
struct List_Str *Canonical(struct List_Str *L,int Translate,int BR){
  int _=0,L1=0,L2=0,Position=0;
  struct List_Str *R=NULL,*Created=NULL,*B2=NULL,*Final=L;
  R=L;
  while(L){
    L1=Awareness1(L,BR);
    if(L1>1){
      if(!Translate){
	for(R=L;R;R=R->Next,_++){}
	if(L1==_)
	  return L;
      }
      R=L;
      Created=NULL;
      for(_=0;_<Position;_++){
	Created=Ins_List_Element(Created,R->Str,_); 
	R=R->Next;
      }
      B2=Created;
      if(!Created){
	B2=Created=ANSWER;
      }
      else{
	while(Created->Next)
	  Created=Created->Next;
	Created->Next=ANSWER;
      }
      while(Created->Next)
	Created=Created->Next;
      for(_=0;_<L1;_++)
	R=R->Next;
      Created->Next=R;
      Position=0;
      Final=L=B2;
    }
    else{
      if((L2=Awareness2(L->Str,BR))){
	R=Final; 
	Created=NULL;
	for(_=0;_<Position;_++){
	  Created=Ins_List_Element(Created,R->Str,_); 
	  R=R->Next;
	}
	B2=Created;
	if(Created){
	  while(Created->Next)
	    Created=Created->Next;
	  Created->Next=ANSWER;
	}
	else
	  B2=Created=ANSWER;
	while(Created->Next)
	  Created=Created->Next;
	R=R->Next; 
	Created->Next=R;
	Position=0; 
	Final=L=B2;
      }
      else{
	R=L; 
	L=L->Next; 
	Position++;
      }
    }
  }
  return Final;
}

/*! \brief List the important verbs of the verb clause.
 * 
 */
struct List_Str *ListReleventVerbs(struct List_Str *Verb){
  int _=0,CSNum=0,Flag=0,Position=0;
  char *Data=NULL;
  struct List_Str *R=NULL,*Buffer=NULL,*Deref=NULL;
  struct Datablock *Gamma=NULL;
  if(strcmp(Data=Get_DB_Entry(Goto_DB_Entry(Database[1],":mode"),0,7),"?")){
    CSNum=atoi(Data+2);
    Data=(char *)malloc(100*sizeof(char));
    for(_=1;_<CSNum;_++){
      sprintf(Data,"cs%d",_);
      Gamma=Goto_DB_Entry(Database[1],Data);
      if(Gamma->DS[1]){
	Deref=IntCSRecon(Data);
	Flag=1;
	for(Buffer=Verb;Buffer;Buffer=Buffer->Next)
	  if(!Is_List_Element(Deref,Buffer->Str))
	    Flag=0;
	if(Flag)
	  R=Ins_List_Element(R,List2Str(Deref),Position++);
      }
    }
  }
  else
    if(ThinkOutLoud)
      puts("WARNING: Verb context search failure.");
  return R;
}

/*! \brief Separate the sentence into subject, predicate nouns and predicate verbs.
 * 
 */
int SeparateSentence(struct Sentence *Sentence){
  int NumofGraphs=0,_=0,C=0,Position=0,SPOS=0,PNPOS=0,PVPOS=0,PRPOS=0,Template=-1;
  int AfterVerb=0,Match=0;
  char *Old=NULL,*New=NULL;
  struct Datablock *DB=NULL,*Language=NULL;
  struct List_Str *Quals=NULL,*Values=NULL,**Graphs=NULL,*SentenceTopology=NULL,*Buffer=NULL,*B2=NULL,*VUnits=NULL,*VerbPart=NULL;
  struct List_Str *SentenceTemplate=NULL,*TemplateL=NULL,*SL=NULL;
  if(Sentence->Mood)
    DB=Goto_DB_Entry(Database[1],Sentence->Mood);
  else{
    if(ThinkOutLoud)
      puts("Error: No sentence mood detected, aborting SeparateSentence!");
    DB=0;
  }
  if(DB){
    for(Quals=DB->DS[1];Quals;Quals=Quals->Next)
      if(!strcmp(Quals->Str,":TEMPLATE"))
	NumofGraphs++;
    Graphs=(struct List_Str **)malloc(NumofGraphs*sizeof(struct List_Str *));
    Values=DB->DS[2];
    _=0;
    for(Quals=DB->DS[1];Quals;Quals=Quals->Next){
      if(!strcmp(Quals->Str,":TEMPLATE"))
	Graphs[_++]=Str2List(Values->Str);
      Values=Values->Next;
    }
    Language=GetLang();
    VUnits=Str2List(Get_List_Element(Language->DS[2],Find_List_Element(Language->DS[1],":predverbs")));
    C=0;
    B2=Sentence->Sentence;
    for(Buffer=Disambiguated;Buffer;Buffer=Buffer->Next){
      /* 
	 If they are verbs then save as pv. If they are not, save as u.
	 If they are VUnits but not verbs then save them as verbs if they
	 are after actual verbs.
       */
      if((Is_List_Element(VUnits,Buffer->Str))){
	if((!strcmp(Buffer->Str,"verb"))||(!strcmp(Buffer->Str,"adverb"))){
	  AfterVerb=1;
	  VerbPart=Ins_List_Element(VerbPart,B2->Str,0);
	  SentenceTopology=Ins_List_Element(SentenceTopology,"pv",C);
	}
	else{
	  if(AfterVerb){
	    VerbPart=Ins_List_Element(VerbPart,B2->Str,0);
	    SentenceTopology=Ins_List_Element(SentenceTopology,"pv",C);
	  }
	  else
	    SentenceTopology=Ins_List_Element(SentenceTopology,"u",C);
	}
      }
      else{
	if(Is_List_Element(VUnits,Buffer->Str))
	  SentenceTopology=Ins_List_Element(SentenceTopology,Buffer->Str,C);
	else{
	  SentenceTopology=Ins_List_Element(SentenceTopology,"u",C);
	  AfterVerb=0;
	}
      }
      C++;
      B2=B2->Next;
    }

    /* This section finds out the template */
    for(_=0;_<NumofGraphs;_++){
      TemplateL=Graphs[_];
      Old="";
      Match=1;
      SentenceTemplate=NULL;
      C=0;
      New=NULL;
      for(SL=SentenceTopology;SL;SL=SL->Next){
	/* if the sentencetopology has changed */
	if(strcmp(Old,SL->Str)){
	  /* check if the sentencetopology matches the graph */
	  if(!TemplateL){
	    Match=0;
	    break;
	  }
	  if(strcmp(TemplateL->Str,"pv")){
	    if(strcmp(SL->Str,"u")){
	      Match=0;
	      break;
	    }
	  }
	  else{
	    if(strcmp(SL->Str,"pv")){
	      Match=0;
	      break;
	    }
	  }
	  /* increment the template */
	  New=TemplateL->Str;
	  TemplateL=TemplateL->Next;
	}
	SentenceTemplate=Ins_List_Element(SentenceTemplate,New,C++);
	Old=SL->Str;
      }
      if(Match){
	Template=_;
	break;
      }
    }
    Sentence->PredicateVerbBlock=NULL;
    Sentence->PredicateNounBlock=NULL;
    Sentence->Subject=NULL;
    Sentence->Predicate=NULL;
    Sentence->SentenceStructure=NULL;
    if(Template==-1){
      if(ThinkOutLoud) puts("Unidentified sentence structure!");
      Sentence->Understood=0;
      Sentence->SentenceStructure=SentenceTopology;
      return 0;
    }

    /* need to convert u pv u into s pv pn */
    Sentence->SentenceStructure=Graphs[Template];
    for(Buffer=SentenceTemplate,B2=Sentence->Sentence;Buffer&&B2;Buffer=Buffer->Next,B2=B2->Next){
      if(Buffer->Str[0]=='p'){
	Sentence->Predicate=Ins_List_Element(Sentence->Predicate,B2->Str,PRPOS++);
	if(!strcmp(Buffer->Str,"pn"))
	  Sentence->PredicateNounBlock=Ins_List_Element(Sentence->PredicateNounBlock,B2->Str,PNPOS++);
	if(!strcmp(Buffer->Str,"pv"))
	  Sentence->PredicateVerbBlock=Ins_List_Element(Sentence->PredicateVerbBlock,B2->Str,PVPOS++);
      }
      else
	Sentence->Subject=Ins_List_Element(Sentence->Subject,B2->Str,SPOS++);	
    }
  }
  else{
    if(ThinkOutLoud) printf("ERROR: sentence mood %s, does not exist.\n",Sentence->Mood);
  }
  if(Sentence->PassiveVoice){
    /* we need to do better here!!!  */
    if(ThinkOutLoud) puts("Passive sentence detected, swapping S and PN...");
    Buffer=Sentence->PredicateNounBlock;
    Sentence->PredicateNounBlock=Sentence->Subject;
    Sentence->Subject=NULL;
    _=0;
    C=0;
    while(Buffer){
      if(!IsArticle(Buffer->Str,"preposition"))
	Sentence->Subject=Ins_List_Element(Sentence->Subject,Buffer->Str,_++);
      else{
	/* need to check that it isnt a passive agent */
	if(!IsGrammarAttribute(":spa",Buffer->Str))
	  Sentence->PredicateNounBlock=Ins_List_Element(Sentence->PredicateNounBlock,Buffer->Str,C++);
      }
      Buffer=Buffer->Next;
    }
  }
  
   /* at this point the predicate verbs incorrectly contain prepositions */

  B2=NULL;
  _=0;
  C=0;
  Position=0;
  
  Sentence->BasicSubject=Cpy_List(Sentence->Subject);
  Sentence->BasicPredicate=Cpy_List(Sentence->PredicateNounBlock);
  
  for(Buffer=Sentence->PredicateVerbBlock;Buffer;Buffer=Buffer->Next){
    if(IsArticle(Buffer->Str,"preposition")){
      if(Sentence->PredicateNounBlock){
	Sentence->PredicateNounBlock=Ins_List_Element(Sentence->PredicateNounBlock,Buffer->Str,_++);
      }
      else{
	Sentence->Subject=Ins_List_Element(Sentence->Subject,Buffer->Str,_++);
      }
      Sentence->PassiveVerbPrepositions=Ins_List_Element(Sentence->PassiveVerbPrepositions,Buffer->Str,Position++);
    }
    else{
      B2=Ins_List_Element(B2,Buffer->Str,C++);
    }
  }
  Sentence->PredicateVerbBlock=B2;
  SubstitutePronouns(Sentence->Subject,Sentence->PredicateNounBlock);
  return 0;
}

/*! \brief Substitute the pronouns in the sentence.
 * 
 */
void SubstitutePronouns(struct List_Str *Subjects,struct List_Str *Predicates){
  int Previous=0,Current=0,_=0,A=0,Object=0,CumulativeObject=0,Personal=0,ContainsPronouns=0,ChangeofTopic=1;
  char *Name=NULL,*SNPronouns=NULL,*Gender=NULL;
  struct List_Str *SN=NULL,*PN=NULL,*Buffer=NULL,*Total=NULL,*ContextAddr=NULL;
  struct Datablock *DB=NULL,*MODE=GetLang(),*Emotions=NULL;
  if(MODE&&(Subjects||Predicates)){
    for(Buffer=Subjects;Buffer;Buffer=Buffer->Next){
      Object=0;
      if(IsArticle(Buffer->Str,FILTERNOUNSONLY))
	Object=CumulativeObject=1;
      if(IsArticle(Buffer->Str,"pronoun"))
	ContainsPronouns=1;
      if(Object||(IsArticle(Buffer->Str,"adjective"))){
	Current=1;
	Total=Ins_List_Element(Total,Buffer->Str,_++);
      }
      else{
	if(Previous&&CumulativeObject){
	  SN=Ins_List_Element(SN,List2Str(Total),A++);
	  _=0;
	  Total=NULL;
	  CumulativeObject=0;
	}
	Current=0;
      }
      Previous=(Current||Object);
    }
    if(Previous&&Object)
      SN=Ins_List_Element(SN,List2Str(Total),A++);
    A=_=Object=Current=Previous=CumulativeObject=0;
    Total=NULL;
    for(Buffer=Predicates;Buffer;Buffer=Buffer->Next){
      Object=0;
      if(IsArticle(Buffer->Str,FILTERNOUNSONLY))
	Object=CumulativeObject=1;
      if(IsArticle(Buffer->Str,"pronoun"))
	ContainsPronouns=1;
      if(Object||(IsArticle(Buffer->Str,"adjective"))){
	Current=1;
	Total=Ins_List_Element(Total,Buffer->Str,_++);
      }
      else{
	if(Previous&&CumulativeObject){
	  PN=Ins_List_Element(PN,List2Str(Total),A++);
	  _=0;
	  Total=NULL;
	  CumulativeObject=0;
	}
	Current=0;
      }
      Previous=(Current||Object);
    }
    if(Previous&&Object)
      PN=Ins_List_Element(PN,List2Str(Total),A++);
    if((_=Find_List_Element((DB=Goto_DB_Entry(Database[1],":mode"))->DS[1],":personality"))+1)
      Name=Get_DB_Entry(DB,2,_);
    if(Size_of_List(SN)-1){
      for(Buffer=SN;Buffer;Buffer=Buffer->Next)
	if((!strcmp(Buffer->Str,Name))||(!strcmp(Buffer->Str,"i")||(!strcmp(Buffer->Str,"me"))))
	  Personal=1;
      if(Personal)
	SNPronouns="we us";
      else
	SNPronouns="they them";
    }
    else{
      if(IsArticle(SN->Str,"pronoun"))
	SNPronouns=NULL;
      else{
	SNPronouns=NULL;
      }
      Gender=Get_DB_Entry(Goto_DB_Entry(Database[1],SN->Str),0,2);
      if(Gender){
	if(!strcmp(Gender,"male")){
	  SNPronouns="he him";
	}
	else{
	  if(!strcmp(Gender,"female"))
	    SNPronouns="she her";
	  else
	    SNPronouns="it";
	}
      }
      else{
	SNPronouns="it";
      }
      if(Name){
	if(!strcmp(Name,SN->Str))
	  SNPronouns="i me";
      }
      SNPronouns="";
    }
    if(SNPronouns){
      for(Buffer=Str2List(SNPronouns);Buffer;Buffer=Buffer->Next){
	if(!(DB=Goto_DB_Entry(Database[1],Buffer->Str)))
	  DB=Database[1]=Add_DB_Entry(Database[1],Buffer->Str);
	if(Subjects)
	  Rep_DB_Entry(DB,0,7,List2Str(Subjects));
	else
	  Rep_DB_Entry(DB,0,7,StrCat("","?"));
      }
    }
    if(!(DB=Goto_DB_Entry(Database[1],"conversationtopic")))
      DB=Database[1]=Add_DB_Entry(Database[1],"conversationtopic");
    if(!ContainsPronouns){
      for(Buffer=SN;Buffer;Buffer=Buffer->Next)
	if(Is_List_Element(DB->DS[1],List2Str(SortList(Str2List(Buffer->Str)))))
	  ChangeofTopic=0;
      for(Buffer=PN;Buffer;Buffer=Buffer->Next)
	if(Is_List_Element(DB->DS[1],List2Str(SortList(Str2List(Buffer->Str)))))
	  ChangeofTopic=0;
      if(ChangeofTopic){
	if(ThinkOutLoud) puts("Change of topic detected.");

	if(!(Emotions=Goto_DB_Entry(Database[1],"emotionrecord")))
	  Emotions=Database[1]=Add_DB_Entry(Database[1],"emotionrecord");

	/* reset emotions */
	Emotions->DS[1]=Emotions->DS[2]=NULL;
	DB->DS[1]=DB->DS[2]=NULL;
      }
    }

    for(Buffer=SN;Buffer;Buffer=Buffer->Next){
      Rep_DB_Pair(DB,List2Str(RefineNouns(Str2List(Buffer->Str),0)),"?");
    }
    for(Buffer=PN;Buffer;Buffer=Buffer->Next){
      Rep_DB_Pair(DB,List2Str(RefineNouns(Str2List(Buffer->Str),0)),"?");
    }

    /*
      need to set conversation topic here
      we need to write the topic to :ccontext attribute in the :mode record
      for optimisation it makes sense to prepend the context addressible memory in reverse order
    */

    for(Buffer=DB->DS[1];Buffer;Buffer=Buffer->Next){
      ContextAddr=Ins_List_List(ContextAddr,Str2List(Buffer->Str),0);
    }
    Rep_DB_Entry(Goto_DB_Entry(Database[1],":mode"),0,3,CSCreate(ContextAddr));
  }
  else if(!MODE) puts("Language not setup properly.");
}

/*! \brief Breaks up Smeding's conjoined noun problem.
 * 
 */
struct List_Str  *ParallelSimples(struct List_Str *SN,struct List_Str *PV,struct List_Str *PN){
   int _=0,A=0,B=0,NumberSubjects=0,NumberPredicates=0;
   struct List_Str *Buffer=NULL,*Buffer2=NULL,*CSList=NULL,**SNS=NULL,**PNS=NULL;
   for(Buffer=SN;Buffer;Buffer=Buffer->Next){
      if(!strcmp(Buffer->Str,"and")){
	 SNS=Add_To_Array(SNS,Buffer2,NumberSubjects++);
	 Buffer2=NULL;
	 _=0;
      }
      else
	 Buffer2=Ins_List_Element(Buffer2,Buffer->Str,_++);
   }
   SNS=Add_To_Array(SNS,Buffer2,NumberSubjects++);
   Buffer2=NULL;
   _=0;
   for(Buffer=PN;Buffer;Buffer=Buffer->Next){
      if(!strcmp(Buffer->Str,"and")){
	 PNS=Add_To_Array(PNS,Buffer2,NumberPredicates++);
	 Buffer2=NULL;
	 _=0;
      }
      else
	 Buffer2=Ins_List_Element(Buffer2,Buffer->Str,_++);
   }
   PNS=Add_To_Array(PNS,Buffer2,NumberPredicates++);
   _=0;
   for(A=0;A<NumberSubjects;A++)
      for(B=0;B<NumberPredicates;B++)
	 CSList=Ins_List_Element(CSList,IndicativeComponent(Str2List(List2Str(Ins_List_Element(Ins_List_Element(Ins_List_Element(NULL,List2Str(SNS[A]),0),List2Str(PV),1),List2Str(PNS[B]),2)))),_++);
   return CSList;
}

/*! \brief Format a sentence so it can be output.
 * 
 */
struct List_Str *OutputAnswer(char *Pre,struct List_Str *L,char *Space,char *Final,char *End,int ThoughtsOnly){
   int _=0;
   char *Data=NULL,*D1=NULL,*Emo=NULL,*Output=NULL,*Smilies=NULL;
   struct List_Str *Buffer=NULL,*Expressions=NULL;
   struct Datablock *DB=NULL,*Lang=GetLang();
   struct Feeling *F=NULL;
   struct Sentence *SData=NULL;

   if(!DetectVerbosity())
     ThoughtsOnly=1;

   if(!End)
     End=".\n";
   if(L){
     if((_=Find_List_Element(Lang->DS[1],":assignemo"))+1)
       if(strcmp(Smilies=Get_DB_Entry(Lang,2,_),"?"))
	 Expressions=Str2List(Smilies);
     if(Pre&&(strlen(Pre)>0))
       Output=StrCat(Pre,"");
     else
       Output="";
     for(Buffer=L;Buffer;Buffer=Buffer->Next){
       Output=StrCat(Output,Buffer->Str);
       if(Buffer->Next){
	 if(Buffer->Next->Next)
	   Output=StrCat(Output,Final);
	 else
	   Output=StrCat(Output,Space);
       }
     }
     L=Str2List(Output);
     if(End)
       Output=StrCat(Output,End);
     Data=Output;
     Add2Conversation(1,L);
     Data[0]=toupper(Data[0]);
     for(_=0;Data[_];_++)
       if((Data[_]==',')||(Data[_]==';')||(Data[_]==':'))
	 if(_)
	   if(Data[_-1]==' ')
	     memmove(Data+(_-1),Data+_,strlen(Data+_)+1);
     if(GlobalF){
       F=GlobalF;
       GlobalF=NULL;
     }
     else{
       F=Detect_Dominant_Emo(L);
       if(!F){
	 if(ThinkOutLoud) puts(":ADDEMO not set up. Mitigating...");
	 if(!Suppress_ANSWER){
	   Add2ConvBuffer("ENiX",Data);
	   printf("%s\n",Data);
	 }
	 return L;
       }
     }
     if(LEGACYEMOTION)
       Associate_Emo(L,F);
     if(!F->DominantName)
       F->DominantName="";
     if((DB=Goto_DB_Entry(Database[1],F->DominantName))){
       if(strcmp(Emo=Get_DB_Entry(DB,0,7),"?")){
	 Execute(NULL,Str2List(Emo));
       }
     }
     ANSWER=Str2List(Data);
     D1=Get_List_Element(Expressions,F->DominantEmo);
     if(!D1)
       D1="";
     if(!Suppress_ANSWER){
       if(ThoughtsOnly)
	 Add2ConvBuffer("Thoughts",Data);
       else
	 Add2ConvBuffer("ENiX",Data);
       /* Need to determine if the Sentence is a question, if it is save to Add2QBuffer */
       Database[1]=Recognise(Database[1],L);
       SData=ConvertSentence(L,0,0);
       if(SData->Mood)
	 if((!strcmp(SData->Mood,"whq"))||(!strcmp(SData->Mood,"ynq"))){
	   if(ThoughtsOnly)
	     Add2QBuffer("Thoughts",Data);
	   else
	     Add2QBuffer("ENiX",Data);
	 }
       if(!ThoughtsOnly)
	 printf("%s%s\n",Data,D1);
     }
   }
   return L;
}

/*! \brief Add sentence to a conversation buffer.
 * 
 */
struct Datablock *Add2Conversation(int Type,struct List_Str *L){
  struct Datablock *R=Goto_DB_Entry(Database[1],"CONVBUFFER");
  if(!R){
    R=Add_DB_Entry(Database[1],"CONVBUFFER");
    CSCreate(L);
    CSAddr(L,NULL);
    if(Type)
      Rep_DB_Pair(R,ANSWER->Str,"C");
    else
      Rep_DB_Pair(R,ANSWER->Str,"P");
  }
  return R;
}

/*! \brief Determine if the negations cancel each other out.
 * 
 */
int SameNegation(struct List_Str *A,struct List_Str *B){
   int Type=0;
   struct List_Str *Alpha=NULL;
   for(Alpha=A;Alpha;Alpha=Alpha->Next)
     if(!strcmp(Alpha->Str,"not"))
       Type++;
   for(Alpha=B;Alpha;Alpha=Alpha->Next)
     if(!strcmp(Alpha->Str,"not"))
       Type--;
   return (!Type);
}

/*! \brief Get the semantic noun data from the sentence.
 * 
 */
struct List_Str *Get_Sem_CSNouns(struct List_Str *Sentence){
   struct List_Str *Buffer=Sentence;
   struct Sentence *S=NULL;
   ParseSentenceEmotion(Buffer);
   S=ConvertSentence(Sentence,1,1);
   return Ins_List_Element(Ins_List_Element(Ins_List_Element(NULL,List2Str(Canonical(S->PredicateNounBlock,1,1)),0),List2Str(Canonical(VerbBaseFinder(S->PredicateVerbBlock),1,1)),0),List2Str(Canonical(S->Subject,0,1)),0);
}

/*! \brief Create a list of context addressible memory locations associated with verbs.
 *  - By doing this we create a list of CS addresses that represent subjects and predicate noun clauses.
 */
struct List_Str *GenerateCSNouns(struct List_Str *Inp){
  char *RecordName=NULL;
  struct List_Str *R=NULL,*CSVerbs=NULL,*Buffer1=NULL,*Buffer2=NULL;
  struct Datablock *DB=NULL;
  for(CSVerbs=Inp;CSVerbs;CSVerbs=CSVerbs->Next){
    RecordName=StrCat("_examples_",CSVerbs->Str);
    DB=Goto_DB_Entry(Database[0],RecordName);
    free(RecordName);
    if(DB){
      for(Buffer1=DB->DS[1];Buffer1;Buffer1=Buffer1->Next)
	for(Buffer2=Str2List(Buffer1->Str);Buffer2;Buffer2=Buffer2->Next)
	  R=Add2Set(R,Buffer2->Str);
      for(Buffer1=DB->DS[2];Buffer1;Buffer1=Buffer1->Next)
	R=Add2Set(R,Buffer1->Str);
    }
  }
  return R;
}

/*! \brief Create a list of context addressible verbs.
 *  
 */
struct List_Str *GenerateCSVerbs(){
  struct List_Str *R=NULL;
  struct Datablock *DB=NULL;
  for(DB=Database[0];DB;DB=DB->Next)
    if(!strncmp(DB->DS[0]->Str,"_examples_",10))
      R=Add2Set(R,DB->DS[0]->Str+10);
  return R;
}

/*! \brief Do a fuzzy search through the context to determine if the context overlaps.
 *  
 */
struct List_Str *SharedContext(char *Str,struct List_Str *CSVerbs,struct List_Str *CSNouns){
   int _=0,Found=0;
   char *NounList=NULL;
   struct List_Str *R=NULL,*Buffer=NULL,*Buffer2=NULL,*FoundNouns=NULL,*Deref=NULL;
   struct Datablock *Lang=GetLang();
   if(Lang)
     if((_=Find_List_Element(Lang->DS[1],":nouns"))+1){
	NounList=Get_List_Element(Lang->DS[2],_);
	_=0;
	for(Buffer=IntCSRecon(Str);Buffer;Buffer=Buffer->Next)
	  if(IsArticle(Buffer->Str,NounList))
	    FoundNouns=Ins_List_Element(FoundNouns,Buffer->Str,_++);
	_=0;
	for(Buffer2=CSNouns;Buffer2;Buffer2=Buffer2->Next){
	  Deref=IntCSRecon(Buffer2->Str);
	   Found=1;
	   for(Buffer=FoundNouns;Buffer;Buffer=Buffer->Next)
	     if(!Is_List_Element(Deref,Buffer->Str))
	       Found=0;
	   if(Found)
	     R=Ins_List_Element(R,Buffer2->Str,0);
	}
     }
   return R;
}

/*! \brief Check if any of the commands are ENiX commands.
 *  - This has nothing to do with ENiX awareness. Commands are preceded by colons.
 */
int Awareness1(struct List_Str *L,int BR){
  int C=0,Length=0,Found=0,BI=0;
  struct List_Str *Alpha=Cpy_List(L),*Beta=NULL,*Buffer=NULL;
  Length=Size_of_List(Alpha);
  while(Length){
    Beta=Alpha;
    for(C=1;C<Length;C++){
      Alpha=Alpha->Next;
    }
    Alpha->Next=NULL;
    CSLoad(Beta,NULL);
    if(ANSWER){
      if(strcmp(ANSWER->Str,"?")){
	BI=0;
	for(Buffer=ANSWER;Buffer;Buffer=Buffer->Next)
	  if((!strncmp(Buffer->Str,":",1))&&BR){
	    BI=1;
	    break;
	  }
	if(BI){
	  Alpha=Beta;
	  Length--;
	}
	else{
	  Found=Length;
	  Length=0;
	}
      }
      else{
	Alpha=Beta;
	Length--;
      }
    }
    else{
      Alpha=Beta;
      Length--;
    }
  }
  return Found;
}

/*! \brief Check if any of the commands are ENiX commands.
 *  - This has nothing to do with ENiX awareness. Commands are preceded by colons.
 */
int Awareness2(char *L,int BR){
  char *B=NULL;
  struct List_Str *Buffer=NULL;
  ANSWER=NULL;
  if(Paradox(L,NULL,0)){
    ANSWER=Ins_List_Element(NULL,L,0); 
    return 0;
  }
  if(L[0]==':')
    return 0;
  Buffer=ANSWER=Str2List(B=Get_DB_Entry(Goto_DB_Entry(Database[1],L),0,7));
  while(Buffer){
    if((!strncmp(Buffer->Str,":",1))&&BR)
      return 0;
    Buffer=Buffer->Next;
  }
  if(strcmp(B,"?"))
    return 1;
  else
    return 0;
}

/*! \brief Create a list of pseudo random numbers.
 *
 */
struct List_Str *Random(struct List_Str *Word_List,struct List_Str *L){
   int Seed=0,Pos=0,_=0,Max=atoi(Word_List->Str),Limit=atoi(L->Str);
   struct Datablock *DB=GetLang();
   if(DB){
      if((Pos=Find_List_Element(DB->DS[1],":randseed"))+1)
	Seed=atoi(Get_DB_Entry(DB,2,Pos));
      else Seed=14451;
      srand(Seed);
      ANSWER=NULL;
      for(Pos=0;Pos<Max;Pos++)
	ANSWER=Ins_List_Element(ANSWER,FloatToString((Seed=rand())%Limit),_++);
      Rep_DB_Pair(DB,":randseed",FloatToString(Seed));
   }
   else
     puts("Language not setup!");
   return L->Next;
}

/*! \brief Detect the voice of the sentence.
 *
 */
int Detect_Voice(struct List_Str *L){
  int QuestionP=0,YNP=0,WHP=0,SUP=0,SO=0,ISCOMMA=0,ISNOUN=0;
  char *Lang=NULL,*Q=NULL,*First=NULL,*Last=NULL;
  struct List_Str *YN=NULL,*WH=NULL,*Buffer=NULL;
  struct Datablock *DB=Database[1];
  if(!(DB=Goto_DB_Entry(Database[1],":mode")))
    return 0;
  else{
    Lang=Get_DB_Entry(DB,0,1);
    if(!(DB=Goto_DB_Entry(Database[1],Lang)))
      return 0;
    else{
      SO=Find_List_Element(DB->DS[1],":sentiency");
      if(SO<0)
	return 0;
      else
	if(!strcmp(Get_List_Element(DB->DS[2],SO),"off"))
	  return 0;
      QuestionP=Find_List_Element(DB->DS[1],":question");
      YNP=Find_List_Element(DB->DS[1],":yn");
      WHP=Find_List_Element(DB->DS[1],":wh");
      SUP=Find_List_Element(DB->DS[1],":sentenceunit");
      if(((QuestionP<0)||(YNP<0))||((WHP<0)||(SUP<0)))
	return 0;
      else{
	Q=Get_List_Element(DB->DS[2],QuestionP);
	YN=Str2List(Get_List_Element(DB->DS[2],YNP));
	WH=Str2List(Get_List_Element(DB->DS[2],WHP));
	Buffer=L;
	First=Buffer->Str;
	while(Buffer){
	  Last=Buffer->Str;
	  Buffer=Buffer->Next;
	}
	if(!strcmp(Last,Q)){
	  while(YN){
	    if(IsArticle(First,YN->Str))
	      return 3;
	    YN=YN->Next;
	  }
	  while(WH){
	    if(!strcmp(First,WH->Str))
	      return 4;
	    WH=WH->Next;
	  }
	  return 2;
	}
	for(Buffer=L;Buffer;Buffer=Buffer->Next){
	  if(!strcmp(Buffer->Str,","))
	    ISCOMMA=1;
	  if(IsArticle(Buffer->Str,"noun propernoun"))
	    ISNOUN=1;
	  if(IsArticle(Buffer->Str,"verb")){
	    if((ISCOMMA)||(!ISNOUN))
	      return 0;
	    else
	      return 1;
	    break;
	  }
	}
      }
    }
  }
  return 0;
}

/*! \brief Determine the tense of the sentence.
 *
 */
struct List_Str  *SentenceTense(struct List_Str *Word_List,struct List_Str *L){
  struct Sentence *Sentence=ConvertSentence(Word_List,0,1);
  ANSWER=Str2List(Get_List_Element(Sentence->CSVerbRef,1));
  return L;
}

/*! \brief Create a sentence.
 *
 */
struct List_Str *AssembleSentence(struct List_Str *Subject,struct List_Str *PredicateVerb,struct List_Str *Qualifiers,struct List_Str *Nouns){
  int C=0,Toggle=0;
  struct List_Str *R=NULL,*Buffer=NULL,*Buffer2=NULL;
  for(Buffer=Subject;Buffer;Buffer=Buffer->Next){
    if(IsArticle(Buffer->Str,"noun adjective")&&(!Toggle)){
      R=Ins_List_Element(R,"a",C++);
      Toggle=1;
    }
    else
      Toggle=0;
    R=Ins_List_Element(R,Buffer->Str,C++);
  }
  R=Ins_List_List(R,PredicateVerb,C+=Size_of_List(PredicateVerb));
  Toggle=0;
  for(Buffer=Qualifiers,Buffer2=Nouns;Buffer&&Buffer2;Buffer=Buffer->Next,Buffer2=Buffer2->Next){
    R=Ins_List_Element(R,"a",C++);
    R=Ins_List_Element(R,Buffer->Str,C++);
    R=Ins_List_Element(R,Buffer2->Str,C++);
  }
  return R;
}

/*! \brief Deconstruct the sentence into component forms.
 *
 */
struct Sentence *ConvertSentence(struct List_Str *Sentence,int AutoLearnWords, int DisableComplexS){
  struct Sentence *Output=NULL;
  Output=(struct Sentence *)malloc(sizeof(struct Sentence));
  Output->Understood=1;

  /* needs to convert to lower case */
  Sentence=IWrapper(Str2List(ToLower(List2Str(Sentence))));
  Output->Sentence=Sentence;

  Output->Mood=Spirit(Sentence,AutoLearnWords);
  Output->Disambiguated=Disambiguated;
  Output->InterceptedSpirit=InterceptedSpirit;
  Output->Language=GetLang();
  Output->Sentiency=Detect_Sentiency();
  Output->Negation=0;
  if(DisableComplexS)
    Output->ComplexSentence=0;
  else
    Output->ComplexSentence=ComplexSentence(Output);
  Output->PassiveVoice=0;
  if(!Output->Mood)
    Output->Understood=0;
  else{
    Output->PassiveVoice=Active_Passive(Sentence);
  }

  if(ThinkOutLoud) 
    puts("Scanning sentence structures...");
  SeparateSentence(Output);
  if(Output->Subject||Output->PredicateVerbBlock||Output->PredicateNounBlock){}
  else
    Output->Understood=0;

  Output->S=NULL;
  Output->PV=NULL;
  Output->PN=NULL;

  Output->RefinedSubject=NULL;
  Output->RefinedPredicate=NULL;
  Output->RefinedVerb=NULL;

  if(Output->Understood){

    Output->CSVerbRef=RootVerb(Output->PredicateVerbBlock);
    Output->RefinedSubject=RefineNouns(Output->Subject,Output->PassiveVoice);
    Output->SubjectLogic=DetermineNounLogic(Output->Subject);

    Output->RefinedPredicate=RefineNouns(Output->PredicateNounBlock,Output->PassiveVoice);
    Output->PredicateLogic=DetermineNounLogic(Output->Predicate);
    Output->RefinedVerb=RootVerb(PutAdverbsLast(SetExclude(Output->PredicateVerbBlock,Str2List("not"))));

    Output->Negation=IsNegated(Output->PredicateVerbBlock);

    if((0<Output->InterceptedSpirit)&&(Output->InterceptedSpirit<4)){
      if(Output->InterceptedSpirit==1)	
	Output->S=Canonical(Output->Subject,1,1);
      else
	Output->S=Canonical(Output->Subject,0,1);
      Output->PV=Canonical(VerbBaseFinder(Output->PredicateVerbBlock),1,1);
      Output->PN=Canonical(Output->PredicateNounBlock,1,1);
    }
    Output->VerbCSNum=CSCreate(Output->RefinedVerb);
  }
  else{
    Output->CSVerbRef=NULL;
    if(ThinkOutLoud)
      puts("Please rephrase this sentence, or extend language functions.");
  }
  
  if(Is_List_Element(Output->RefinedVerb,"past"))
    Output->Tense=0;
  if(Is_List_Element(Output->RefinedVerb,"present"))
    Output->Tense=1;
  if(Is_List_Element(Output->RefinedVerb,"future"))
    Output->Tense=2;

  Output->SContainsGroup=ContainsGrouping(Output->S);
  Output->SContainsPlurals=ContainsPlurals(Output->S);
  Output->SIsPlural=IsPlural(Output->S);
  Output->PContainsGroup=ContainsGrouping(Output->PN);
  Output->PContainsPlurals=ContainsPlurals(Output->PN);
  Output->PIsPlural=IsPlural(Output->PN);

  return Output;
}

/*! \brief Add adverbs to the sentence.
 *
 */
struct List_Str *ModSenAddAdv(struct List_Str *Sentence,char *Adverb){
  int ContainsBe=0,VerbPos=0;
  char *Tense=NULL,*SentenceInStr=NULL;
  struct List_Str *R=NULL,*VerbForms=NULL,*Buffer=NULL,*TenseData=NULL;
  struct Sentence *ProcSentence=NULL;
  struct Datablock *DB=NULL;
  /* lets start with something simple, negating sentences! */
  ProcSentence=ConvertSentence(Sentence,0,1);
  Tense=Get_List_Element(ProcSentence->CSVerbRef,1);
  /* need to check if the base verb is be or something else */
  if(!(DB=Goto_DB_Entry(Database[1],":meldvf"))){
    if(ThinkOutLoud)
      printf("Warning: NegateSentence (%s,%d) :meldvf missing from language\n",__FILE__,__LINE__);
    return NULL;
  }
  VerbForms=DB->DS[2];
  SentenceInStr=List2Str(Sentence);
  for(Buffer=VerbForms;Buffer;Buffer=Buffer->Next)
    if(strstr(SentenceInStr,Buffer->Str))
      ContainsBe=1;
  /*
    Examples:
    ---------
    the dog [was not] sat on the mat
    the dog [is not] sat on the mat
    the dog [will not be] sat on the mat
    the mat was [not] under the tree
    the mat is [not] under the tree
    the mat will [not] be under the tree
   */
  R=Cpy_List(Sentence);
  VerbPos=0;
  if(!ContainsBe){
    TenseData=Ins_List_Element(TenseData,Adverb,0);
    if(!strcmp(Tense,"past"))
      TenseData=Ins_List_Element(TenseData,"was",0);
    if(!strcmp(Tense,"present"))
      TenseData=Ins_List_Element(TenseData,"is",0);
    if(!strcmp(Tense,"future"))
      TenseData=Ins_List_Element(TenseData,"will",0);
    for(Buffer=Sentence;Buffer;Buffer=Buffer->Next){
      if(IsArticle(Buffer->Str,"verb")){
	R=Ins_List_List(R,TenseData,VerbPos);
	break;
      }
      VerbPos++;
    }
  }
  else{
    for(Buffer=Sentence;Buffer;Buffer=Buffer->Next){
      if(IsArticle(Buffer->Str,"verb")){
	R=Ins_List_Element(R,Adverb,VerbPos+1);
	break;
      }
      VerbPos++;
    }
  }
  return R;
}

/*! \brief Negate a sentence.
 *
 */
struct List_Str *NegateSentence(struct List_Str *Sentence){
  return ModSenAddAdv(Sentence,"not");
}

/*! \brief Convert an indicative sentence into an imperative one.
 *
 */
struct List_Str *ModSenInd2Imp(struct List_Str *Sentence){
  int VerbIs=0,NegIs=0,_=0;
  struct List_Str *R=NULL,*VerbBlock=NULL,*Verbs=NULL,*Buffer=NULL;
  struct Sentence *InternalSentence=NULL;
  struct Datablock *DB=NULL;
  if(!Sentence)
    return NULL;
  InternalSentence=ConvertSentence(Sentence,0,1);
  /* Put the verbs first */
  VerbBlock=InternalSentence->PredicateVerbBlock;
  for(Buffer=VerbBlock,_=0;Buffer;Buffer=Buffer->Next){
    if(!IsArticle(Buffer->Str,"adverb"))
      Verbs=Ins_List_Element(Verbs,Buffer->Str,_++);
    else
      NegIs=1;
  }
  /* determine if the verb blocks are verb conjugates of "be" */  
  if((DB=Goto_DB_Entry(Database[1],":meldvf"))){
    VerbIs=0;
    for(Buffer=DB->DS[2];Buffer;Buffer=Buffer->Next){
      if(!strcmp(Buffer->Str,List2Str(Verbs))){
	VerbIs=1;
      }      
    }
    if(VerbIs){
      if(NegIs)
	VerbBlock=Str2List("do not put");
      else
	VerbBlock=Str2List("put");
    }
    else{
      /* Change tense of verb to present */
      VerbBlock=DiscardTense(Canonical(VerbBaseFinder(Verbs),1,1));
      for(;VerbBlock->Next;VerbBlock=VerbBlock->Next){}
      if(NegIs)
	VerbBlock=Ins_List_List(VerbBlock,Str2List("do not"),0);
    }
  }
  else{
    if(ThinkOutLoud)
      printf("ModSenInd2Imp (%s,%d): Language not setup!\n",__FILE__,__LINE__);
    return NULL;
  }
  /* VERB SUBJECT PREDICATENOUNS */
  R=InternalSentence->PredicateNounBlock;
  R=Ins_List_List(R,InternalSentence->Subject,0);
  R=Ins_List_List(R,VerbBlock,0);
  return R;
}

/*! \brief Convert an imperative sentence into an indicative one.
 *
 */
struct List_Str *ModSenImp2Ind(struct List_Str *Sentence){
  struct List_Str *R=NULL,*Verb=NULL;
  struct Sentence *InternalSentence=NULL;
  if(!Sentence)
    return NULL;
  InternalSentence=ConvertSentence(Sentence,0,1);
  if(!strcmp(List2Str(InternalSentence->PredicateVerbBlock),"put"))
    Verb=Ins_List_Element(Verb,"is",0);
  else
    Verb=InternalSentence->PredicateVerbBlock;
  R=InternalSentence->PredicateNounBlock;
  R=Ins_List_List(R,Verb,0);
  R=Ins_List_List(R,InternalSentence->Subject,0);
  return R;
}
 
/*! \brief Convert an active sentence into a passive one.
 *
 */
struct List_Str *ModSenAct2Pas(struct List_Str *Sentence){
  int Prep,_=0;
  char *Data=NULL;
  struct List_Str *R=NULL,*Buffer=NULL,*NewPredNB=NULL;
  struct Sentence *InternalSentence=NULL,*FinalSentence=NULL;
  InternalSentence=ConvertSentence(Sentence,0,1);
  /* Place the preposition after the verb */
  for(Buffer=InternalSentence->PredicateNounBlock;Buffer;Buffer=Buffer->Next){
    Prep=0;
    if(IsArticle(Buffer->Str,"preposition")){
      Data=Buffer->Str;
      Prep=1;
    }
    if(!Prep)
      NewPredNB=Ins_List_Element(NewPredNB,Buffer->Str,_++);
  }
  R=InternalSentence->Subject;
  R=Ins_List_Element(R,"by",0);
  if(Data)
    R=Ins_List_Element(R,Data,0);
  R=Ins_List_List(R,InternalSentence->PredicateVerbBlock,0);
  R=Ins_List_List(R,NewPredNB,0);
  /* Need to verify if the new sentence makes sense! */
  FinalSentence=ConvertSentence(R,0,1);
  if(!FinalSentence->Understood){
    R=NULL;
  }
  return R;
}

/*! \brief Convert a passive sentence into an active one.
 *
 */
struct List_Str *ModSenPas2Act(struct List_Str *Sentence){
  struct List_Str *R=NULL;
  struct Sentence *InternalSentence=NULL,*FinalSentence=NULL;
  InternalSentence=ConvertSentence(Sentence,0,1);
  R=InternalSentence->PredicateNounBlock;
  R=Ins_List_List(R,InternalSentence->PredicateVerbBlock,0);
  R=Ins_List_List(R,InternalSentence->Subject,0);
  FinalSentence=ConvertSentence(R,0,1);
  if(!FinalSentence->Understood)
    R=NULL;
  return R;
}

/*! \brief Return a list of verbs which are direct variants of the verb specified.
 *
 */
struct List_Str *ListSimilarVerbs(struct List_Str *L){
  char *Stash=NULL;
  struct List_Str *Buffer=NULL,*TMP=NULL,*R=NULL;
  struct Datablock *DB=NULL;
  for(Buffer=L;Buffer;Buffer=Buffer->Next)
    if((DB=Goto_DB_Entry(Database[1],Buffer->Str)))
      if((Stash=Lookup_DB_Attr(DB,":baseword",NULL)))
	if((DB=Goto_DB_Entry(Database[1],Stash)))
	  if((TMP=Str2List(Lookup_DB_Attr(DB,":similarwords",NULL))))
	    R=Ins_List_List(R,TMP,0);
  return R;
}

/*! \brief Filter out verbs of the same tense.
 *
 */
struct List_Str *FilterTense(struct List_Str *L,char *Tense){
  int _=0;
  struct List_Str *Buffer=NULL,*R=NULL;
  struct Datablock *DB=NULL;
  for(Buffer=L;Buffer;Buffer=Buffer->Next)
    if((DB=Goto_DB_Entry(Database[1],Buffer->Str)))
      if(Is_List_Element(Str2List(Get_DB_Entry(DB,0,2)),Tense))
	R=Ins_List_Element(R,Buffer->Str,_++);
  return R;
}

/*! \brief Initialise Meanings structure to null.
 *
 */
struct Meanings *ZeroMeanings(){
  struct Meanings *New=(struct Meanings *)malloc(sizeof(struct Meanings));
  New->Size=0;
  New->Conversations=NULL;
  return New;
}

/*! \brief Debug the Meanings structure.
 *
 */
void DebugMeanings(struct Meanings *M){
  int _=0;
  for(_=0;_<M->Size;_++){
    PrintListSpecial("[",M->Conversations[_],"][","][","]\n");
  }
}

/*! \brief Recall a previous sentence. 
 * 
 */
struct List_Str *RecPrevSentence(int Prev){
  int _=0,Size=0,Trip=0;
  struct List_Str *R=NULL,*Sentences=NULL,*SentenceVerbs=NULL,*Buffer=NULL;
  struct List_Str *OrderedSentences=NULL,*S=NULL,*T=NULL,*TopicItems=NULL;
  /* find the topics */
  /* need to suppress the output */
  Trip=ENABLEOUT;
  ENABLEOUT=0;
  Topic(NULL,NULL);
  ENABLEOUT=Trip;
  TopicItems=ANSWER;
  /* find a list of sentences */
  ListSentences(CSList(),NULL);
  for(SentenceVerbs=ANSWER;SentenceVerbs;SentenceVerbs=SentenceVerbs->Next){
    CS2Sentence(Str2List(SentenceVerbs->Str),NULL);
    for(Buffer=ANSWER;Buffer;Buffer=Buffer->Next)
      if(!Is_List_Element(Sentences,Buffer->Str))
	Sentences=Ins_List_Element(Sentences,Buffer->Str,_++);
  }
  _=0;
  for(T=TopicItems;T;T=T->Next)
    for(S=Sentences;S;S=S->Next)
      if(strstr(S->Str,T->Str))
	if(!Is_List_Element(OrderedSentences,S->Str))
	  OrderedSentences=Ins_List_Element(OrderedSentences,S->Str,_++);
  Size=Size_of_List(OrderedSentences);
  if(Size>Prev)
    R=Str2List(Get_List_Element(OrderedSentences,Size-Prev-1));
  return R;
}

/*! \brief Convert the sentence to another sentence using a base verb rather than the one specified.
 * 
 */
struct List_Str  *SentenceConvertBase(struct List_Str *Word_List,struct List_Str *L){
  int _=0;
  struct List_Str *FinalSentence=NULL,*Buffer=NULL,*Buffer2=NULL;
  struct Sentence *ThisSentence=NULL;
  ThisSentence=ConvertSentence(Word_List,0,0);
  for(Buffer=ThisSentence->Sentence;Buffer;Buffer=Buffer->Next){
    if(!IsArticle(Buffer->Str,"verb"))
      FinalSentence=Ins_List_Element(FinalSentence,Buffer->Str,_++);
    else
      for(Buffer2=ThisSentence->CSVerbRef;Buffer2;Buffer2=Buffer2->Next)
	if(IsArticle(Buffer2->Str,"verb"))
	  FinalSentence=Ins_List_Element(FinalSentence,Buffer2->Str,_++);
  }
  ANSWER=FinalSentence;
  return L;
}

/*! \brief Convert the sentence so that its verb is the tense specified. 
 * 
 */
struct List_Str  *SentenceConvertTense(struct List_Str *Word_List,struct List_Str *L){
  int _=0;
  char *Str=NULL,*Tense=NULL,*InitialVerb=NULL,*MiddleVerb=NULL,*FinalVerb=NULL;
  struct List_Str *FinalSentence=NULL,*Buffer=NULL,*FilterSubject=NULL,*FilterPredicate=NULL,*PrepositionList=NULL;
  struct Sentence *ThisSentence=NULL;
  ThisSentence=ConvertSentence(Word_List,0,0);
  if(!ThisSentence->Mood){
    if(ThinkOutLoud){
      printf("Warning: ConvertSentenceTense, %s:%d, unable to determine sentence mood, aborting.\n",__FILE__,__LINE__);
      PrintListSpecial("When you have a minute, please add: [",Word_List," "," ","] to the grammar training profile.\n");
    }
    ANSWER=Word_List;
    return L;
  }
  Tense=L->Str;
  /* Set InitialVerb and middle verb*/
  if(!strcmp(Tense,"past")){
    if(ThisSentence->SIsPlural==0)
      InitialVerb="was";
    else
      InitialVerb="were";
  } else if(!strcmp(Tense,"future")){
    InitialVerb="will";
    MiddleVerb="be";
  } else{
    if(ThisSentence->SIsPlural==0)
      InitialVerb="is";
    else
      InitialVerb="are";
  }
  /* Set FinalVerb */
  for(Buffer=ThisSentence->PV;Buffer;Buffer=Buffer->Next)
    if(IsArticle(Buffer->Str,"verb")&&strcmp(Buffer->Str,"is"))
      FinalVerb=ConvertVerbTense(Buffer->Str,Tense,!(ThisSentence->PassiveVoice));
  if(!strcmp(ThisSentence->Mood,"indicative")){
    if(ThisSentence->PassiveVoice){
      FinalSentence=ThisSentence->BasicSubject;
      FinalSentence=Ins_List_List(FinalSentence,ThisSentence->PassiveVerbPrepositions,0);
      if(FinalVerb)
	FinalSentence=Ins_List_Element(FinalSentence,FinalVerb,0);
      if(MiddleVerb)
	FinalSentence=Ins_List_Element(FinalSentence,MiddleVerb,0);
      FinalSentence=Ins_List_Element(FinalSentence,InitialVerb,0);
      FinalSentence=Ins_List_List(FinalSentence,ThisSentence->BasicPredicate,0);
    }
    else{
      FinalSentence=ThisSentence->PN;
      if(FinalVerb)
	FinalSentence=Ins_List_Element(FinalSentence,FinalVerb,0);
      if(MiddleVerb)
	FinalSentence=Ins_List_Element(FinalSentence,MiddleVerb,0);
      FinalSentence=Ins_List_Element(FinalSentence,InitialVerb,0);
      FinalSentence=Ins_List_List(FinalSentence,ThisSentence->S,0);
    }
  }
  else if(!strcmp(ThisSentence->Mood,"imperative")){
    _=0;
    for(Buffer=ThisSentence->Sentence;Buffer;Buffer=Buffer->Next)
      if(!IsArticle(Buffer->Str,"verb"))
	FinalSentence=Ins_List_Element(FinalSentence,Buffer->Str,_++);
      else
	FinalSentence=Ins_List_Element(FinalSentence,List2Str(VerbBaseFinder(Str2List(Buffer->Str))),_++);
  }
  else if(!strcmp(ThisSentence->Mood,"ynq")){
    if(ThisSentence->PassiveVoice){
      FinalSentence=ThisSentence->BasicSubject;
      FinalSentence=Ins_List_List(FinalSentence,ThisSentence->PassiveVerbPrepositions,0);
      if(FinalVerb)
	FinalSentence=Ins_List_Element(FinalSentence,FinalVerb,0);
      if(MiddleVerb)
	FinalSentence=Ins_List_Element(FinalSentence,MiddleVerb,0);
      FinalSentence=Ins_List_List(FinalSentence,ThisSentence->BasicPredicate,0);
      FinalSentence=Ins_List_Element(FinalSentence,InitialVerb,0);
    }
    else{
      FinalSentence=ThisSentence->PN;
      FinalSentence=Ins_List_Element(FinalSentence,FinalVerb,0);
      if(MiddleVerb)
	FinalSentence=Ins_List_Element(FinalSentence,MiddleVerb,0);
      FinalSentence=Ins_List_List(FinalSentence,ThisSentence->S,0);
      FinalSentence=Ins_List_Element(FinalSentence,InitialVerb,0);
    }
  }
  else if(!strcmp(ThisSentence->Mood,"whq")){
    if(ThisSentence->PassiveVoice){
      FinalSentence=Ins_List_List(FinalSentence,ThisSentence->BasicPredicate,0);
      FinalSentence=Append_List_Element(FinalSentence,InitialVerb);
      if(MiddleVerb)
	FinalSentence=Append_List_Element(FinalSentence,MiddleVerb);
      if(FinalVerb)
	FinalSentence=Append_List_Element(FinalSentence,FinalVerb);
      FinalSentence=Ins_List_List(FinalSentence,ThisSentence->PassiveVerbPrepositions,Size_of_List(FinalSentence));
      FinalSentence=Ins_List_List(FinalSentence,ThisSentence->BasicSubject,Size_of_List(FinalSentence));
    }
    else{
      FilterPredicate=ExtractArticles(ThisSentence->PN,FILTERCLAUSE);
      FilterSubject=ExtractArticles(ThisSentence->S,FILTERCLAUSE);
      PrepositionList=ExtractArticles(ThisSentence->PN,"preposition");
      FinalSentence=Ins_List_Element(FinalSentence,"?",0);
      FinalSentence=Ins_List_List(FinalSentence,FilterPredicate,0);
      FinalSentence=Ins_List_List(FinalSentence,PrepositionList,0);
      FinalSentence=Ins_List_Element(FinalSentence,FinalVerb,0);
      if(MiddleVerb)
	FinalSentence=Ins_List_Element(FinalSentence,MiddleVerb,0);
      FinalSentence=Ins_List_Element(FinalSentence,InitialVerb,0);
      FinalSentence=Ins_List_List(FinalSentence,FilterSubject,0);
    }
  }
  else{
    for(Buffer=ThisSentence->Sentence;Buffer;Buffer=Buffer->Next){
      if(!IsArticle(Buffer->Str,"verb"))
	FinalSentence=Ins_List_Element(FinalSentence,Buffer->Str,_++);
      else{
	if((Str=ConvertVerbTense(Buffer->Str,L->Str,!(ThisSentence->PassiveVoice)))){
	  /* insert be if it is future tense */
	  if(!strcmp(L->Str,"future"))
	    FinalSentence=Ins_List_Element(FinalSentence,"be",_++);
	  FinalSentence=Ins_List_Element(FinalSentence,Str,_++);
	}
	else
	  FinalSentence=Ins_List_Element(FinalSentence,Buffer->Str,_++);
      }
    }
  }
  ANSWER=FinalSentence;
  return L->Next;
}

/*! \brief Convert the verb to a different tense. 
 * 
 */
char *ConvertVerbTense(char *Verb,char *Tense,int ActiveVoice){
  char *R=NULL,*BaseVerb=NULL;
  struct List_Str *Verbs=NULL;
  struct Datablock *DB=NULL;
  /* start by finding the baseverb */
  if((DB=Goto_DB_Entry(Database[1],Verb)))
    BaseVerb=Lookup_DB_Attr(DB,":baseword",NULL);
  if(!BaseVerb)
    return Verb;
  Tense=ActiveVoice?strdup("present"):strdup("past");
  /* look for verbs that point to the base verb */
  for(DB=Database[1];DB;DB=DB->Next)
    if((IsArticle(Verb,"verb"))&&(!strcmp(Get_DB_Entry(DB,0,2),Tense)))
      if(!strcmp(Lookup_DB_Attr(DB,":baseword",NULL),BaseVerb))
	if(strcmp(R=Get_DB_Entry(DB,0,0),"?"))
	  Verbs=Ins_List_Element(Verbs,R,0);
  R=NULL;
  if(strcmp(Tense,"past"))
    for(;Verbs;Verbs=Verbs->Next)
      if(strstr(Verbs->Str,"ing"))
	R=Verbs->Str;
  if(!R)
    return Verb;
  return R;
}

/*! \brief Sort out the nouns so that they are in a more canonical format.
 * 
 */
struct List_Str *RefineNouns(struct List_Str *Clause,int Passive){
  int _=0,WasAdjective=0;
  char *Conjunctions="conjunction";
  struct List_Str *R=NULL,*Buffer=NULL,*Cleaned=NULL;
  struct List_Str *Nouns=NULL,*Adjectives=NULL,*Prepositions=NULL;
  struct List_Str *TMP=NULL,*SubClauses=NULL;

  /* start by determining if there are any conjunctions */
  if(ExtractArticles(Clause,Conjunctions)){

    /* separate out sub phrases */
    for(Buffer=Clause;Buffer;Buffer=Buffer->Next){
      if((IsArticle(Buffer->Str,Conjunctions))&&(!WasAdjective)){
	if(TMP){
	  SubClauses=Ins_List_Element(SubClauses,List2Str(RefineNouns(TMP,Passive)),_++);
	  TMP=NULL;
	}
      }
      else{
	if(!IsArticle(Buffer->Str,Conjunctions))
	  TMP=Ins_List_Element(TMP,Buffer->Str,0);
	if(!Buffer->Next)
	  if(TMP)
	    SubClauses=Ins_List_Element(SubClauses,List2Str(RefineNouns(TMP,Passive)),_++);
      }

      /* if a conjunction follows an adjective then it should be ignored */
      if(IsArticle(Buffer->Str,"adjective"))
	WasAdjective=1;
      else
	WasAdjective=0;
    }

    /* sort them */
    SubClauses=SortList(SubClauses);
    return SubClauses;
  }
  else{
    /* start by filtering the word types */
    R=ExtractArticles(Clause,"noun propernoun pronoun adjective preposition");
  
    /* get rid of the by in passive sentence */
    if(Passive)
      for(Buffer=R;Buffer;Buffer=Buffer->Next){
	if(strcmp(Buffer->Str,"by"))
	  Cleaned=Ins_List_Element(Cleaned,Buffer->Str,_++);
      }
    else
      Cleaned=Clause;
    R=Cleaned;
  
    /* Sort and arrange the articles in order */
    Nouns=SortList(ExtractArticles(Cleaned,FILTERNOUNSONLY));
    Adjectives=SortList(ExtractArticles(Cleaned,"adjective"));
    Prepositions=SortList(ExtractArticles(Cleaned,"preposition"));
    Cleaned=Prepositions;
    Cleaned=Ins_List_List(Cleaned,Adjectives,0);
    Cleaned=Ins_List_List(Cleaned,Nouns,0);
    R=Cleaned;
  }
  return Ins_List_Element(NULL,List2Str(R),0);
}

/*! \brief Determine the logic operations between conjoined nouns.
 * - The opposite of NounRefine2Clause().
 */
int DetermineNounLogic(struct List_Str *Clause){
  int R=0,Commas=0,Ands=0,Ors=0,Nors=0,Neithers=0,Eithers=0,WasAdjective=0;
  struct List_Str *LogicOps=ExtractArticles(Clause,"conjunction punctuation");
  struct List_Str *Buffer=NULL;

  /* Logic = 0:AND,1:OR,2:NOR,3:XOR,4:Error */
  if(LogicOps){
    for(Buffer=Clause;Buffer;Buffer=Buffer->Next){
      if(!WasAdjective){
	if(!strcmp(Buffer->Str,","))             Commas++;
	else if(!strcmp(Buffer->Str,"and"))      Ands++;
	else if(!strcmp(Buffer->Str,"or"))       Ors++;
	else if(!strcmp(Buffer->Str,"either"))   Eithers++;
	else if(!strcmp(Buffer->Str,"neither"))  Neithers++; 
	else if(!strcmp(Buffer->Str,"nor"))      Nors++;
      }
      if(IsArticle(Buffer->Str,"adjective"))
	WasAdjective=1;
      else
	WasAdjective=0;
    }
    R=Ors?1:R;
    R=(Neithers&&(Nors||Ors))?2:R;
    R=(Eithers&&Ors)?3:R;
    R=Ands?0:R;
  }
  else
    R=0;
  return R;
}

/*! \brief Create a claus from subject data and logic.
 *  - The opposite of DetermineNounLogic().
 */
struct List_Str *NounRefine2Clause(struct List_Str *Refined,int Logic){
  char *Start=NULL,*FinalSep=NULL;
  struct List_Str *R=NULL,*SubClause=NULL,*Buffer=NULL,*TMP=NULL,*Final=NULL;
  for(Buffer=Refined;Buffer;Buffer=Buffer->Next){
    SubClause=Str2List(Buffer->Str);
    TMP=ExtractArticles(SubClause,FILTERNOUNSONLY);
    TMP=Ins_List_List(TMP,FormatList(ExtractArticles(SubClause,"adjective"),NULL,",","and",NULL),0);
    if(ExtractArticles(SubClause,"noun"))
      TMP=Ins_List_Element(TMP,"the",0);
    TMP=Ins_List_List(TMP,ExtractArticles(SubClause,"preposition"),0);
    Final=Add2Set(Final,List2Str(TMP));
  }
  if(Logic==0)
    FinalSep="and";
  else if(Logic==1)
    FinalSep="or";
  else if(Logic==2){
    Start="neither";
    FinalSep="nor";
  }else if(Logic==3){
    Start="either";
    FinalSep="or";
  }
  R=Str2List(List2Str(FormatList(Final,Start,",",FinalSep,NULL)));
  return R;
}

/*! \brief Create a verb clause.
 *  
 */
struct List_Str  *VerbRefine2Clause(struct List_Str *Refined){
  struct List_Str *R=NULL,*Adverbs=NULL,*Verbs=NULL;
  Adverbs=ExtractArticles(Refined,"adverb");
  Verbs=ExtractArticles(Refined,"verb");
  R=Ins_List_List(Verbs,Adverbs,0);
  return R;
}

/*! \brief Create a new sentence structure with the information provided as parameters.
 *  
 */
struct Sentence *CreateSentenceStruct(struct List_Str *Subj,int SLogic,struct List_Str *Pred,int PLogic,struct List_Str *Verbs,int Tense,char *Mood){
  struct Sentence *S=(struct Sentence *)malloc(sizeof(struct Sentence));
  S->SubjectLogic=SLogic;
  S->PredicateLogic=PLogic;
  S->RefinedSubject=Subj;
  S->RefinedPredicate=Pred;
  S->RefinedVerb=Verbs;
  S->PassiveVoice=0;
  S->Tense=0;
  S->Mood=Mood;
  return S;
}

/*! \brief Dereference a CS record ID into a sentence.
 *  
 */
struct List_Str  *CS2Sentence(struct List_Str *Word_List,struct List_Str *L){
  struct List_Str *Buffer=NULL,*Final=NULL;
  for(Buffer=Word_List;Buffer;Buffer=Buffer->Next){
    Final=Ins_List_List(Final,CSSentenceRecon(Buffer->Str),Size_of_List(Final));
  }
  ANSWER=Final;
  return L;
}

/*! \brief Dereference a CS record ID into a sentence.
 * - Internal version of CS2Sentence(). 
 */
struct List_Str  *CSSentenceRecon(char *CSID){
  /* 
     CSID must be the CS number of the verb of the sentence 
     see :listsentences and :listcsvalues
   */
  int Tense=-1,_=0;
  char *RecordName=NULL;
  struct List_Str *R=NULL,*Buffer=NULL,*DS1=NULL,*DS2=NULL,*Verb=NULL,*Subject=NULL,*Predicate=NULL;
  struct List_Str *B1=NULL;
  struct Datablock *DB=NULL;
  RecordName=StrCat("_examples_",CSID);
  DB=Goto_DB_Entry(Database[0],RecordName);
  free(RecordName);
  if(DB){
    /* need to find tense */
    Verb=IntCSRecon(CSID);
    for(_=0;_<3;_++)
      if(Is_List_Element(Verb,TenseTypes[_]))
	Tense=_;
    if(Tense==-1)
      printf("ERROR: No tense found! (%s:%d)\n",__FILE__,__LINE__);
    for(DS1=DB->DS[1],DS2=DB->DS[2];DS1;DS1=DS1->Next,DS2=DS2->Next)
      if(strcmp(DS2->Str,":NULL")){
	Subject=NULL;
	for(B1=Str2List(DS1->Str);B1;B1=B1->Next)
	  Subject=Ins_List_Element(Subject,List2Str(IntCSRecon(B1->Str)),0);
	Predicate=Ins_List_Element(NULL,List2Str(IntCSRecon(DS2->Str)),0);
	Buffer=Convert2Sentence(CreateSentenceStruct(Subject,0,Predicate,0,Verb,Tense,"indicative"));
	R=Ins_List_Element(R,List2Str(Buffer),0);
      }
  }
  else
    return NULL;
  return R;
}

/*! \brief Calculates combinations.
 * - Internal recursive module component.
 */
void CombRec(struct List_Str *Sofar, struct List_Str *D,int L){
  int _=0,Size=Size_of_List(D);
  char *E=NULL;
  struct List_Str *Buffer=NULL,*Prefix=NULL;
  if(L){
    for(_=0;_<Size;_++){
      Buffer=Cpy_List(D);
      E=Get_List_Element(D,_);
      Buffer=Del_List_Element(Buffer,_);
      Prefix=Ins_List_Element(Cpy_List(Sofar),E,Size_of_List(Sofar));
      CombRec(Prefix,Buffer,L-1);
    }
  }
  else
    ANSWER=Ins_List_Element(ANSWER,List2Str(Sofar),Size_of_List(ANSWER));
}

/*! \brief Creates a list of combinations.
 * 
 */
struct List_Str *ListCombinations(struct List_Str *WordList, struct List_Str *L){
   int Size=Size_of_List(WordList);
   ANSWER=NULL;
   CombRec(NULL,WordList,Size);
   Shrink(ANSWER,NULL);
   return L;
}

/*! \brief Generates phrases.
 * 
 */
struct List_Str *Phrase_Generator(struct List_Str *WordList, struct List_Str *L){
  int SL=0,PL=0,_=0;
  struct List_Str *Buffer=NULL,*Buffer2=NULL,*Output=NULL,*S=NULL,*PV=NULL,*PN=NULL,*NewSentence=NULL;
  struct Sentence *DecodedSentence=NULL,*FinalSentenceCHK=NULL;
  ListCombinations(WordList,ANSWER=NULL);
  Buffer=ANSWER;
  for(;Buffer;Buffer=Buffer->Next)
    if(Spirit(Str2List(Buffer->Str),0))
      Buffer2=Ins_List_Element(Buffer2,Buffer->Str,_++);
  for(Buffer=Buffer2;Buffer;Buffer=Buffer->Next){
    DecodedSentence=ConvertSentence(Str2List(Buffer->Str),0,0);
    if(DecodedSentence->Understood&&(!strcmp(DecodedSentence->Mood,"indicative"))){
      SL=DecodedSentence->SubjectLogic;
      PL=DecodedSentence->PredicateLogic;
      S=DecodedSentence->RefinedSubject;
      PV=DecodedSentence->RefinedVerb;
      PN=DecodedSentence->RefinedPredicate;
      NewSentence=Convert2Sentence(CreateSentenceStruct(S,SL,PN,PL,PV,0,"indicative"));
      if((FinalSentenceCHK=ConvertSentence(NewSentence,0,0))&&(FinalSentenceCHK->Understood))
	Output=Add2Set(Output,List2Str(NewSentence));
    }
  }
  ANSWER=Output;
  return L;
}

/*! \brief Format the sentence structure into an actual sentence.
 * 
 */
struct List_Str  *Convert2Sentence(struct Sentence *Sentence){
  struct List_Str *R=NULL,*S=NULL,*PV=NULL,*PN=NULL;
  S=NounRefine2Clause(Sentence->RefinedSubject,Sentence->SubjectLogic);
  PV=VerbRefine2Clause(Sentence->RefinedVerb);
  PN=NounRefine2Clause(Sentence->RefinedPredicate,Sentence->PredicateLogic);
  if(!strcmp(Sentence->Mood,"indicative")){
    R=Ins_List_List(PN,PV,0);
    R=Ins_List_List(R,S,0);
    SentenceConvertTense(R,Str2List(TenseTypes[Sentence->Tense]));
    R=ANSWER;
  }
  else if(!strcmp(Sentence->Mood,"imperative")){
    /* needs adjusting */
    R=PN;
    R=Ins_List_List(R,S,0);
    R=Ins_List_List(R,PV,0);
    SentenceConvertTense(R,Str2List(TenseTypes[Sentence->Tense]));
    R=ANSWER;
  }
  else if(!strcmp(Sentence->Mood,"ynq")){
    S=NounRefine2Clause(Sentence->RefinedSubject,Sentence->SubjectLogic);
    PV=VerbRefine2Clause(Sentence->RefinedVerb);
    PN=NounRefine2Clause(Sentence->RefinedPredicate,Sentence->PredicateLogic);
    R=PN;
    R=Ins_List_List(R,PV,0);
    R=Ins_List_List(R,S,0);
    R=Ins_List_Element(R,"was",0);
    R=Ins_List_Element(R,"?",Size_of_List(R));
    SentenceConvertTense(R,Str2List(TenseTypes[Sentence->Tense]));
    R=ANSWER;
  }
  else if(!strcmp(Sentence->Mood,"whq")){
    R=Str2List("what was");
    R=Ins_List_List(R,VerbRefine2Clause(Sentence->RefinedVerb),Size_of_List(R));
    R=Ins_List_List(R,ExtractArticles(Str2List(List2Str(Sentence->RefinedPredicate)),"preposition"),Size_of_List(R));
    R=Append_List_Element(R,"by");
    R=Ins_List_List(R,NounRefine2Clause(Sentence->RefinedSubject,Sentence->SubjectLogic),Size_of_List(R));
    R=Append_List_Element(R,"?");
    SentenceConvertTense(R,Str2List(TenseTypes[Sentence->Tense]));
    R=ANSWER;
  }
  return R;
}

/*! \brief If a sentence is syntactically garbelled, descramble it so it makes sense.
 * 
 */
struct List_Str  *DeYoda(struct List_Str *Word_List,struct List_Str *L){
  int SL=0,PL=0;
  struct List_Str *Buffer=NULL,*Phrases=NULL,*S=NULL,*PV=NULL,*PN=NULL,*Output=NULL,*Interrogative=NULL;
  struct Sentence *DecodedSentence=NULL,*ReformattedSentence=NULL;
  /* form a list of syntactically correct sentences */
  Phrase_Generator(Word_List,NULL);
  for(Buffer=Phrases=ANSWER;Buffer;Buffer=Buffer->Next){
    DecodedSentence=ConvertSentence(Str2List(Buffer->Str),0,0);
    SL=DecodedSentence->SubjectLogic;
    PL=DecodedSentence->PredicateLogic;
    S=DecodedSentence->RefinedSubject;
    PV=DecodedSentence->RefinedVerb;
    PN=DecodedSentence->RefinedPredicate;
    Interrogative=Convert2Sentence(CreateSentenceStruct(S,SL,PN,PL,PV,0,"ynq"));
    ReformattedSentence=ConvertSentence(Interrogative,0,0);
    /*
    if(YNQWrapper(ReformattedSentence))
    */
    if(IsMultiplexQuery(ReformattedSentence))
      Output=Add2Set(Output,Buffer->Str);
  }
  if(!Output)
    ANSWER=Phrases;
  else
    ANSWER=Output;
  return L;
}

/*! \brief Determine in a verb clause is negated or not.
 * 
 */
int IsNegated(struct List_Str *PV){
  if(Is_List_Element(PV,"not"))
    return 1;
  return 0;
}

/*! \brief Convert a sentence into one grammatical mood into another grammatical mood.
 * 
 */
struct List_Str *SentenceConvertMood(struct List_Str *Word_List,struct List_Str *L){
  char *RequiredSentenceMood=L->Str;
  struct List_Str *Result=NULL;
  struct Sentence *SData=ConvertSentence(Word_List,1,1);
  Result=Convert2Sentence(CreateSentenceStruct(SData->RefinedSubject,SData->SubjectLogic,SData->RefinedPredicate,SData->PredicateLogic,SData->RefinedVerb,0,RequiredSentenceMood));
  ANSWER=Result;
  return L->Next;
}

/*! \brief Process a paragraph as a group of sentences.
 * 
 */
void Paragraph2Sentence(struct List_Str *Paragraph){
   int _=0;
   struct List_Str *Buffer=NULL,*Buffer2=NULL,*EndPuncts=NULL,*TMP=NULL;
   struct Datablock *Lang=GetLang();
   for(Buffer=Paragraph;Buffer;Buffer=Buffer->Next){
     if(Buffer->Str[0]==':'){
       IntelligentInt(Paragraph,1);
       return;
     }
   }
   if(Lang){
      if((_=Find_List_Element(Lang->DS[1],":endpunct"))+1)
	EndPuncts=Str2List(Get_DB_Entry(Lang,2,_));
      else{ 
	 if(ThinkOutLoud) puts(":endpunct is not set!");
	 IntelligentInt(Paragraph,1);
	 return;
      }
   }
   else{
      if(ThinkOutLoud) puts(":endpunct is not set!");
      IntelligentInt(Paragraph,1);
      return;
   }
   _=0;
   for(Buffer=Paragraph;Buffer;Buffer=Buffer->Next){
      TMP=Ins_List_Element(TMP,Buffer->Str,_++);
      if(!Buffer->Next){
	 if(TMP) IntelligentInt(TMP,1);
	 TMP=NULL;
	 _=0;
      }
      else{
	 for(Buffer2=EndPuncts;Buffer2;Buffer2=Buffer2->Next){
	    if(!strcmp(Buffer2->Str,Buffer->Str)){
	       if(TMP) IntelligentInt(TMP,1);
	       TMP=NULL;
	       _=0;
	    }
	 }
      }
   }
}

/*! \brief Learn the Hidden Markov Models / Directed Graphs behind sentence grammar.
 * 
 */
struct List_Str *Study(struct List_Str *WordList,struct List_Str *L){
  int _=0;
  char *First=NULL,*Second=NULL,*G1=NULL,*G2=NULL,*Directed_Graph=NULL; 
  struct List_Str *Sentence=NULL,*Args1=NULL,*Args2=NULL,*Grammar1=NULL,*Grammar2=NULL,*Buffer=NULL;
  struct Datablock *DB=NULL;
  if(!Detect_Sentiency()){
    puts("ERROR: Language needs to be setup before running this command - aborting!");
    return L;
  }
  if(IsGrammarAttribute(":locklang","on")){
    puts("Sorry the language grammar is locked.");
    return L;
  }
  Sentence=WordList;
  Directed_Graph=L->Str;
  L=L->Next;
  DB=GetLang();
  if(!((_=Find_List_Element(DB->DS[1],":graphs"))+1)){
    puts("ERROR: Graphs need to be setup correctly!"); 
    return L;
  }
  else{
    if(!Is_List_Element(Str2List(Get_DB_Entry(DB,2,_)),Directed_Graph)){
      puts("ERROR: Graphs need to be setup correctly!"); 
      return L;
    }
  }
  First="startsentence"; Args1=Ins_List_Element(Args1,"?",0); 
  Args2=Ins_List_Element(Ins_List_Element(Args2,"?",0),"?",0); 
  G1="startsentence"; 
  Grammar1=Ins_List_Element(Grammar1,"?",0); 
  Grammar2=Ins_List_Element(Ins_List_Element(Grammar2,"?",0),"?",0);
  while(Sentence){
    Second=Sentence->Str; 
    Buffer=Str2List(G2=Get_DB_Entry(Goto_DB_Entry(Database[1],Second),0,1));
    if(Buffer->Next){
      printf(":STUDY needs unambiguous grammar categories for directed graphs.\n%s can be either of the following: ",Second);
      PrintList(Buffer);
      puts("Abort command!");
      return L;
    }
    Grammar1->Str=G1;
    Grammar2->Str=G2; 
    Args1->Str=First;
    Args2->Str=Second;
    Grammar2->Next->Str=DirectedGraphStr(G1,G2,Directed_Graph);
    Qualify(Grammar1,Grammar2);
    Qualify(Args1,Args2);
    Sentence=Sentence->Next;
    First=Second;
    G1=G2;
  }
  Grammar1->Str=G1;
  Grammar2->Str="endsentence"; 
  Args1->Str=First;
  Args2->Str="endsentence";
  Grammar2->Next->Str=DirectedGraphStr(G1,"endsentence",Directed_Graph);
  Qualify(Grammar1,Grammar2); 
  Qualify(Args1,Args2);
  return L;
}

/*! \brief Create a load of permutations of a list. 
 *  - This is useful for creating sentences that make sense.
 */
void Permutation(struct List_Str *Set, struct List_Str *Perm, int N){
  int A=0,Size=0; 
  struct List_Str *This_Permutation=NULL,*New=NULL;
  if(N>0){
    for(A=0;A<N;A++){
      This_Permutation=Perm;
      This_Permutation=Ins_List_Element(This_Permutation,Get_List_Element(Set,A),0);
      New=Cpy_List(Set);
      New=Del_List_Element(New,A);
      Permutation(New,This_Permutation,N-1);
      while(New){
	New=Del_List_Element(New,0);
      }
    }
  }
  else{
    Perm=Del_List_Element(Perm,Find_List_Element(Perm,"endsentence"));
    Sentence_Generator(Perm,NULL);
    if(ANSWER){
      ANSWER=Del_List_Element(ANSWER,0);
      New=ANSWER;
      while(New){
	Size++;
	New=New->Next;
      }
      ANSWER=Del_List_Element(ANSWER,Size-1);
      PrintList(ANSWER);
    }
  }
}

/*! \brief Create a load of permutations of a list. 
 *  - This is useful for creating sentences that make sense.
 */
void Permutation2(struct List_Str *Set, struct List_Str *Perm, int N){
   int A=0;
   struct List_Str *This_Permutation=NULL, *New=NULL;
   
   printf("DEBUG P2 1: "); PrintList(Set);
   printf("DEBUG P2 2: "); PrintList(Perm);
   
   if(N>0){
      for(A=0;A<N;A++){
	 This_Permutation=Perm;
	 This_Permutation=Ins_List_Element(This_Permutation,Get_List_Element(Set,A),0);
	 New=Cpy_List(Set);
	 New=Del_List_Element(New,A);
	 Permutation2(New,This_Permutation,N-1);
	 while(New){
	    New=Del_List_Element(New,0);
	 }
      }
   }
   else{
      Perm=Del_List_Element(Perm,Find_List_Element(Perm,"endsentence")); 
      Sentence_Designer(Perm,Ins_List_Element(NULL,":ERROR",0));
      if(!IsSentence(ANSWER))
	ANSWER=NULL;
      if(ANSWER){
	 PrintList(ANSWER);
      }
   }
}

/*! \brief Create a sentence.
 *  
 */
struct List_Str *Sentence_Designer(struct List_Str *WordList, struct List_Str *L){ /* Experimental modification */
   int _=0,C=0;
   char *Category=NULL;
   struct List_Str *Input=NULL,*Grammar=NULL,*Buffer=NULL,*Output=NULL;
   Input=WordList;
   ANSWER=NULL; 
   if(!ANSWER){
      C=0;
      Grammar=NULL;
      Buffer=Input;
      while(Input){
	 Category=Get_DB_Entry(Goto_DB_Entry(Database[1],Input->Str),0,1); 
	 if(strcmp(Category,"?")!=0){
	    Grammar=Ins_List_Element(Grammar,Category,C++);
	 }
	 Input=Input->Next;
      }
      Input=Buffer;
      Sentence_Generator(Grammar,NULL);
      Buffer=ANSWER;
      C=0;
      while(Buffer){
	 if(Grammar&&Input){
	    if(strcmp(Buffer->Str,Grammar->Str)==0){
	       Output=Ins_List_Element(Output,Input->Str,C++);
	       Input=Input->Next;
	       Grammar=Grammar->Next;
	    }
	    else Output=Ins_List_Element(Output,Find_Grammar_Example(Buffer->Str),C++);
	 }
	 else Output=Ins_List_Element(Output,Find_Grammar_Example(Buffer->Str),C++);
	 Buffer=Buffer->Next;
      }
      ANSWER=Output;
   }
   ANSWER=Del_List_Element(ANSWER,0);
   Output=ANSWER;
   _=-1;
   while(Output){
      _++;
      Output=Output->Next;
   }
   ANSWER=Del_List_Element(ANSWER,_);
   return L;
}

/*! \brief Create a sentence.
 *  
 */
struct List_Str *Sentence_Generator(struct List_Str *WordList, struct List_Str *L){
   int _=0,Begin=0;
   char *First=NULL,*Second=NULL;
   struct List_Str *Input=NULL,*Result=NULL,*Inp1=NULL,*Inp2=NULL;
   Input=WordList;
   Inp1=Ins_List_Element(Inp1,"?",0);
   Inp2=Ins_List_Element(Inp2,"?",0);
   Input=Ins_List_Element(Input,"startsentence",0);
   Result=Input; 
   while(Result){
      Result=Result->Next;
      _++;
   } 
   Result=NULL;
   Input=Ins_List_Element(Input,"endsentence",_);
   First=Input->Str;
   Input=Input->Next;
   Begin=1;
   PrintList(Input);
   while(Input){
      Second=Input->Str;
      Inp1->Str=First;
      Inp2->Str=Second;
      printf("DEBUG Sentence Generator L8278: "); PrintList(Inp1);
      printf("DEBUG Sentence Generator L8279: "); PrintList(Inp2);
      /*
      Route(Inp1,Ins_List_Element(Inp2,":ERROR",1));
      */
      Route(Inp1,Inp2);
      if(ANSWER){ 
	 if(Begin){
	    Result=Ins_List_List(ANSWER,Result,0);
	    Begin=0;
	 } 
	 else{
	    Result=Ins_List_List(Del_List_Element(ANSWER,0),Result,0);
	 } 
	 ANSWER=NULL;
      } 
      else{
	 ANSWER=NULL;
	 return L;
	 Begin=1;
      } 
      Input=Input->Next;
      First=Second;
   }
   ANSWER=Result;
   return L;
}

/*! \brief An experimental idea to convert sentences from one language to another.
 * - Incomplete. 
 */
struct List_Str *Translator(struct List_Str *Word_List,struct List_Str *L){
   int _=0;
   char *Language_From=NULL,*Language_To=NULL,*Translate_From=NULL,*Translate_To=NULL;
   struct Datablock *DB=Database[1];
   struct List_Str *To_Translate=Word_List,*Translated=NULL;
   Language_From=L->Str;
   L=L->Next;
   Language_To=L->Str;
   L=L->Next;
   printf("Validating languages: %s and %s... ",Language_From,Language_To);
   if((DB=Goto_DB_Entry(Database[1],Language_From))&&(Goto_DB_Entry(Database[1],Language_To))){
      puts("Validated."); 
      printf("Translating: "); 
      PrintList(To_Translate);
      while(To_Translate){
	 Translate_From=To_Translate->Str;
	 Translate_To=NULL;
	 if((_=Find_List_Element(DB->DS[1],Language_To))>-1) Translate_To=Get_List_Element(DB->DS[2],_);
	 if(Translate_To)
	   Translated=Ins_List_Element(Translated,Translate_To,0);
	 printf("Translating %s to %s.\n",Translate_From,Translate_To);
	 To_Translate=To_Translate->Next;
      }
      puts("Translation possibilities:");
      Setup(Ins_List_Element(NULL,Language_To,0),NULL);
      Phrase_Generator(Translated,NULL);
      Setup(Ins_List_Element(NULL,Language_From,0),NULL);
   }
   else puts("Invalid language or language. Have you set them up??");
   return L;
}

/*! \brief Reconstruct a previously seen sentence.
 * 
 */
struct List_Str *Recollect(struct List_Str *WordList, struct List_Str *L){
   int Size=0;
   struct List_Str *Input=NULL,*Buffer=NULL;
   Input=WordList;
   Buffer=Input;
   while(Buffer){
      Size++;
      Buffer=Buffer->Next;
   }
   Permutation(Input,NULL,Size);
   return L;
}

/*! \brief Breaks up the sentences into parsable form.
 *  - Wraps IntelligentInt().
 */
struct List_Str *IWrapper(struct List_Str *Com){
  char *S=NULL;
  struct List_Str *List=NULL,*Buffer=NULL;
  while(Com){
    S=Com->Str;
    Com=Com->Next;
    if(List){ 
      while(List->Next) 
	List=List->Next; 
      List->Next=Expand_Exp(S); 
    } 
    else{ 
      List=Expand_Exp(S); 
      Buffer=List; 
    }  
  } 
  List=Buffer;
  return List;
}

/*! \brief Runs whatever task is overdue for execution in ENiX.
 *  
 */
struct List_Str *Scheduler(struct List_Str *Word_List,struct List_Str *L){
  int Position=0;
  unsigned long int TimeNow=0,ActivationTime=0,DeltaTime=0,NewTime=0;
  char *TimeToReplace=(char *)malloc(12*sizeof(char));
  struct List_Str *Q=NULL,*Expanded=NULL,*Command=NULL;
  struct Datablock *DB=GetScheduleRec();
  TimeNow=(unsigned long int)time(0);
  for(Q=DB->DS[1];Q;Q=Q->Next){
    Expanded=Str2List(Q->Str);
    ActivationTime=atol(Get_List_Element(Expanded,2));
    if(TimeNow>ActivationTime){
      DeltaTime=atol(Get_List_Element(Expanded,3));
      Command=Str2List(Get_List_Element(DB->DS[2],Position));
      IntelligentInt(Command,0);
      if(DeltaTime){
	NewTime=DeltaTime+ActivationTime;
	/* add it back into DS[1] */
	snprintf(TimeToReplace,11,"%ld",NewTime);
	TimeToReplace[11]=0;
	DB->DS[1]=Rep_List_Element(DB->DS[1],List2Str(Rep_List_Element(Expanded,TimeToReplace,2)),Position);
      }
      else{
	/* delete the scheduled activity */
	SchedDel(Str2List(Get_List_Element(Expanded,0)),NULL);
      }
    }
    Position++;
  }
  return L;
}

/*! \brief BreakCombSentence, break the combined sentence of conjoined and simple sentences into 
 *         conjoined and simple sentences connected via logic
 *  
 */
struct CombinedSentence *BreakCombSentence(struct List_Str *CombinedSentence){
  int _=0,TerminateClause=0,ClauseListSize=0,OxfordComma=0,IsComma=0,WasComma=0,IsConjunc=0,ThisContainsVerb=0,Logic=0;
  int PrevContainsVerb=0,NumSentences=0,OxfordCommaAnywhere=0;
  struct List_Str *Buffer=NULL,*SentenceSoFar=NULL,*ConjunctionsSoFar=NULL,**ClauseList=NULL;
  struct List_Str *Clause=NULL,**SentenceList=NULL;
  struct CombinedSentence *CSentence=(struct CombinedSentence *)malloc(sizeof(struct CombinedSentence));

  CSentence->Size=0;
  CSentence->Sentences=NULL;
  CSentence->Logic=4;

  for(Buffer=CombinedSentence;Buffer;Buffer=Buffer->Next){
    if(ExtractArticles(Str2List(Buffer->Str),"conjunction comma")){
      TerminateClause=1;
      ConjunctionsSoFar=Append_List_Element(ConjunctionsSoFar,Buffer->Str);
    }
    else if(ExtractArticles(Str2List(Buffer->Str),"exclamationmark fullstop questionmark"))
      TerminateClause=1;
    else
      SentenceSoFar=Append_List_Element(SentenceSoFar,Buffer->Str);
    if(TerminateClause){
      if(SentenceSoFar)
	ClauseList=Add_To_Array(ClauseList,SentenceSoFar,ClauseListSize++);
      if(ConjunctionsSoFar)
	ClauseList=Add_To_Array(ClauseList,ConjunctionsSoFar,ClauseListSize++);
      SentenceSoFar=NULL;
      ConjunctionsSoFar=NULL;
      TerminateClause=0;
    }
  }
  if(SentenceSoFar){
    ClauseList=Add_To_Array(ClauseList,SentenceSoFar,ClauseListSize++);
    if(ConjunctionsSoFar)
      ClauseList=Add_To_Array(ClauseList,ConjunctionsSoFar,ClauseListSize++);
  }

  /*
    If the clause is a comma and a conjunction, the sentence is ended
    If there are two clauses in a row containing verbs, the sentence is ended
   */

  SentenceSoFar=NULL;
  for(_=0;_<ClauseListSize;_++){
    Clause=ClauseList[_];
    if(ExtractArticles(Clause,"conjunction"))
      IsConjunc=1;
    if(Is_List_Element(Clause,","))
      IsComma=1;
    if(WasComma&&IsConjunc)
      OxfordCommaAnywhere=OxfordComma=1;
    if(ExtractArticles(Clause,"verb"))
      ThisContainsVerb=1;

    if((ThisContainsVerb&&PrevContainsVerb)||OxfordComma){
      SentenceList=Add_To_Array(SentenceList,SentenceSoFar,NumSentences++);
      if(OxfordComma){
	SentenceSoFar=NULL;
	/* Logic = 0:AND,1:OR,2:NOR,3:XOR,4:ERROR */
	if((Logic!=3)&&(Logic!=2)){
	  if(Is_List_Element(Clause,"or")||IsComma)
	    Logic=1;
	  else if(Is_List_Element(Clause,"and"))
	    Logic=0;
	}
	SentenceList[NumSentences-1]=Del_List_Element(SentenceList[NumSentences-1],Size_of_List(SentenceList[NumSentences-1])-1);
      }
      else{
	if(Is_List_Element(Clause,"either"))
	  Logic=3;
	else if(Is_List_Element(Clause,"neither"))
	  Logic=2;
	SentenceSoFar=Clause;
      }
    }
    else{
      if(!NumSentences){
	if(Is_List_Element(Clause,"either"))
	  Logic=3;
	else if(Is_List_Element(Clause,"neither"))
	  Logic=2;
      }
      SentenceSoFar=Ins_List_List(SentenceSoFar,Clause,Size_of_List(SentenceSoFar));
    }
    OxfordComma=0;
    PrevContainsVerb=ThisContainsVerb;
    ThisContainsVerb=0;
    WasComma=IsComma;
    IsComma=0;
    IsConjunc=0;
  }
  if(SentenceSoFar)
    SentenceList=Add_To_Array(SentenceList,SentenceSoFar,NumSentences++);
  if(OxfordCommaAnywhere&&(!strcmp(SentenceList[0]->Str,"neither")||(!strcmp(SentenceList[0]->Str,"either"))))
    SentenceList[0]=Del_List_Element(SentenceList[0],0);

  CSentence->Size=NumSentences;
  CSentence->Sentences=SentenceList;
  CSentence->Logic=Logic;

  return CSentence;
}

/*! \brief SplitConjSentences, break the list of conjoined and simple sentences into a list of 
 *         simple sentences connected via logic
 */
struct CombinedSentence *SplitConjSentences(struct CombinedSentence *Conjoined){
  int _=0,Logic=0;
  struct List_Str *ThisSentence=NULL,*BufferSubj=NULL,*BufferPred=NULL,*SimpleSentence=NULL;
  struct CombinedSentence *CSentence=(struct CombinedSentence *)malloc(sizeof(struct CombinedSentence));
  struct Sentence *DecodedSentence=NULL;

  CSentence->Size=0;
  CSentence->Sentences=NULL;
  CSentence->Logic=Conjoined->Logic;

  for(_=0;_<Conjoined->Size;_++){
    ThisSentence=Conjoined->Sentences[_];

    if(Is_List_Element(ThisSentence,"or")||Is_List_Element(ThisSentence,","))
      Logic=1;
    else if(Is_List_Element(ThisSentence,"and"))
      Logic=0;
    else if(Is_List_Element(ThisSentence,"either"))
      Logic=3;
    else if(Is_List_Element(ThisSentence,"neither"))
      Logic=2;
    
    if(ExtractArticles(ThisSentence,"conjunction")){
      DecodedSentence=ConvertSentence(ThisSentence,1,0);
      for(BufferSubj=DecodedSentence->RefinedSubject;BufferSubj;BufferSubj=BufferSubj->Next)
	for(BufferPred=DecodedSentence->RefinedPredicate;BufferPred;BufferPred=BufferPred->Next){
	  SimpleSentence=Convert2Sentence(CreateSentenceStruct(Append_List_Element(NULL,BufferSubj->Str),0,Append_List_Element(NULL,BufferPred->Str),0,DecodedSentence->RefinedVerb,0,"indicative"));
	  CSentence->Sentences=Add_To_Array(CSentence->Sentences,SimpleSentence,CSentence->Size++);
	}
    }
    else
      CSentence->Sentences=Add_To_Array(CSentence->Sentences,ThisSentence,CSentence->Size++);
  }

  /* the outter logic trumps the inner logic */
  if(Conjoined->Logic==4)
    CSentence->Logic=Logic;

  /*    
  printf("LOGIC FOUND: %d\n",CSentence->Logic);
  
  puts("Simple Sentences:");
  for(_=0;_<CSentence->Size;_++){
    PrintList(CSentence->Sentences[_]);
  }
  */
  
  return CSentence;
}


/*! \brief Return a CSValue that may be negated
 *  
 */
char *Sentence2NegCSVar(struct List_Str *S){
  int NotPosition=0;
  char *CSVar=NULL;
  struct List_Str *Negated=NULL,*SimpleSentence=NULL;
  struct Sentence *DecodedSentence=NULL;
  if((NotPosition=Find_List_Element(S,"not"))+1){
    Negated=Del_List_Element(Cpy_List(S),NotPosition);
    DecodedSentence=ConvertSentence(Negated,1,0);
    if(DecodedSentence->Understood){
      if(DecodedSentence->InterceptedSpirit==3)
	SimpleSentence=Convert2Sentence(CreateSentenceStruct(DecodedSentence->RefinedSubject,0,DecodedSentence->RefinedPredicate,0,VerbBaseFinder(DecodedSentence->RefinedVerb),0,"indicative"));
      else if(DecodedSentence->InterceptedSpirit==4)
	SimpleSentence=Convert2Sentence(CreateSentenceStruct(DecodedSentence->RefinedSubject,0,DecodedSentence->RefinedPredicate,0,VerbBaseFinder(DecodedSentence->RefinedVerb),0,"imperative"));	
      CSVar=StrCat("n",CSCreate(SimpleSentence));
    }
    else
      CSVar=CSCreate(Negated);
  }
  else{
    DecodedSentence=ConvertSentence(S,1,0);
    if(DecodedSentence->Understood){
      if(DecodedSentence->InterceptedSpirit==3)
	SimpleSentence=Convert2Sentence(CreateSentenceStruct(DecodedSentence->RefinedSubject,0,DecodedSentence->RefinedPredicate,0,VerbBaseFinder(DecodedSentence->RefinedVerb),0,"indicative"));
      else if(DecodedSentence->InterceptedSpirit==4)
	SimpleSentence=Convert2Sentence(CreateSentenceStruct(DecodedSentence->RefinedSubject,0,DecodedSentence->RefinedPredicate,0,VerbBaseFinder(DecodedSentence->RefinedVerb),0,"imperative"));
      CSVar=CSCreate(SimpleSentence);
    }
    else
      CSVar=CSCreate(S);
  }
  return CSVar;
}


/*! \brief SeparateConditional, break the conditional down into largest component sentences.
 *  
 */
struct Conditional *SeparateConditional(struct Conditional *ConditionalLogic){
  int _=0,SentenceType=0,Previous=-1;
  char *PossiblyNegCSSymbol=NULL;
  struct List_Str *ConditionalCauses=NULL,*ConditionalEffects=NULL,*Buffer=NULL;
  struct List_Str *CauseSentence=NULL,*EffectSentence=NULL,*SentenceSoFar=NULL;
  struct List_Str *CauseSymbols=NULL,*EffectSymbols=NULL;
  struct Datablock *LangRecord=GetLang();
  struct CombinedSentence *CauseComb=NULL,*EffectComb=NULL;
  
  if(LangRecord){
    ConditionalCauses=Str2List(Lookup_DB_Attr(LangRecord,":setcondcause",NULL));
    ConditionalEffects=Str2List(Lookup_DB_Attr(LangRecord,":setcondeffect",NULL));
  }
  else
    return ConditionalLogic;
  if((!IntIntersect(ConditionalLogic->OriginalData,ConditionalCauses))&&(!IntIntersect(ConditionalLogic->OriginalData,ConditionalEffects)))
    return ConditionalLogic;

  /*
  DEBUG;
  PrintList(ConditionalLogic->OriginalData);
  */

  for(Buffer=ConditionalLogic->OriginalData;Buffer;Buffer=Buffer->Next){
    if(Is_List_Element(ConditionalCauses,Buffer->Str))
      SentenceType=1;
    else if(Is_List_Element(ConditionalEffects,Buffer->Str))
      SentenceType=2;
    else{
      if(Previous>0)
	SentenceSoFar=Append_List_Element(SentenceSoFar,Buffer->Str);
    }
    if(Previous!=SentenceType){
      if(Previous==1){
	CauseSentence=SentenceSoFar;
	SentenceSoFar=NULL;
      }
      else if(Previous==2){
	EffectSentence=SentenceSoFar;
	SentenceSoFar=NULL;
      }
    }      
    Previous=SentenceType;
  }
  if(Previous==1)
    CauseSentence=SentenceSoFar;
  else if(Previous==2)
    EffectSentence=SentenceSoFar;

  if(CauseSentence)
    if((CauseComb=BreakCombSentence(CauseSentence)))
      CauseComb=SplitConjSentences(CauseComb);

  if(EffectSentence)
    if((EffectComb=BreakCombSentence(EffectSentence)))
      EffectComb=SplitConjSentences(EffectComb);

  if(CauseComb){
    ConditionalLogic->CauseLogic=CauseComb->Logic;
    ConditionalLogic->NumCauses=CauseComb->Size;
    ConditionalLogic->CauseSentences=CauseComb->Sentences;
    /* we need to exclude negated cause sentences */
    for(_=0;_<CauseComb->Size;_++){
      PossiblyNegCSSymbol=Sentence2NegCSVar(CauseComb->Sentences[_]);
      if(strncmp(PossiblyNegCSSymbol,"ncs",3))
	CauseSymbols=Append_List_Element(CauseSymbols,Sentence2NegCSVar(CauseComb->Sentences[_]));
    }
    /* if we dropped them all then we need to having "nothing" as a cause sentence */
    if(!CauseSymbols)
      CauseSymbols=Append_List_Element(CauseSymbols,"nothing");
    ConditionalLogic->CauseSymbols=SortList(CauseSymbols);
  }
  else{
    ConditionalLogic->CauseLogic=0;
    ConditionalLogic->NumCauses=0;
    ConditionalLogic->CauseSentences=NULL;
    ConditionalLogic->CauseSymbols=NULL;
  }
  if(EffectComb){
    ConditionalLogic->EffectLogic=EffectComb->Logic;
    ConditionalLogic->NumEffects=EffectComb->Size;
    ConditionalLogic->EffectSentences=EffectComb->Sentences;
    for(_=0;_<EffectComb->Size;_++){
      EffectSymbols=Append_List_Element(EffectSymbols,Sentence2NegCSVar(EffectComb->Sentences[_]));
    }
    ConditionalLogic->EffectSymbols=SortList(EffectSymbols);
  }
  else{
    ConditionalLogic->EffectLogic=0;
    ConditionalLogic->NumEffects=0;
    ConditionalLogic->EffectSentences=NULL;
    ConditionalLogic->CauseSymbols=NULL;
  }

  /* Is active, is conditional, is question? */
  ConditionalLogic->IsActive=1;
  ConditionalLogic->IsQuestion=Is_List_Element(ConditionalLogic->OriginalData,"?");
  ConditionalLogic->IsConditional=1;

  /* nounlist and verblist */
  
  return ConditionalLogic;
}

/*! \brief Convert conditional subjunctive sentences into a group of sentences connected via logic.
 *  
 */
struct Conditional *ConvertConditional(struct List_Str *SentenceData){
  struct Conditional *ConditionalLogic=(struct Conditional *)malloc(sizeof(struct Conditional));
  ConditionalLogic->OriginalData=SentenceData;
  ConditionalLogic->IsQuestion=0;
  ConditionalLogic->IsActive=0;
  ConditionalLogic->NumCauses=0;
  ConditionalLogic->NumEffects=0;
  ConditionalLogic->EffectSentences=NULL;
  ConditionalLogic->CauseSentences=NULL;
  ConditionalLogic->EffectSymbols=NULL;
  ConditionalLogic->CauseSymbols=NULL;
  ConditionalLogic->CauseLogic=0;
  ConditionalLogic->EffectLogic=0;
  ConditionalLogic->AnswerLogic=4;
  ConditionalLogic->Answer=NULL;
  ConditionalLogic=SeparateConditional(ConditionalLogic);
  return ConditionalLogic;
}

/*! \brief PrepareConditional needs to multiplex the conditional sentences ready for query.
 *  - NOTE INCOMPLETE
 */
struct Conditional *ProcessConditional(struct Conditional *Cond){
  struct List_Str *Answer=NULL,*Buffer=NULL;
  if(Cond->IsQuestion){
    if(Cond->NumCauses||Cond->NumEffects){
      if(Cond->NumCauses&&Cond->NumEffects){
	if(LookupYNQConditional(Cond))
	  puts("Yes.");
	else
	  puts("No.");
      }
      else{
	Cond=WrapWHQConditional(Cond);
	if(Cond->Answer)
	  for(Answer=Cond->Answer;Answer;Answer=Answer->Next){
	    for(Buffer=Str2List(Answer->Str);Buffer;Buffer=Buffer->Next){
	      PrintListSpecial("",IntCSRecon(Buffer->Str)," "," "," ");
	      if(Buffer->Next){
		if(Buffer->Next->Next)
		  printf(", ");
		else
		  printf("and ");
	      }
	    }
	    if(Answer->Next)
	      puts("");
	  }
	else
	  puts("Nothing happens.");
      }
    }
  }
  else
    CacheConditional(Cond);
  return Cond;
}

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.a
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP


 */
