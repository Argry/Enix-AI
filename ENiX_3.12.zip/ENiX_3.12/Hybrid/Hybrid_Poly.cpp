/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

*/

#include <cstdio>
#include <cmath>
#include "Hybrid_Poly.h"

/*! \brief Determine if the theorised polynomial solves the problem.
 *
 */
bool Polynomial::IsLearnt(){  
  return Execute(0,InitialData.Size).Equal(InitialData);
}

/*! \brief Execute the polynomial at a known ordinate.
 *
 */
double Polynomial::ExecuteAt(double x){
  double y=0;
  for(unsigned long int i=0;i<Coefficients.size();i++)
    y+=Coefficients[i]*pow(x,i);
  return y;  
}

/*! \brief Obtain a list of ordinates calculated from the polynomial.
 * - Start is the initial x position.
 * - Finish is the final x position.
 */
Line Polynomial::Execute(unsigned long int Start,unsigned long int Finish){
  Line Sequence(Finish-Start);
  for(unsigned long int i=Start;i<Finish;i++)
    Sequence.Elements[i-Start]=ExecuteAt((double)i);
  return Sequence;
}

/*! \brief Print a polynomial from a coefficient.
 * 
 */
void Polynomial::Print(vector <double> V){
  bool First=1,Printed=0;
  for(unsigned long int i=0;i<V.size();i++){
    if((V[i]>0)&&(!First))
      putchar('+');
    if(V[i]==-1&&(!First))
      putchar('-');
    if(V[i]){
      if((V[i]!=1&&V[i]!=-1)||(i==0))
	cout<< V[i];
      if(i)
	putchar('n');
      if(i>1)
	printf("^%ld",i);
      First=0;
      Printed=1;
    }
  }
  if(!Printed)
    putchar('0');
}

/*! \brief Print a polynomial from the polynomial data and prepend the function.
 * 
 */
void Polynomial::Print(){
  printf("f(n)=");
  Print(Coefficients);
  putchar('\n');  
}

/*! \brief Compute the difference between elements in a line where they are known.
 * 
 */
Line Polynomial::Difference(Line L){
  Line NewLine(L.Size-1);
  for(unsigned long int i=0;i<L.Size-1;i++){
    if(L.Unknowns[i]||L.Unknowns[i+1]){
      NewLine.Unknowns[i]=1;
      NewLine.Elements[i]=0;
    }
    else{
      NewLine.Unknowns[i]=0;
      NewLine.Elements[i]=L.Elements[i+1]-L.Elements[i];
    }
  }
  return NewLine;
};

/*! \brief Compute the factorial of a number.
 * 
 */
double Polynomial::Factorial(unsigned long int C){
  double F=1;
  for(;C;C--)
    F*=C;
  return F;
}

/*! \brief Get the coefficient of a exponent term.
 *  - This should only be called from Generate().
 */
double Polynomial::GetCoefficient(Line L,unsigned long int Level){
  return L.GetValue()/Factorial(Level);
}

/*! \brief Calculate polynomial ordinates from specified coefficients and length.
 * 
 */
Line Polynomial::CalcPoly(vector <double> Coeffs, unsigned long int Length){
  Line Return(Length);
  for(unsigned long int x=0;x<Length;x++)
    Return.Elements[x]=ExecuteAt(x);
  return Return;
}

/*! \brief Actually generate the polynomial from the line data initialised in the class.
 * 
 */
void Polynomial::Generate(){
  unsigned long int Level=0;
  Line NewLine=InitialData;
  Coefficients.resize(InitialData.Size,0);
  Coefficients=NewLine.Zero(Coefficients);
  while(NewLine.Size>1){  
    if(NewLine.Equal()){
      if(NewLine.GetValue()==0)
	return;
      Coefficients[Level]=GetCoefficient(NewLine,Level);
      NewLine=InitialData.Subtract(CalcPoly(Coefficients,InitialData.Size));
      Level=0;
      continue;
    }
    NewLine=Difference(NewLine);
    Level++;
  }
}

/*
888 888           888             ,e,      888   ,8,"88e  
888 888 Y8b Y888P 888 88e  888,8,  "   e88 888    "  888D 
8888888  Y8b Y8P  888 888b 888 "  888 d888 888       88P  
888 888   Y8b Y   888 888P 888    888 Y888 888      ,*"   
888 888    888    888 88"  888    888  "88 888    8888888 
           888                                            
           888                                            
 */
