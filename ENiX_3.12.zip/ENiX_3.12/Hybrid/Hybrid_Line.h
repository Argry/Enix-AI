/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

*/

#include <iostream>
#include <vector>

#ifndef HYBRID_LINE
#define HYBRID_LINE

using namespace std;

/*! \brief Line data is a datatype that records a vector of doubles and records if these doubles are known.
 *
 */
class Line{
public:
  unsigned long int Size;
  vector <double> Elements;
  vector <bool>   Unknowns;
  Line();
  Line(unsigned long int Init);
  void Input(vector <string> V);
  void Print();
  bool Equal();
  bool Equal(Line Other);
  Line Subtract(Line Sub);
  double GetValue();
  void PrintVector(vector <double> V);
  bool IsZero(vector <double> V);
  double FirstNonZero(vector <double> V);
  vector <double> Zero(vector <double> V);
  vector <double> ConvertFromString(vector <string> V);
};

#endif

/*
888 888           888             ,e,      888   ,8,"88e  
888 888 Y8b Y888P 888 88e  888,8,  "   e88 888    "  888D 
8888888  Y8b Y8P  888 888b 888 "  888 d888 888       88P  
888 888   Y8b Y   888 888P 888    888 Y888 888      ,*"   
888 888    888    888 88"  888    888  "88 888    8888888 
           888                                            
           888                                            
 */
