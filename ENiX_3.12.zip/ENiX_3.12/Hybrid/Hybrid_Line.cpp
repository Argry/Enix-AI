/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

*/

#include <cstdio>
#include <cstdlib>
#include "Hybrid_Line.h"

/*! \brief Finds the first non-zero element of V.
 *
 */
double Line::FirstNonZero(vector <double> V){
  double R=0;
  for(unsigned long int i=0;i<V.size();i++)
    if(V[i]){
      R=V[i];
      break;
    }
  return R;
}

/*! \brief Converts vector of strings to a vector of doubles.
 *
 */
vector <double> Line::ConvertFromString(vector <string> V){
  vector <double> NumVec;
  for(unsigned long int i=0;i<V.size();i++)
    NumVec.push_back(atof(V[i].c_str()));
  return NumVec;
}

/*! \brief Determines if a vector is zero throughout.
 *
 */
bool Line::IsZero(vector <double> V){
  for(unsigned long int i=0;i<V.size();i++)
    if(V[i])
      return 0;
  return 1;
}

/*! \brief Zeros a vector V.
 *
 */
vector <double> Line::Zero(vector <double> V){
  for(unsigned long int i=0;i<V.size();i++)
    V[i]=0;
  return V;
}

/*! \brief Prints a vector V.
 *
 */
void Line::PrintVector(vector <double> V){
  for(unsigned long int i=0;i<V.size();i++)
    cout << V[i] << " ";
  putchar('\n');
}

/*! \brief Determines if two vectors are equal.
 *
 */
bool Line::Equal(Line Other){
  unsigned long int Shortest=(Size>Other.Size)?Other.Size:Size;
  for(unsigned long int i=0;i<Shortest;i++)
    if((!Other.Unknowns[i])&&(!Unknowns[i]))
      if(Other.Elements[i]!=Elements[i])
	return 0;
  return 1;
}

/*! \brief Obtain the first known value for the Line data.
 *  - Used with Equal.
 */
double Line::GetValue(){
  for(unsigned long int i=0;i<Size;i++)
    if(!Unknowns[i])
      return Elements[i];
  return 0;
}

/*! \brief Subtract a line Sub from the line data.
 *  
 */
Line Line::Subtract(Line Sub){
  unsigned long int Shortest=(Size>Sub.Size)?Sub.Size:Size;
  Line Difference(Shortest);
  for(unsigned long int i=0;i<Shortest;i++){
    if(Unknowns[i]||Sub.Unknowns[i])
      Difference.Unknowns[i]=1;
    else
      Difference.Elements[i]=Elements[i]-Sub.Elements[i];      
  }
  return Difference;
}

/*! \brief Determine if the line is the same throughout all known values.
 *  
 */
bool Line::Equal(){
  for(unsigned long int i=1;i<Size;i++){
    if((!Unknowns[i])&&(!Unknowns[i-1]))
      if(Elements[i]!=Elements[i-1])
	return 0;
  }
  return 1;
}

/*! \brief Populate the line data with the input vector V.
 *  
 */
void Line::Input(vector <string> V){
  Size=V.size();
  for(unsigned long int i=0;i<V.size();i++){
    if(V[i].compare("?")){
      Unknowns.push_back(0);
      Elements.push_back(atof(V[i].c_str()));
    }
    else{
      Unknowns.push_back(1);
      Elements.push_back(0);
    }
  }
}

/*! \brief Initialise the line data to size 0.
 *  
 */
Line::Line(){
  Size=0;
}

/*! \brief Initialise the line data to a particular length Init.
 *  
 */
Line::Line(unsigned long int Init){
  Elements.resize(Init,0);
  Unknowns.resize(Init,0);
  Size=Init;
}

/*! \brief Print the line data.
 *  
 */
void Line::Print(){
  for(unsigned long int i=0;i<Size;i++){
    if(Unknowns[i])
      printf("? ");
    else
      cout << Elements[i] << " ";
  }
  putchar('\n');
}

/*
888 888           888             ,e,      888   ,8,"88e  
888 888 Y8b Y888P 888 88e  888,8,  "   e88 888    "  888D 
8888888  Y8b Y8P  888 888b 888 "  888 d888 888       88P  
888 888   Y8b Y   888 888P 888    888 Y888 888      ,*"   
888 888    888    888 88"  888    888  "88 888    8888888 
           888                                            
           888                                            
 */
