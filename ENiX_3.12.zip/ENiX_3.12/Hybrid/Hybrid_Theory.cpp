/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

*/

#include <cstdio>
#include "Hybrid_Theory.h"
#include "Hybrid_Chaos.h"
#include "Hybrid_Rec.h"
#include "Hybrid_Poly.h"
#include "Hybrid_Line.h"


/*! \brief Deducts the theorised recurrence relation from the data to leave a polynomial sequence.
 *
 */
Line Hybrid::DeductRecurrence(){
  Line R(InitialData.Size);
  if(R.IsZero(RecForm))
    return InitialData;
  vector <double> Return(InitialData.Size,0);
  Return[0]=InitialData.Elements[0];
  R.Elements[0]=InitialData.Elements[0]-1;
  RecForm.resize(Return.size(),0);
  for(unsigned long int End=1;End<Return.size();End++){
    for(unsigned long int Pos=0;Pos<End;Pos++)
      Return[End]+=RecForm[Pos]*Return[End-Pos-1];
    R.Elements[End]=InitialData.Elements[End]-Return[End];
  }
  return R;
}

/*! \brief The Omega function attempts to determine if all the recurrence terms have been removed.
 *
 */
bool Hybrid::Omega(vector <double> V){
  bool FirstTerm=1;
  double PrevOmega=0,ThisOmega=0;
  unsigned long int Good=0,Bad=0;
  for(unsigned long int i=1;i<V.size();i++){
    if(V[i-1])
      ThisOmega=V[i]/V[i-1];
    else
      ThisOmega=0;
    ThisOmega=ThisOmega>0?ThisOmega:-ThisOmega;
    if(!FirstTerm)
      if(ThisOmega>PrevOmega)
	Bad++;
    if(ThisOmega<Threshold+1)
      Good++;
    cout << ThisOmega << " ";
    PrevOmega=ThisOmega;
    FirstTerm=0;
  }
  printf("\nGood: %ld Bad:%ld\n",Good,Bad);
  if(Good && (!Bad))
    return 1;
  return 0;
}

/*! \brief Prints a hybrid formula.
 *
 */
void Hybrid::Print(){
  bool RecExists=0;
  Recurrence Rec;
  Polynomial Poly;
  Line NewLine;
  printf("M(n)=");
  if(!NewLine.IsZero(RecForm)){
    Rec.Print(RecForm);
    RecExists=1;
  }
  if((!NewLine.IsZero(PolyForm))||(!RecExists)){
    if(RecExists&&(NewLine.FirstNonZero(PolyForm)>0))
      putchar('+');
    Poly.Print(PolyForm);
  }
  putchar('\n');
}

/*! \brief Actually generates a hybrid formula.
 *
 */
unsigned long int Hybrid::Generate(){
  unsigned long int NumFound=0;
  Chaos Entropy(-2,2,1,3);
  Line Diff;
  Recurrence Rec;
  Polynomial Poly;
  Rec.InitialData=InitialData;
  do{
    Rec.Coefficients=Entropy.Coefficients;
    RecForm=Entropy.Coefficients;
    Diff=DeductRecurrence();
    Poly.InitialData=Diff;
    Poly.Generate();
    PolyForm=Poly.Coefficients;
    if(Poly.IsLearnt()){
      printf(" -> "); Print();
      NumFound++;
    }
  }while(Entropy.Iterate());
  return NumFound;
}

/*! \brief Scan through a range of formulae for identities.
 *  - This was a hypothesis which has been proved wrong now.
 */
void Hybrid::Scan(){
  unsigned long int Length=6;
  unsigned long int SeqLength=10;
  unsigned long int NumFound=0;
  Chaos Entropy(-2,2,1,Length);
  Line NewLine;
  PolyForm.resize(SeqLength,0);
  RecForm.resize(SeqLength,0);
  puts("Scanning for identities:");
  do{    
    PolyForm=NewLine.Zero(PolyForm);
    RecForm=NewLine.Zero(RecForm);
    unsigned long int i=0;
    for(;i<(Length>>1);i++)
      PolyForm[i]=Entropy.Coefficients[i];
    for(;i<Length;i++)
      RecForm[i-(Length>>1)]=Entropy.Coefficients[i];
    printf("\nScanning for: ");Print();
    (InitialData=Execute(SeqLength)).Print();
    if((NumFound=Generate())>1)
      printf("Results found: %ld\n",NumFound);
  }while(Entropy.Iterate());
}

/*! \brief Execute the hybrid formula between 0 and Finish.
 *  
 */
Line Hybrid::Execute(unsigned long int Finish){
  Line R(Finish);
  Polynomial Poly;
  vector <double> Return(Finish,0);
  RecForm.resize(Finish,0);
  Poly.Coefficients=PolyForm;
  Poly.Coefficients.resize(Finish,0);
  if(R.IsZero(RecForm))
    return Poly.Execute(0,Finish);
  R.Elements[0]=Poly.ExecuteAt(0)+1;
  Return[0]=R.Elements[0];
  for(unsigned long int End=1;End<Finish;End++){
    for(unsigned long int Pos=0;Pos<End;Pos++)
      Return[End]+=RecForm[Pos]*Return[End-Pos-1];
    R.Elements[End]=Return[End]+Poly.ExecuteAt(End);
  }
  return R;
}

/*
888 888           888             ,e,      888   ,8,"88e  
888 888 Y8b Y888P 888 88e  888,8,  "   e88 888    "  888D 
8888888  Y8b Y8P  888 888b 888 "  888 d888 888       88P  
888 888   Y8b Y   888 888P 888    888 Y888 888      ,*"   
888 888    888    888 88"  888    888  "88 888    8888888 
           888                                            
           888                                            
 */
