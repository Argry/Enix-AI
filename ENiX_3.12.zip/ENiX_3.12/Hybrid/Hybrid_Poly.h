/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

*/

#include "Hybrid_Line.h"

#ifndef HYBRID_POLY
#define HYBRID_POLY

using namespace std;

/*! \brief This class holds the information necessary to process polynomials.
 *
 */
class Polynomial{
public:
  Line InitialData;
  vector <double> Coefficients;
  Polynomial(){}
  Polynomial(vector <string> V){ InitialData.Input(V); }
  Polynomial(Line V){ InitialData=V; }
  void Generate();
  void Print();
  void Print(vector <double> V);
  Line Execute(unsigned long int Start,unsigned long int Finish);
  bool IsLearnt();
  double ExecuteAt(double x);
private:
  double GetCoefficient(Line L,unsigned long int Level);
  double Factorial(unsigned long int C);
  Line Difference(Line L);
  Line CalcPoly(vector <double> Coeffs,unsigned long int Length);
};

#endif

/*
888 888           888             ,e,      888   ,8,"88e  
888 888 Y8b Y888P 888 88e  888,8,  "   e88 888    "  888D 
8888888  Y8b Y8P  888 888b 888 "  888 d888 888       88P  
888 888   Y8b Y   888 888P 888    888 Y888 888      ,*"   
888 888    888    888 88"  888    888  "88 888    8888888 
           888                                            
           888                                            
 */
