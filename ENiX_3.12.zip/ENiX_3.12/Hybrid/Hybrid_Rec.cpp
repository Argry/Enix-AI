/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

*/

#include <cstdio>
#include "Hybrid_Rec.h"

/*! \brief Determines if the recurrence relation solves the problem.
 *
 */
bool Recurrence::IsLearnt(){
  return Execute(0,InitialData.Size).Equal(InitialData);
}

/*! \brief Print a recurrence relation from the data V.
 *
 */
void Recurrence::Print(vector <double> V){
  bool FirstTerm=1;
  for(unsigned long int i=0;i<V.size();i++){
    if(V[i]){
      if((V[i]>0)&&(!FirstTerm))
	putchar('+');
      if(V[i]==-1)
	putchar('-');
      if((V[i]!=1)&&(V[i]!=-1))
	cout<< V[i]<<"*";
      printf("M[n-%ld]",i+1);
      FirstTerm=0;
    }
  }
}

/*! \brief Print the recurrence relation with function name.
 *
 */
void Recurrence::Print(){
  bool FirstTerm=1;
  printf("R[n]=");
  Print(Coefficients);
  putchar('\n');
}

/*! \brief Generate the recurrence relation.
 *
 */
void Recurrence::Generate(){
  double Number=0;
  Coefficients.resize(InitialData.Size,0);
  for(unsigned long int End=1;End<InitialData.Size;End++){
    Number=InitialData.Elements[End];
    for(unsigned long int i=1;i<End;i++)
      Number-=(InitialData.Elements[End-i]*Coefficients[i-1]);
    Coefficients[End-1]=(Number/InitialData.Elements[End-1]);
  }
}

/*! \brief Execute the recurrence relation upto x from a known ordinate R0.
 *
 */
vector <double> Recurrence::ExecuteTo(unsigned long int x,double R0){
  vector <double> Return(x,0);
  Return[0]=R0;
  for(unsigned long int End=1;End<Return.size();End++)
    for(unsigned long int Pos=0;Pos<End;Pos++)
      Return[End]+=Coefficients[Pos]*Return[End-Pos-1];
  return Return;
}

/*! \brief Execute the recurrence relation between an interval.
 * - Start is the beginning of the ordinates.
 * - Finish is the end of the ordinates.
 */
Line Recurrence::Execute(unsigned long int Start,unsigned long int Finish){
  Line Range(Finish-Start);
  vector <double> Sequence=ExecuteTo(Finish,InitialData.Elements[0]);
  for(unsigned long int i=Start;i<Finish;i++)
    Range.Elements[i-Start]=Sequence[i];
  return Range;
}


/*
888 888           888             ,e,      888   ,8,"88e  
888 888 Y8b Y888P 888 88e  888,8,  "   e88 888    "  888D 
8888888  Y8b Y8P  888 888b 888 "  888 d888 888       88P  
888 888   Y8b Y   888 888P 888    888 Y888 888      ,*"   
888 888    888    888 88"  888    888  "88 888    8888888 
           888                                            
           888                                            
 */
