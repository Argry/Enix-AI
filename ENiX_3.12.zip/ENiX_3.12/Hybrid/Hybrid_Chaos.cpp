/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

*/

#include <cstdio>
#include "Hybrid_Chaos.h"

/*! \brief Initialises the Chaos library.
 * - SetMin is the lowest value an element can be.
 * - SetMax is the highest value an element can be.
 * - SetGranularity is the granularity steps between SetMin and SetMax.
 * - Length is the number of elements in the vector.
 */
Chaos::Chaos(double SetMin,double SetMax,double SetGranularity,unsigned long int Length){
  Coefficients.resize(Length,SetMin);
  Min=SetMin;
  Max=SetMax;
  Granularity=SetGranularity;
}

/*! \brief Iterates the Chaos Coefficients vector by 1 carrying over where necessary.
 * 
 */
bool Chaos::Iterate(){
  for(unsigned long int i=0;i<Coefficients.size();i++){
    if(Coefficients[i]<Max){
      Coefficients[i]+=Granularity;
      return 1;
    }
    else
      Coefficients[i]=Min;
  }
  return 0;
}

/*! \brief Displays the Chaos vector to the user.
 * 
 */
void Chaos::Print(){
  for(unsigned long int i=0;i<Coefficients.size();i++)
    cout << Coefficients[i] << " ";
  putchar('\n');
}

/*
888 888           888             ,e,      888   ,8,"88e  
888 888 Y8b Y888P 888 88e  888,8,  "   e88 888    "  888D 
8888888  Y8b Y8P  888 888b 888 "  888 d888 888       88P  
888 888   Y8b Y   888 888P 888    888 Y888 888      ,*"   
888 888    888    888 88"  888    888  "88 888    8888888 
           888                                            
           888                                            
 */

