/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

*/

#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <string.h>

#include "Hybrid_Poly.h"
#include "Hybrid_Rec.h"
#include "Hybrid_Chaos.h"
#include "Hybrid_Theory.h"

using namespace std;

/*! \brief Class containing user accessible features.
 *
 */
class TopLevel{
public:
  void GeneratePolynomial(vector <string> Params);
  void GenerateRecurrence(vector <string> Params);
  void GenerateHybrid(vector <string> Params);
  void EvaluatePolynomial(vector <string> Params);
  void EvaluateRecurrence(vector <string> Params);
  void Help();
  void TestChaos();
  void ParseCLIOptions(int ArgNum, char *Args[]);
};

/*! \brief Evaluates the specified polynomial.
 *
 */
void TopLevel::EvaluatePolynomial(vector <string> Params){
  Polynomial Poly;
  Line L;
  Poly.Coefficients=L.ConvertFromString(Params);
  Poly.Print();
  Poly.Execute(0,10).Print();  
}

/*! \brief Evaluates the specified recurrence.
 *
 */
void TopLevel::EvaluateRecurrence(vector <string> Params){
  Recurrence Rec;
  Line L(1);
  L.Elements[0]=1;
  Rec.InitialData=L;
  Rec.Coefficients=L.ConvertFromString(Params);
  Rec.Print();
  Rec.Execute(0,10).Print();  
}

/*! \brief Parses the CLI options.
 *
 */
void TopLevel::ParseCLIOptions(int ArgNum, char *Args[]){
  bool Option=0;
  unsigned long int Pos=0;
  int Choice=0;
  vector <string> Params;
  string Tmp;
  for(int i=1;i<ArgNum;i++){
    Tmp=Args[i];
    Option=0;
    if((Tmp=="--help") || (Tmp=="-h")){
      Help();
    }
    if(Tmp=="SOLVEREC"){
      Option=1;
      Choice=1;
    }
    if(Tmp=="SOLVEPOLY"){
      Option=1;
      Choice=2;
    }
    if(Tmp=="SOLVEHYBRID"){
      Option=1;
      Choice=3;
    }
    if(Tmp=="GENPOLY"){
      Option=1;
      Choice=4;
    }
    if(Tmp=="GENREC"){
      Option=1;
      Choice=5;
    }
    if(!Option)
      Params.push_back(Args[i]);
  }
  switch(Choice){
  case 0:
    Help();
  case 1:
    GenerateRecurrence(Params);
    break;
  case 2:
    GeneratePolynomial(Params);
    break;
  case 3:
    GenerateHybrid(Params);
    break;
  case 4:
    EvaluatePolynomial(Params);
    break;
  case 5:
    EvaluateRecurrence(Params);
    break;
  }
}

/*! \brief Displays available options.
 *
 */
void TopLevel::Help(){
  puts("\nUsage:");
  puts("\t-h,--help\t\tShow this help menu");
  puts("\tGENPOLY\t\t\tGenerate a sequence from a polynomial");
  puts("\tGENREC\t\t\tGenerate a sequence from a recurrence relation");
  puts("\tSOLVEREC\t\tCalculate a recurrence relation");
  puts("\tSOLVEPOLY\t\tCalculate polynomial");
  puts("\tSOLVEHYBRID\t\tCalculate hybrid equation");
  puts("\nExamples:");
  puts("\tHybrid.bin SOLVEREC 1 1 2 3 5 8 13 21");
  puts("\t -> M(n)=M[n-1]+M[n-2]\n");
  puts("\tHybrid.bin SOLVEHYBRID -1 1 0 9 10 31 22 63 38 119");
  puts("\t -> M(n)=-2*M[n-1]-2*M[n-2]-2*M[n-3]-2+n^2\n");
  puts("\tHybrid.bin SOLVEPOLY -2 1 8 19 34 53 76 103");
  puts("\t -> f(n)=-2+n+2n^2\n");
  exit(0);
}

/*! \brief Testing function for the Chaos library.
 *
 */
void TopLevel::TestChaos(){
  Chaos NewChaos(-5,5,1,5);
  do
    NewChaos.Print();
  while(NewChaos.Iterate());
}

/*! \brief Accepts CLI input and generates a hybrid formula - if possible.
 *
 */
void TopLevel::GenerateHybrid(vector <string> Params){
  if(Params.size()>1){
    Hybrid Composite(Params);
    Composite.Generate();
  }
  else{
    Hybrid Composite;
    Composite.Scan();
  }
}

/*! \brief Accepts CLI input and generates a recurrence relation - if possible.
 *
 */
void TopLevel::GenerateRecurrence(vector <string> Params){
  Recurrence Rec(Params);
  Rec.Generate();
  Rec.Print();
  if(Rec.IsLearnt())
    puts(":)");
  else
    puts("Something went wrong :(");
}

/*! \brief Accepts CLI input and generates a polynomial - if possible.
 *
 */
void TopLevel::GeneratePolynomial(vector <string> Params){
  Polynomial Poly(Params);
  Poly.Generate();
  Poly.Print();
  if(Poly.IsLearnt())
    puts(":)");
  else
    puts("Something went wrong :(");
}

/*! \brief Bootstraps ENiX 3 Hybrid 2.
 *
 */
int main(int ArgNum, char *Args[]){
  TopLevel Init;
  Init.ParseCLIOptions(ArgNum,Args);
  return 0;
}

/*
888 888           888             ,e,      888   ,8,"88e  
888 888 Y8b Y888P 888 88e  888,8,  "   e88 888    "  888D 
8888888  Y8b Y8P  888 888b 888 "  888 d888 888       88P  
888 888   Y8b Y   888 888P 888    888 Y888 888      ,*"   
888 888    888    888 88"  888    888  "88 888    8888888 
           888                                            
           888                                            
 */
