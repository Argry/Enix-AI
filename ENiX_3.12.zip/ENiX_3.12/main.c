/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2013.

*/

#include<stdio.h>
#include<math.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>

#include "ENiX_Globals.h"
#include "ENiX_STRING.h"
#include "ENiX_CALC.h"
#include "ENiX_LIST.h"
#include "ENiX_TIME.h"
#include "ENiX_WMS.h"
#include "ENiX_WMS_COMPAT.h"
#include "ENiX_DISK.h"
#include "ENiX_CS.h"
#include "ENiX_NLP.h"
#include "ENiX_SCOPE.h"
#include "ENiX_EMO.h"
#include "ENiX_STEMMER.h"
#include "ENiX_EXEC.h"
#include "ENiX_SPLINE.h"
#include "ENiX_HLR.h"
#include "ENiX_ANALYSER.h"
#include "ENiX_MUSIC.h"
#include "ENiX_REASON.h"
#include "ENiX_SETTHEORY.h"
#include "ENiX_SEMANTICS.h"
#include "ENiX_ROBOTICS.h"
#include "ENiX_APPLICATIONS.h"
#include "ENiX_OUTPUT.h"
#include "ENiX_MULTIPLEX.h"
#include "ENiX_PLURALS.h"
#include "ENiX_CONV.h"
#include "Amoeba-API.h"


char             *ProgramName;
char             *Data;

int     ENABLEOUT=1;
int     Suppress_ANSWER=0;

struct List_Str  *Test(struct List_Str *Word_List,struct List_Str *L);

/*! \brief List of pointers to functions that constitute the ENiX 3 Instruction Set.
 *
 */
struct List_Str  *(*InstructionSet[])(struct List_Str *ContextPrefix,struct List_Str *ContextSuffix)=
{
  AAVF,Add,AddEmotions,AddEmoDebug,AddScope,AddWRef,All,AllRels,AND,Answer,Append,APVF,
  Argue,AssignEmotions,RUN_Answer,AuxVerbs,Borg,Decide,Chocky,ClrEmoDebug,Nothing,CContext,
  GetConvBuffer,Correct,CpyScope,CreateGraph,CS2Sentence,CSAddr,CSDebug,CSLoad,CSRecon,
  CSSave,Debug,DebugAware,Conditional_Debug,Reasoning_Debug,DebugEmotionCache,DecideWords,Outcome,
  Define,Definition,Delete,DelScope,Described,DeYoda,Div,Do,Domain,Element,Emo2Vec,EmoDebug,
  EmoDebugVec,FindEmoSentence,EmotionMapper,Emotion,EmoList,
  EmpathyInj,EmpathyPost,EmpathyWrapper,Question,Nothing,EndPunct,Equalizer,Equivalence,
  HelpExample,Except,Exp,Sentence_Designer,FALSE,First,FirstAfter,FirstBefore,Force,Foreach,
  Forget,GetEmoDebug,
  GetGraphs,Grammar,Graphs,Greater,GroupSet,GroupShow,Help,Hook,Route,If,ImpEvent,InfoEvent,
  Intersection,Setup,Language_Debug,Last,LastAfter,LastBefore,Decision_Maker,Like,Limits,
  ListByTopic,ListCSValues,
  ListSentences,Load,Locklang,ListCombinations,LstScope,MapLanguage,Math,Meld,MeldVF,Memory,
  Merge,Mode,Mul,CreateMusic,Mutate,NAND,New,Nicefy,NLPAvoidWrap,NLPCauseWrap,NOR,NOT,Nouns,
  Nothing,ODDMAN,OR,Orthogonal,Nothing,Show_Pattern,Personality,Phrase_Generator,PopEmoDebug,
  PPronouns,PredVerbs,Prepend,Pronouns,Purge,Purpose,Qualify,Nothing,Random,SetRandSeed,Read,Reason,
  Sentence_Generator,Recollect,Relationship,Reverse,Revise,Route,RUN,Save,SAVF,Saveset,
  SchedDel,SchedNew,Scheduler,SemPath,
  SentenceAssign,SentenceConvertBase,SentenceConvertMood,SentenceConvertTense,Sentencedebug,
  SentenceEmotion,SentenceExplain,SentenceTense,SentenceUnity,Sentiency,SerialRecv,SerialSend,
  SerialTest,SetBias,SetCondCause,SetCondEffect,SetEmoMode,SetGender,SetMood,SetNULL,SetPassive,
  SetQuestion,SetScope,SetSerial,
  SetWH,SetYN,ShortPath,ShowProf,Shrink,ShwScope,SIGNAL,Similar,Size,Sleep,Smaller,SMVF,SPA,SPath,
  Split,SPVF,Statistics,StemAdd,StemBase,StemClass,StemFind,StemMeld,StemShow,Store,Study,
  Sub,Subj,Subset,SystemMood,Swap,Tense,Tenses,Test,Nothing,Think1,Think2,TOL,Topic,Translator,TreeGenerate,
  TRUE,T_Transform,Understand,Union,Unknown,Unstore,Unwrap,Vec2Emo,Verbosity, VerbPostProc,
  VerbTableAdd,Version,Wait,WHQEvent,Wrap,XOR,YNQEvent
};

/*! \brief Generic test function stub.
 *
 */
struct List_Str  *Test(struct List_Str *Word_List,struct List_Str *L){
   puts("DEV: INSERT FUNCTION HERE.");

   return L;
}

/*! \brief Bootstraps ENiX3.
 *
 */
int main(int argc, char *argv[]){
  int _=0,c=0,Batch_Mode=0,i=0;
  char *G=NULL,*Backup=NULL,*String=NULL; 
  struct List_Str *Com=NULL,*INPIPE=NULL;
  struct Datablock *DB=NULL;
  Data=NULL;
  if(argc==2){
    for(_=0;_<strlen(argv[1]);_++){
      G=(char *)argv[1];
      if(G[_]==' '){ 
	Batch_Mode=1;
	_=strlen(G);
      } 
    } 
  }
  G=(char *)argv[0]; 
  _=StrLen(G); 
  for(c=0;c<_;c++) 
    if(G[c]=='/')
      i=c+1; 
  ProgramName=StrCat("",G+i);
  Filename=StrCat(StrCat(getenv("HOME"),"/.ENiX/"),StrCat(ProgramName,".MEM"));
  Backup=StrCat(StrCat(getenv("HOME"),"/.ENiX/"),StrCat(ProgramName,".BAK"));
  if(argc>1){
    if(!strcasecmp(argv[1],":undo")){
      puts("Undoing last operation. (Note can only :UNDO once).");
      if(system(StrCat("rm -f ",Filename))){}
      if(system(StrCat(StrCat(StrCat("cp ",Backup)," "),Filename))){}
      return 1;
    }
  }
  Load2RAM();

  LoadEmoDB(); /* added 24.09.2011 */
  
  if(!isatty(fileno(stdin)))
    INPIPE=Str2List(LoadPipe(stdin));
  if(Batch_Mode){
    Com=Ins_List_List(Ins_List_Element(NULL,Filename,0),Str2List(argv[1]),1);
  }
  else{
    for(_=0;_<argc;_++){
      if(strlen(argv[_])){
	String=StrCat("",argv[_]);
	Com=Ins_List_Element(Com,String,_);
      }
    }
  }
  if(INPIPE) 
    Com=Ins_List_List(Com,INPIPE,1);
  LowerCaseList(Com->Next);
  Translation_Bypass=0;

  /* added 31/10/2013 */
  Com=ExtractConvSource(Com->Next);

  if(Com){
    if(!strcmp(Com->Str,":purge")) Purge(NULL,NULL);
    else{
      Paragraph2Sentence(IWrapper(Com));
    }
  }
  else{
    if(!Detect_Sentiency())
      HelpSplash();
    else{
      Scheduler(NULL,NULL);
    }
  }
  if((DB=Goto_DB_Entry(Database[1],":mode")))
    Rep_DB_Pair(DB,":memnew",FloatToString(Newly_Learnt));

  Save2Persistent(Backup);

  return 0;
}

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */

