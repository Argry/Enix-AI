/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ENiX_Globals.h"
#include "ENiX_STRING.h"
#include "ENiX_LIST.h"
#include "ENiX_WMS.h"
#include "ENiX_WMS_COMPAT.h"
#include "ENiX_ANALYSER.h"

int                      Complexity;
struct Kernel_Problem    *Sub_Problems;
struct Canonical_Problem *Opt_Problems;
int                      Fabricate_Current_Example;

char             *DGateNames[]={":FALSE  ",":NOR    ",":AND-NOT",":NOT-2  ",":NOT-AND",":NOT-1  ",":XOR    ",":NAND   ",":AND    ",":NXOR   ",":WIRE-1 ",":OR-NOT ",":WIRE-2 ",":NOT-OR ",":OR     ",":TRUE   "};
char             *SGateNames[]={":FALSE  ",":NOT    ",":WIRE   ",":TRUE   "};

/*! \brief Executes a neural network on a list of numbers. Saves the result in ANSWER.
 *
 */
struct List_Str *Decide(struct List_Str *WordList,struct List_Str *L){
  int i=0,Value=0;
  char *Pattern=L->Str,*DimStr=NULL;
  struct List_Str *Input=NULL,*Data=NULL;
  if(strcmp(DimStr=(Get_DB_Entry(Goto_DB_Entry(Database[0],Pattern),0,7)),"?"))
    Data=Str2List(DimStr);
  else
    Data=NULL;
  ANSWER=NULL;
  for(Input=WordList;Input;Input=Input->Next){
    Value=Internal_Execute(Data,atoi(Input->Str));
    ANSWER=Ins_List_Element(ANSWER,FloatToString(Value),i++);
  }
  return L->Next;
}

/*! \brief Determines if the neural network is understood.
 * - Understanding metric is either 0, 1 or 2. Representing not understood, partially understood or understood.
 */
struct List_Str *Understand(struct List_Str *Word_List,struct List_Str *L){
   int Position=0,TPI=0,Complexity=0,Last_Complexity=0,Understood=2,A=0,B=0,Hope=0;
   char *Concept=L->Str,*Buffer=NULL;
   struct List_Str *Values=NULL,*TMP=NULL,*Command=NULL,*Complexities=NULL,*Buffer2=NULL;
   struct Datablock *DB=Database[0];
   if((Position=Find_DB_Entry(Database[0],Concept))<0){
      printf("%s not found. Aborting.\n",Concept);
      return L->Next;
   }
   DB=Goto_DB_Entry(Database[0],Concept);
   Position=1<<atoi(Get_DB_Entry(DB,0,2));
   Command=Ins_List_Element(NULL,Concept,0);
   for(TPI=0;TPI<Position;TPI++){
      Decide(Ins_List_Element(NULL,FloatToString(TPI),0),Command);
      Values=Ins_List_Element(Values,ANSWER->Str,TPI);
   }
   Decide(Values,Ins_List_Element(NULL,Concept,0));
   ANSWER=Ins_List_Element(Values,"scratchpad",0);
   for(Values=(TMP=ANSWER)->Next;Values;Values=Values->Next){
      Buffer=Values->Str; 
      Values->Str=":unknown"; 
      Decision_Maker(TMP,NULL); 
      Complexity=atoi(ANSWER->Str);
      if(Last_Complexity){ 
	 if(Last_Complexity!=Complexity) 
	   Understood=0; 
      }
      if(Complexity)
	Hope=1;
      Last_Complexity=Complexity; 
      Values->Str=Buffer; 
      Complexities=Append_List_Element(Complexities,FloatToString(Complexity));
   }  
   if(!Hope)
     Understood=0;
   else
     if(!Understood)
       for(Buffer2=Complexities;Buffer2;Buffer2=Buffer2->Next){
	  if((B=Find_List_Element(Complexities,Buffer2->Str))+1)
	    if((A-B)&&A&&B)
	      Understood=1;
	  A++;
       }
   TriggerEmoAttr("trigunderstood",Understood);
   ANSWER=Ins_List_Element(NULL,FloatToString(Understood),0);
   return L->Next;
}


/*! \brief Displays the equalisation plot for debugging awareness.
 * 
 */
struct List_Str *DebugAware(struct List_Str *Word_List,struct List_Str *L){
  int Position=0,TPI=0,Complexity=0,Last_Complexity=0,Understood=2,A=0,B=0,Hope=0;
  char *Concept=L->Str,*Buffer=NULL;
  struct List_Str *Values=NULL,*TMP=NULL,*Command=NULL,*Complexities=NULL,*Buffer2=NULL;
  struct Datablock *DB=Database[0];
  if((Position=Find_DB_Entry(Database[0],Concept))<0){
    printf("%s not found. Aborting.\n",Concept);
    return L->Next;
  }
  DB=Goto_DB_Entry(Database[0],Concept);
  Position=1<<atoi(Get_DB_Entry(DB,0,2));
  Command=Ins_List_Element(NULL,Concept,0);
  for(TPI=0;TPI<Position;TPI++){
    Decide(Ins_List_Element(NULL,FloatToString(TPI),0),Command);
    Values=Ins_List_Element(Values,ANSWER->Str,TPI);
  }
  Decide(Values,Ins_List_Element(NULL,Concept,0));
  ANSWER=Ins_List_Element(Values,"scratchpad",0);
  for(Values=(TMP=ANSWER)->Next;Values;Values=Values->Next){
    Buffer=Values->Str; 
    Values->Str=":unknown"; 
    Decision_Maker(TMP,NULL); 
    Complexity=atoi(ANSWER->Str);
    if(Last_Complexity){ 
      if(Last_Complexity!=Complexity) 
	Understood=0; 
    }
    if(Complexity)
      Hope=1;
    Last_Complexity=Complexity; 
    Values->Str=Buffer; 
    Complexities=Append_List_Element(Complexities,FloatToString(Complexity));
  }  
  if(!Hope)
    Understood=0;
  else
    if(!Understood)
      for(Buffer2=Complexities;Buffer2;Buffer2=Buffer2->Next){
	if((B=Find_List_Element(Complexities,Buffer2->Str))+1)
	  if((A-B)&&A&&B)
	    Understood=1;
	A++;
      }
  /* TriggerEmoAttr("trigunderstood",Understood); */
  printf("Equalisation matrix: ");
  PrintList(Complexities);
  if(Understood==0)
    puts("Concept is not understood.");
  if(Understood==1)
    puts("Concept is partially understood.");
  if(Understood==2)
    puts("Concept is understood.");
  ANSWER=Ins_List_Element(NULL,FloatToString(Understood),0);
  return L->Next;
}

/*! \brief This function executes pieces of the neural network.
 * - Internal only.
 */
int Internal_Execute(struct List_Str *Logic_Grid,int TPI){
   int Stream=0,Layer=0,Type=0,Logic=0,I1=0,I2=0,i=0,Prev_Stream=0,Prev_Layer=0,Layer_Input=TPI,Layer_Output=0,Output=0;
   while(Logic_Grid){
      Stream=atof(Logic_Grid->Str);
      Logic_Grid=Logic_Grid->Next;
      Layer=atof(Logic_Grid->Str);
      Logic_Grid=Logic_Grid->Next;
      Type=atof(Logic_Grid->Str);
      Logic_Grid=Logic_Grid->Next;
      Logic=atof(Logic_Grid->Str);
      Logic_Grid=Logic_Grid->Next;
      I1=atof(Logic_Grid->Str);
      Logic_Grid=Logic_Grid->Next;
      I2=atof(Logic_Grid->Str);
      Logic_Grid=Logic_Grid->Next;
      if(Prev_Layer!=Layer){
	 if(Prev_Stream!=Stream){
	   Layer_Input=TPI;
	   Output+=(Layer_Output<<Prev_Stream);
	   Prev_Stream=Stream;
	 }
	 else{
	   Layer_Input=Layer_Output;
	 }
	 Layer_Output=0;
	 Prev_Layer=Layer;
	 i=0;
      }
      else{
	if(Prev_Stream!=Stream){
	  i=0; 
	  Layer_Input=TPI;  
	  Output+=(Layer_Output<<Prev_Stream); 
	  Prev_Stream=Stream; 
	  Layer_Output=0; 
	}
      }
      if(Type==1)
	Layer_Output+=Single_Input_Gates(Logic,(Layer_Input>>I1)&1);
      else
	Layer_Output+=Double_Input_Gates(Logic,(Layer_Input>>I1)&1,(Layer_Input>>I2)&1)<<i++;
   }
   Output+=(Layer_Output<<Stream);
   return Output;
}

/*! \brief Dual input gate processor. 
 * 
 */
int Double_Input_Gates(int Gate_ID, int In1, int In2){ return !!(Gate_ID&(1<<(In1+In2+In2))); } /* Courtesy of Mj  */

/*
int Double_Input_Gates(int Gate_ID, int In1, int In2){
   if(Gate_ID==0)  return 0;          if(Gate_ID==1)  return !(In1|In2); if(Gate_ID==2)  return In1&(!In2); if(Gate_ID==3)  return !In2;
   if(Gate_ID==4)  return (!In1)&In2; if(Gate_ID==5)  return !In1;       if(Gate_ID==6)  return In1^In2;    if(Gate_ID==7)  return !(In1&In2);
   if(Gate_ID==8)  return In1&In2;    if(Gate_ID==9)  return !(In1^In2); if(Gate_ID==10) return In1;        if(Gate_ID==11) return In1|(!In2);
   if(Gate_ID==12) return In2;        if(Gate_ID==13) return (!In1)|In2; if(Gate_ID==14) return In1|In2;    if(Gate_ID==15) return 1;
}
*/

/*! \brief Single input gate processor. 
 * 
 */
int Single_Input_Gates(int Gate_ID, int Input){ return (Gate_ID&(1<<Input))>>Input; }           /* Courtesy of Mj */

/*! \brief Generate the actual neural network.
 * 
 */
struct List_Str  *Decision_Maker(struct List_Str *Word_List, struct List_Str *L){ /* memory error when input length is 1 */
   int _=0,Out_Max=0,A=0,B=0,C=0,Layer=0; 
   char *Concept_Name=NULL;
   double Value=0;
   struct List_Str *Data=NULL,*Cluster=NULL; 
   struct Kernel_Problem *Main_Problem=(struct Kernel_Problem *)malloc(sizeof(struct Kernel_Problem)); 
   struct List_Str *Input=NULL; 
   struct Datablock *R=NULL;
   if(Size_of_List(Word_List)<2)
     return L;
   Complexity=0;
   Input=Word_List;
   Main_Problem->Split=0;
   Main_Problem->Minimal=0;
   Main_Problem->Size=0;
   Main_Problem->Inputs=0;
   Main_Problem->Outputs=0;
   Main_Problem->Knowns=(int *)malloc(sizeof(int));
   Main_Problem->Unknowns=(int *)malloc(sizeof(int));
   Concept_Name=Input->Str;
   for(Input=Input->Next;Input;Input=Input->Next){
      Main_Problem->Knowns=(int *)realloc(Main_Problem->Knowns,((Main_Problem->Size)+1)*sizeof(int)); 
      Main_Problem->Unknowns=(int *)realloc(Main_Problem->Unknowns,((Main_Problem->Size)+1)*sizeof(int));
      if((strcmp(Input->Str,":unknown")==0)||(strcmp(Input->Str,"?")==0)){
	 Main_Problem->Knowns[Main_Problem->Size]=0;
	 Main_Problem->Unknowns[Main_Problem->Size]=1;
      }
      else{
	 Main_Problem->Knowns[Main_Problem->Size]=atoi(Input->Str); 
	 Main_Problem->Unknowns[Main_Problem->Size]=0;
	 if(Main_Problem->Knowns[Main_Problem->Size]>Out_Max)
	   Out_Max=Main_Problem->Knowns[Main_Problem->Size];
      }
      Main_Problem->Size++;
   }
   for(_=Out_Max;_;_=_>>1){
      Main_Problem->Inputs++;
   }
   for(_=Main_Problem->Size-1;_;_=_>>1){
      Main_Problem->Outputs++;
   }
   Opt_Problems=(struct Canonical_Problem *)malloc((Main_Problem->Inputs)*sizeof(struct Canonical_Problem));
   Sub_Problems=(struct Kernel_Problem *)malloc((Main_Problem->Inputs)*sizeof(struct Kernel_Problem)); 
   for(_=0;_<Main_Problem->Inputs;_++){
      Sub_Problems[_].Split=1;
      Sub_Problems[_].Minimal=1;
      Sub_Problems[_].Size=Main_Problem->Size;
      Sub_Problems[_].Inputs=Main_Problem->Inputs;
      Sub_Problems[_].Outputs=1;
      Sub_Problems[_].Knowns=(int *)malloc(((Main_Problem->Size)+1)*sizeof(int)); 
      Sub_Problems[_].Unknowns=(int *)malloc(((Main_Problem->Size)+1)*sizeof(int));
      for(A=0;A<Main_Problem->Size;A++){
	 if(Main_Problem->Unknowns[A]){
	    Sub_Problems[_].Knowns[A]=0;
	    Sub_Problems[_].Unknowns[A]=1;
	 }
	 else{
	    Sub_Problems[_].Knowns[A]=((Main_Problem->Knowns[A]>>_)&1);
	    Sub_Problems[_].Unknowns[A]=0;
	 }
      }
   }
   for(_=0;_<Main_Problem->Inputs;_++){
      Thought_Procreator(Sub_Problems[_],&Opt_Problems[_]);
      B=0;
      Layer=0;
      C=(Opt_Problems[_].G_Max+1)>>1;
      for(A=0;A<Opt_Problems[_].G_Max;A++){
	 Value=_;
	 Data=Ins_List_Element(Data,FloatToString(Value),0);
	 Value=Layer;
	 Data=Ins_List_Element(Data,FloatToString(Value),0);
	 if(Opt_Problems[_].Inputs==1)
	   Value=1;
	 else
	   Value=2;
	 Data=Ins_List_Element(Data,FloatToString(Value),0);
	 Value=Opt_Problems[_].Logic_Grid[A];
         Data=Ins_List_Element(Data,FloatToString(Value),0);
	 if(Layer==0){
	    Value=Opt_Problems[_].Positions[Opt_Problems[_].Input_Route[(A<<1)]];   
	    Data=Ins_List_Element(Data,FloatToString(Value),0);
	    Value=Opt_Problems[_].Positions[Opt_Problems[_].Input_Route[(A<<1)+1]]; 
	    Data=Ins_List_Element(Data,FloatToString(Value),0);
	    
	 }
	 else{
	    Value=Opt_Problems[_].Input_Route[(A<<1)];   
	    Data=Ins_List_Element(Data,FloatToString(Value),0);
	    Value=Opt_Problems[_].Input_Route[(A<<1)+1]; 
	    Data=Ins_List_Element(Data,FloatToString(Value),0);
	 }	 
	 B++;
	 if(B==C){
	    Layer++; 
	    B=0;
	    C=((C+1)>>2);
	 }
      }
   }
   while(Data){
      Cluster=Ins_List_Element(Cluster,Data->Str,0);
      Data=Data->Next;
   }
   if(!Goto_DB_Entry(Database[0],Concept_Name))
     Database[0]=Add_DB_Entry(Database[0],Concept_Name);
   R=Goto_DB_Entry(Database[0],Concept_Name);
   if(Cluster) 
     Rep_DB_Entry(R,0,7,List2Str(Cluster));
   else        
     Rep_DB_Entry(R,0,7,"?");
   Rep_DB_Entry(R,0,1,FloatToString(Complexity));
   Rep_DB_Entry(R,0,2,FloatToString(Main_Problem->Outputs));
   Rep_DB_Entry(R,0,3,FloatToString(Main_Problem->Inputs));
   ANSWER=Ins_List_Element(NULL,FloatToString(Complexity),0);
   return L;
}

/*! \brief Learns the data using a neural network.
 * 
 */
void Thought_Procreator(struct Kernel_Problem P, struct Canonical_Problem *Opt_P){
   int Upper_Bounded=0,Interval_Length=0,Number_of_Intervals=0,Interval=0,x=0,Same=0,Current_Bit=0,Tmp=0;
   for(Upper_Bounded=1;Upper_Bounded<P.Size;Upper_Bounded*=2){}
   Opt_P->Inputs=0; Opt_P->Positions=NULL;
   for(Interval_Length=1;Interval_Length<(Upper_Bounded>>1)+1;Interval_Length*=2){ 
      Number_of_Intervals=Upper_Bounded/Interval_Length; 
      Same=1;
      for(Interval=0;Interval<Number_of_Intervals;Interval+=2){
	for(x=Interval*Interval_Length;x<(Interval+1)*Interval_Length;x++){
	  if((x<P.Size)&&(x+Interval_Length<P.Size)){
	    if(P.Unknowns[x]||P.Unknowns[x+Interval_Length]){}
	    else if(P.Knowns[x]!=P.Knowns[x+Interval_Length]){ 
	      Same=0; 
	      x=(Interval+1)*Interval_Length; 
	    }
	  }
	  else
	    x=(Interval+1)*Interval_Length;
	}
      }
      if(!Same){ 
	Opt_P->Positions=Add_Number(Opt_P->Positions,Opt_P->Inputs,Current_Bit); 
	Opt_P->Inputs++; 
      } 
      Current_Bit++;
   }
   Tmp=Opt_P->Inputs;
   if(!Opt_P->Inputs){
     Opt_P->Positions=Add_Number(Opt_P->Positions,Opt_P->Inputs++,Current_Bit); 
     Opt_P->Size=1;
   }  
   Opt_P->Size=1<<Opt_P->Inputs;
   Fabricate_Current_Example=0;
   Opt_P->Knowns=NULL;
   Opt_P->Unknowns=NULL;
   Opt_P->Logic_Grid=NULL;
   Fabricate(Opt_P,P);
   if(!Tmp){
     Opt_P->Unknowns[1]=0;
     Opt_P->Knowns[1]=Opt_P->Knowns[0];
   }
   if(!Analyse_Pattern(Opt_P)){}
   /*  puts("Pattern Recognition Failure."); */
   else{
      if(Opt_P->Inputs>1)
	Tmp=Opt_P->Inputs-1;
      else
	Tmp=Opt_P->Inputs;
   }
   Complexity+=Opt_P->Complexity;
}

/*! \brief Increase the size of an array.
 * 
 */
int *Add_Number(int *List,int Size,int N){
  if(Size)
    List=(int *)realloc(List,(Size+2)*sizeof(int));
  else
    List=(int *)malloc(2*sizeof(int));
  List[Size]=N;
  List[Size+1]=0;
  return List;
}

/*! \brief Make the example sequence upto a certain power of 2.
 * 
 */
void Fabricate(struct Canonical_Problem *Opt_P,struct Kernel_Problem P){
   int i=0,New_Index=0,Old_Index=0,Code=0,Found=0;
   Opt_P->Unknowns=NULL;
   Opt_P->Knowns=NULL;
   Opt_P->Logic_Grid=NULL;
   for(New_Index=0;New_Index<Opt_P->Size;New_Index++){
     Found=0;
     for(Old_Index=0;Old_Index<P.Size;Old_Index++){
       Code=0;
       for(i=0;i<Opt_P->Inputs;i++)
	 Code+=((Old_Index>>Opt_P->Positions[i])&1)<<i;
       if(P.Unknowns[Old_Index]==0)
	 if(Code==New_Index){                             
	   Opt_P->Unknowns=Add_Number(Opt_P->Unknowns,New_Index,0);
	   Opt_P->Knowns=Add_Number(Opt_P->Knowns,New_Index,P.Knowns[Old_Index]); 
	   Found=1;
	   Old_Index=P.Size;
	 }
     } 
     if(!Found){
       Opt_P->Unknowns=Add_Number(Opt_P->Unknowns,New_Index,1);
       Opt_P->Knowns=Add_Number(Opt_P->Knowns,New_Index,0);
     }
   }
}


/*! \brief Create a template neural network and start mutating.
 * 
 */
int Analyse_Pattern(struct Canonical_Problem *Opt_P){
  int i=0,Layer_Inputs=Opt_P->Inputs;
  Opt_P->R_Max=0;
  Opt_P->G_Max=0;
  Opt_P->Input_Route=NULL;
  Opt_P->Logic_Grid=NULL;
  Opt_P->Complexity=0;
  if(Opt_P->Inputs==1){
    Opt_P->R_Max=1;
    Opt_P->G_Max=1;
    Opt_P->Input_Route=Add_Number(Opt_P->Input_Route,0,0);
    Opt_P->Logic_Grid=Add_Number(Opt_P->Logic_Grid,0,0);
  }
  while(Layer_Inputs>1){
    Layer_Inputs=(Layer_Inputs+1)>>1;
    for(i=0;i<Layer_Inputs;i++){
      Opt_P->Logic_Grid=Add_Number(Opt_P->Logic_Grid,Opt_P->G_Max++,0); 
      Opt_P->Input_Route=Add_Number(Opt_P->Input_Route,Opt_P->R_Max++,0);
      Opt_P->Input_Route=Add_Number(Opt_P->Input_Route,Opt_P->R_Max++,0);
    }
  } 
  return Layer_Mutate_Structure(Opt_P,Opt_P->Inputs,0);
}

/*! \brief Change the neural network structure.
 * 
 */
int Layer_Mutate_Structure(struct Canonical_Problem *Opt_P,int Layer_Inputs,int Layer_Offset){
   int Return=0,i=0,Quit=0,Layer_Outputs=(Layer_Inputs+1)>>1,Use=0;
   if(Opt_P->Inputs==1)
     for(i=0;i<4;i++){
       Opt_P->Logic_Grid[0]=i;
       Return=Test_Mutation(Opt_P);
       if(Return)
	 return 1;
     }
   if(Layer_Outputs>1){           
     while(!Quit){
       Opt_P->Input_Route[Layer_Offset]++;
       for(i=0;i<(Layer_Outputs<<1);i++)
	 if(Opt_P->Input_Route[Layer_Offset+i]==Layer_Inputs){
	   Opt_P->Input_Route[Layer_Offset+i]=0;
	   if(i<(Layer_Inputs<<1)-1)
	     Opt_P->Input_Route[Layer_Offset+i+1]++;
	 }
       Quit=1;
       for(i=0;i<(Layer_Outputs<<1);i++)
	 if(Opt_P->Input_Route[Layer_Offset+i]!=0){
	   Quit=0;
	   i=Layer_Inputs;
	 }
       Use=1;
       for(i=0;i<Layer_Outputs;i++){
	 if(Opt_P->Input_Route[Layer_Offset+(i<<1)]>Opt_P->Input_Route[Layer_Offset+(i<<1)+1]){
	   Use=0;
	   i=Layer_Outputs;
	 }
	 if(i<Layer_Outputs-1)
	   if(Opt_P->Input_Route[Layer_Offset+(i<<1)]>Opt_P->Input_Route[Layer_Offset+(i<<1)+2]){
	     Use=0;
	     i=Layer_Outputs;
	   }
	 }
	 if(Use)
	   Return=Layer_Mutate_Structure(Opt_P,Layer_Outputs,Layer_Offset+(Layer_Outputs<<1));
	 else
	   Return=0;
	 if(Return)
	   return 1;
     }
   }
   else{
     Opt_P->Input_Route[Layer_Offset]=0;
     Opt_P->Input_Route[Layer_Offset+1]=1;
     Return=Layer_Gate_Mutation(Opt_P);
     if(Return)
       return 1;
   }
   return 0;
}

/*! \brief Test if the neural network structure works.
 * 
 */
int Test_Mutation(struct Canonical_Problem *Opt_P){
  int TPI=0,Same=1;
  Opt_P->Complexity++;
  for(TPI=0;TPI<Opt_P->Size;TPI++)
    if(!Opt_P->Unknowns[TPI])
      if(Opt_P->Knowns[TPI]!=Execute_Part(Opt_P,TPI)){
	Same=0;
	TPI=Opt_P->Size;
      }
  return Same;
}

/*! \brief Change the type of the neuron.
 * 
 */
int Layer_Gate_Mutation(struct Canonical_Problem *Opt_P){
  int i=0,Quit=0,Return=0;
  while(!Quit){
    Opt_P->Logic_Grid[0]++;
    for(i=0;i<Opt_P->G_Max;i++)
      if(Opt_P->Logic_Grid[i]==16){
	Opt_P->Logic_Grid[i]=0;
	if(i<Opt_P->G_Max-1)
	  Opt_P->Logic_Grid[i+1]++;
      }
    Quit=1;
    for(i=0;i<Opt_P->G_Max;i++)
      if(Opt_P->Logic_Grid[i]!=0){
	Quit=0;
	i=Opt_P->G_Max;
      }
    Return=Test_Mutation(Opt_P);
    if(Return)
      return 1;
  }
  return 0;
}

/*! \brief Execute part of the neural network at a TPI.
 * 
 */
int Execute_Part(struct Canonical_Problem *Opt_P,int TPI){
  int i=0,Quit=0,Layer_Input=TPI,Layer_Output=0,Layer_Gates=(Opt_P->Inputs+1)>>1,Gate_ID=0;
  if(Opt_P->Inputs==1)
    return Single_Input_Gates(Opt_P->Logic_Grid[0],TPI&1);
  while(!Quit){
    for(i=0;i<Layer_Gates;i++)
      Layer_Output+=Double_Input_Gates(Opt_P->Logic_Grid[Gate_ID++],(Layer_Input>>(Opt_P->Input_Route[i<<1]))&1,(Layer_Input>>(Opt_P->Input_Route[(i<<1)+1]))&1)<<i;
    if(Layer_Gates==1)
      Quit=1;
    Layer_Gates=(Layer_Gates+1)>>1;
    Layer_Input=Layer_Output;
    Layer_Output=0;
  }  return Layer_Input;
}

/*! \brief Calculate oddman out of the number sequence.
 * 
 */
struct List_Str *ODDMAN(struct List_Str *WordList,struct List_Str *L){
  int i=0,Position=0,TPI=0,Complexity=0,Last_Complexity=0,Min_Complexity=0,Understood=1;
  char *Concept=NULL,*Buffer=NULL;
  struct List_Str *Values=NULL,*TMP=NULL;
  struct Datablock *DB=Database[0];
  Concept=L->Str;
  if((Position=Find_DB_Entry(Database[0],Concept))<0){
    printf("%s not found. Aborting.\n",Concept);
    return L->Next;
  }
  DB=Goto_DB_Entry(Database[0],Concept);
  Position=1<<atoi(Get_DB_Entry(DB,0,2));
  for(TPI=0;TPI<Position;TPI++)
    Values=Ins_List_Element(Values,FloatToString(TPI),TPI);
  Decide(Values,Ins_List_Element(NULL,Concept,0));
  ANSWER=Ins_List_Element(ANSWER,"scratchpad",0);
  TMP=ANSWER;
  Values=TMP;
  i=0;
  Position=0;
  for(Values=Values->Next;Values;Values=Values->Next){
    Buffer=Values->Str;
    Values->Str=":unknown";
    Decision_Maker(TMP,NULL);
    Complexity=atoi(ANSWER->Str);
    if(!i)
      Min_Complexity=Complexity;
    if((Complexity<Min_Complexity)&&Complexity){
      Min_Complexity=Complexity;
      Position=i;
    }
    if(Last_Complexity)
      if(Last_Complexity!=Complexity)
	Understood=0;
    if(!Complexity)
      Understood=0;
    i++;
    Last_Complexity=Complexity;
    Values->Str=Buffer;
  }  
  if(Understood)
    ANSWER=Ins_List_Element(NULL,":NULL",0);
  else
    ANSWER=Ins_List_Element(NULL,FloatToString(Position),0); 
  return L->Next;
}

/*! \brief Fill in the missing or unknown numbers in the example sequence.
 * 
 */
struct List_Str *Correct(struct List_Str *WordList,struct List_Str *L){
  int i=0,Position=0,Size=0,TPI=0;
  char *Concept=L->Str;
  struct List_Str *Buffer=NULL,*Input=NULL,*Values=NULL;
  struct Datablock *DB=Database[0];
  if((Position=Find_DB_Entry(Database[0],Concept))<0){
    printf("%s does not exist. Aborting.\n",Concept);
    return L->Next;
  }
  DB=Goto_DB_Entry(Database[0],Concept);
  Size=1<<atoi(Get_DB_Entry(DB,0,2));
  for(TPI=0;TPI<Size;TPI++)
    Values=Ins_List_Element(Values,FloatToString(TPI),TPI);
  Decide(Values,Ins_List_Element(NULL,Concept,0));
  Values=Ins_List_Element(ANSWER,Concept,0);
  for(Input=WordList;Input;Input=Input->Next){
    Position=atoi(Input->Str);
    Buffer=Values->Next;
    for(i=0;i<Position;i++)
      Buffer=Buffer->Next;
    Buffer->Str=":unknown";
  }
  ANSWER=Values;
  return L->Next;
}



/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
