/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <stdlib.h>
#include "ENiX_Globals.h"
#include "ENiX_WMS.h"
#include "ENiX_LIST.h"
#include "ENiX_STRING.h"
#include "ENiX_ANALYSER.h"
#include "ENiX_NLP.h"
#include "ENiX_MUSIC.h"
#include "ENiX_CALC.h"

/*! \brief Write a piece of music. 
 *  - Single theme nothing fancy
 */
struct List_Str *CreateMusic(struct List_Str *Word_List,struct List_Str *L){
  int _=0,Size=0,Tempo=50,Instrument=0,Pitch=0,Volume=100;
  struct List_Str *Melody=NULL;
  struct Melody *Theme=NULL;
  if(!GetLang()){
    printf("CreateMusic (%s:%d) Language not setup!\n",__FILE__,__LINE__);
    return L;
  }
  Random(Ins_List_Element(NULL,"8",0),Ins_List_Element(NULL,"255",0));
  Theme=CreateTheme(ANSWER);
  Melody=Theme->MainTheme;
  Size=Size_of_List(Melody);
  puts("START");
  for(_=0;_<Size;_++){
    Pitch=(atoi(Get_List_Element(Melody,_))>>2)+30;
    printf("%d %d %d %d\n",Tempo,Instrument,Pitch,Volume);
  }
  puts("END");
  return L;
}

/*! \brief Write a piece of music. 
 *  - this was an experiment to use multiple instruments. Does not sound great.
 */
struct List_Str *CreateMusic2(struct List_Str *Word_List,struct List_Str *L){
  int _=0,Size1=0,Size2=0,Size=0,Tempo=50,Instrument=0,Pitch=0,Volume=100;
  struct List_Str *Melody1=NULL,*Melody2=NULL;
  struct Melody *Theme1=NULL,*Theme2=NULL;
  if(!GetLang()){
    printf("CreateMusic (%s:%d) Language not setup!\n",__FILE__,__LINE__);
    return L;
  }
  Random(Ins_List_Element(NULL,"8",0),Ins_List_Element(NULL,"255",0));
  Theme1=CreateTheme(ANSWER);
  Melody1=Theme1->MainTheme;
  Random(Ins_List_Element(NULL,"8",0),Ins_List_Element(NULL,"255",0));
  Theme2=CreateTheme(ANSWER);
  Melody2=Theme2->MainTheme;
  Size=((Size1=Size_of_List(Melody1))<(Size2=Size_of_List(Melody2)))?Size1:Size2;
  puts("START");
  /* need to add choruses and depression */
  Size2--;
  for(_=0;_<Size;_++){
    Instrument=atoi(Get_List_Element(Melody1,_%Size1))&3;
    Pitch=(atoi(Get_List_Element(Melody2,_%Size2))>>2)+30;
    printf("%d %d %d %d\n",Tempo,Instrument,Pitch,Volume);
  }
  puts("END");
  return L;
}

/*! \brief Create a music theme.
 *
 */
struct Melody *CreateTheme(struct List_Str *Seed){
   int Prev=0,Quit=0,Size=0,Terminate=100,Counter=0;
   struct Melody *New=(struct Melody *)malloc(sizeof(Themes));
   struct List_Str *Theme=NULL,*Buffer=NULL,*CMD=Ins_List_Element(NULL,"interntest",0),*ToCompute=NULL,*Word_List=NULL;

   Word_List=Seed;
   Size=Size_of_List(Word_List)-1;
   Buffer=Word_List;
   Domain(Ins_List_Element(Ins_List_Element(NULL,"0",0),FloatToString(Size),1),NULL);
   ToCompute=ANSWER;
   while((!Quit)&&(Counter<Terminate)){
      Buffer=Ins_List_Element(Buffer,"interntest",0);
      Decision_Maker(Buffer,NULL);
      Understand(NULL,CMD);
      Buffer=Del_List_Element(Buffer,0);
      if(atoi(ANSWER->Str)!=2){
	 Prev=0;
	 ODDMAN(NULL,CMD);
	 Correct(ANSWER,CMD);
	 Decision_Maker(ANSWER,NULL);
	 Decide(ToCompute,CMD);
	 Buffer=ANSWER;
	 Counter++;
	 if(Theme)
	   Theme=Ins_List_List(Theme,Buffer,Size_of_List(Theme)-1);
	 else
	   Theme=Ins_List_List(Theme,Buffer,0);
      }
      else{
	 if(Prev)
	   Quit=1;
	 else{
	    Prev=1;
	    New->Correct1=Buffer;
	    T_Transform(Buffer,NULL);
	    Buffer=ANSWER;
	    if(Theme)
	      Theme=Ins_List_List(Theme,Buffer,Size_of_List(Theme)-1);
	    else
	      Theme=Ins_List_List(Theme,Buffer,0);
	    Counter++;
	 }
      }
   }
   if(ThinkOutLoud){
      printf("Sequence orthognolly understood: "); PrintList(Buffer);
   }
   ANSWER=Del_List_Element(Buffer,0);
   New->Correct2=Buffer;
   New->MainTheme=Theme;
   return New;
}




/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
