/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2014.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "ENiX_Globals.h"
#include "ENiX_STRING.h"
#include "ENiX_LIST.h"
#include "ENiX_WMS.h"
#include "ENiX_CS.h"
#include "ENiX_TIME.h"
#include "ENiX_OUTPUT.h"
#include "ENiX_SETTHEORY.h"
#include "ENiX_NLP.h"
#include "ENiX_REASON.h"

extern char *LogicTypes[];
extern char *LogicNLPStartStr[];
extern char *LogicNLPEndStr[];

extern char *YesNo[];

/*! \brief Debug reasoning processing.
 *
 */
struct List_Str *Reasoning_Debug(struct List_Str *Word_List,struct List_Str *L){
  ProcessReasoning(Word_List);
  return L;
}


/*! \brief Debug conditional sentence processing.
 *
 */
struct List_Str *Conditional_Debug(struct List_Str *Word_List,struct List_Str *L){
  struct Conditional *ConvertedSentence=NULL;

  ConvertedSentence=ConvertConditional(Word_List);

  if(ThinkOutLoud){

    printf("Conditional sentence: "); PrintList(ConvertedSentence->OriginalData);
    printf("Is Question... %s\n",YesNo[ConvertedSentence->IsQuestion]);
    printf("Is Active...   %s\n",YesNo[ConvertedSentence->IsActive]);
  
    printf("Causes     : ");
    if(ConvertedSentence->NumCauses)
      PrintListArray(ConvertedSentence->CauseSentences,ConvertedSentence->NumCauses);
    else
      puts("");
    printf("Cause Logic: %d\n",ConvertedSentence->CauseLogic);

    printf("Effects    : ");
    if(ConvertedSentence->NumEffects)
      PrintListArray(ConvertedSentence->EffectSentences,ConvertedSentence->NumEffects);
    else
      puts("");
    printf("Effect Logic: %d\n",ConvertedSentence->EffectLogic);

    printf("CauseSymbols: ");
    PrintList(ConvertedSentence->CauseSymbols);

    printf("EffectSymbols: ");
    PrintList(ConvertedSentence->EffectSymbols);

    }

  ConvertedSentence=ProcessConditional(ConvertedSentence);
  
  return L;
}

/*! \brief Debug related sentences.
 *
 */
void DebugRelated(struct Related *Rels){
  printf("Targets:           ");
  PrintList(Rels->Targets);
  printf("AffectedSentences: ");
  PrintList(Rels->AffectedSentences);
  printf("CanonicalTargets:  ");
  PrintList(Rels->CanonicalTargets);
  printf("CSNouns:           ");
  PrintList(Rels->CSNouns);
  printf("CSVerbs:           ");
  PrintList(Rels->CSVerbs);
}

/*! \brief Print half of the WMS database.
 *
 */
void PrintHalf(struct Datablock *Q){
  int B=0;
  struct Datablock *BF=NULL;
  BF=Q;
  while(BF){ 
    for(B=0;B<3;B++)
      if(BF->DS[B])
	PrintList(BF->DS[B]);
    BF=BF->Next;
  }
}

/*! \brief Print all of the WMS database.
 *
 */
void PrintDatabase(struct Datablock *Q[2]){
  int A=0,B=0;
  struct Datablock *BF[2];
  BF[0]=Q[0];
  BF[1]=Q[1];
  for(A=0;A<2;A++){
    while(BF[A]){ 
      if(A)
	printf("Data: "); 
      else
	printf("Rels: ");
      for(B=0;B<3;B++)
	if(BF[A]->DS[B])
	  PrintList(BF[A]->DS[B]);
      BF[A]=BF[A]->Next;
    }
  }
}

/*! \brief Print a WMS database record.
 *
 */
void Print_DB_Entry(struct Datablock *LS,int P){
  int _=0;
  struct List_Str *L1=NULL,*L2=NULL; 
  for(;LS;_++){ 
    if(_==P){
      if(strncmp(LS->DS[0]->Str,"cs",2)){
	printf("=[Datablock %05d]==========================================\n",_); 
	L1=LS->DS[0];
	printf("Name %23s Grammar %23s\n",Get_List_Element(L1,0),Get_List_Element(L1,1));
	printf("Purpose %20s Emotion %23s\n",Get_List_Element(L1,2),Get_List_Element(L1,3));
	printf("First Time %28s\n",FormatTime(Get_List_Element(L1,4))); 
	printf("Last Time %29s\n",FormatTime(Get_List_Element(L1,5)));
	printf("Probability    %13s Commands %22s\n",List2Str(AutoFormat(Str2List(Get_List_Element(L1,6)))),List2Str(AutoFormat(Str2List(Get_List_Element(L1,7)))));
	if((LS->DS[1])&&(LS->DS[2])){ 
	  puts("-[Comparisons]----------------------------------------------");
	  puts("Qualifier:                                            Value:"); 
	  for(L1=LS->DS[1],L2=LS->DS[2];L1&&L2;L1=L1->Next,L2=L2->Next)
	    printf("%-30s%30s\n",L1->Str,List2Str(AutoFormat(Str2List(L2->Str)))); 
	} 
	puts("============================================================"); 
      }
      else{
	printf("=[Metablock %05d]==========================================\n",_);
	L1=LS->DS[0];
	printf("Address %52s\n",List2Str(IntCSRecon(L1->Str)));
	printf("Grammar %52s\n",Get_List_Element(L1,1));
	printf("Purpose %20s Emotion %23s\n",Get_List_Element(L1,2),Get_List_Element(L1,3));
	printf("First Time %28s\n",FormatTime(Get_List_Element(L1,4))); 
	printf("Last Time %29s\n",FormatTime(Get_List_Element(L1,5)));
	printf("Probability    %13s Commands %22s\n",Get_List_Element(L1,6),Get_List_Element(L1,7));
	if((LS->DS[1])&&(LS->DS[2])){ 
	  puts("-[Comparisons]----------------------------------------------");
	  puts("CS Qualifier Ref:                              CS Value Ref:"); 
	  for(L1=LS->DS[1],L2=LS->DS[2];L1&&L2;L1=L1->Next,L2=L2->Next){
	    if(strncmp(L1->Str,"cs",2))
	      printf("%-60s\n",L1->Str);
	    else
	      printf("%-60s\n",List2Str(IntCSRecon(L1->Str)));
	    if(strncmp(L2->Str,"cs",2))
	      printf("%60s\n",L2->Str);
	    else
	      printf("%60s\n",List2Str(IntCSRecon(L2->Str)));
	  }
	} 
	puts("============================================================"); 
      }
    }
    LS=LS->Next;  
  }
}

/*! \brief Debug context addressible memory location.
 *
 */
struct List_Str *CSDebug(struct List_Str *Word_List,struct List_Str *L){
   int _=0;
   char *L1=NULL,*L2=NULL,*Reg=NULL,*CS=NULL;
   struct List_Str *Buffer=NULL;
   struct Datablock *DB=NULL;
   Buffer=Word_List;
   if(strncmp(Buffer->Str,"cs",2)){
      if(isdigit(Buffer->Str[0])){
	_=StrLen(Buffer->Str)+4;
	CS=(char *)malloc(_*sizeof(char));
	snprintf(CS,_-1,"cs%s",Buffer->Str);
	Buffer->Str=CS;
      }
   }
   if(Buffer){
     L1=Buffer->Str;
     Buffer=Buffer->Next;
     while(Buffer){
       L2=Buffer->Str;
       Reg=CSFind(L1,L2);
       L1=Reg;
       Buffer=Buffer->Next;
     }
   }
   if(!(DB=Goto_DB_Entry(Database[1],L1)))
     ANSWER=NULL;
   else
     Print_DB_Entry(DB,0);
   return L;
}

/*! \brief Show the records containing neural network data and other methods.
 *
 */
struct List_Str *Show_Pattern(struct List_Str *WordList, struct List_Str *L){
   int i=0,Stream=0,Layer=0,Type=0,Logic=0,I1=0,I2=0,Position=0;
   char *RelationName=NULL;
   struct Datablock *R=NULL;
   struct List_Str *Cluster=NULL,*Data=NULL,*Pos=NULL;
   for(Pos=WordList;Pos;Pos=Pos->Next){
     if((Position=Find_DB_Entry(Database[0],RelationName=Pos->Str))+1){
       R=Goto_DB_Entry(Database[0],RelationName);
       Cluster=Str2List(Get_DB_Entry(R,0,7));
       printf("=[Relationship %05d]=======================================\n",Position); Data=R->DS[0];
       printf("Name %23s Complexity %20s\n",Get_List_Element(Data,0),Get_List_Element(Data,1));
       printf("Inputs %21s Outputs %23s\n",Get_List_Element(Data,2),Get_List_Element(Data,3));
       printf("First Time %28s\n",FormatTime(Get_List_Element(Data,4))); 
       printf("Last Time %29s\n",FormatTime(Get_List_Element(Data,5)));
       printf("Probability    %45s\n",Get_List_Element(Data,6));
       puts("-[Logic Grid]-----------------------------------------------");
       puts("             Bitstream Layer Type Gate In1 In2");
       while(Cluster&&strcmp(Cluster->Str,"?")){
	 Stream=atof(Cluster->Str);     Cluster=Cluster->Next;
	 Layer=atof(Cluster->Str);      Cluster=Cluster->Next;
	 Type=atof(Cluster->Str);       Cluster=Cluster->Next;
	 Logic=atof(Cluster->Str);      Cluster=Cluster->Next;
	 I1=atof(Cluster->Str);         Cluster=Cluster->Next;
	 I2=atof(Cluster->Str);         Cluster=Cluster->Next;
	 printf("             %9d %5d %4d %4d %3d %3d\n",Stream,Layer,Type,Logic,I1,I2);
       }
       WordList=WordList->Next;
       Data=R->DS[1];
       i=0;
       if(Data){
	 puts("-[Scenerio Bit: Token]--------------------------------------");
	 while(Data){ printf("%03d: %55s\n",i,Data->Str); i++; Data=Data->Next; }
       }
       Data=R->DS[2];
       i=0;
       if(Data){
	 puts("-[Outcome  Bit: Token]--------------------------------------");
	 while(Data){ printf("%03d: %55s\n",i,Data->Str); i++; Data=Data->Next; }
       }
       puts("============================================================");
     }
     else
       puts("Concept not found.");
   }
   return L;
}

/*! \brief Show the directed graphs (like Hidden Markov Models) learnt by ENiX.
 *
 */
struct List_Str *MapLanguage(struct List_Str *WordList,struct List_Str *L){
  int _=0,Found=0;
  struct List_Str *SRC=NULL,*Articles=NULL,*MoodCategories=NULL,*CACHE=NULL,*CACHE2=NULL,*Out=NULL;
  struct Datablock *DB=NULL;
  SRC=WordList;
  Articles=Str2List(Get_DB_Entry(Goto_DB_Entry(Database[1],SRC->Str),0,7));
  DB=GetLang();
  if(!DB){
    if(ThinkOutLoud)
      puts("ERROR: :GRAPHS not setup in default language!");
    return L;
  }
  _=Find_List_Element(DB->DS[1],":graphs");
  if(_+1)
    MoodCategories=Str2List(Get_List_Element(DB->DS[2],_));
  else{
    if(ThinkOutLoud)
      puts("ERROR: :GRAPHS not setup in default language!");
    return L;
  }
  printf("Moods of grammar:    ");
  PrintList(MoodCategories); 
  printf("Articles of grammar: "); 
  PrintList(Articles);
  while(MoodCategories){
    CACHE=Articles;
    printf(" * %s:\n",MoodCategories->Str);
    while(CACHE){
      _=0;
      Found=0;
      printf("   %20s -> ",CACHE->Str);
      CACHE2=(DB=Goto_DB_Entry(Database[1],CACHE->Str))->DS[2];
      Out=NULL;
      while(CACHE2){
	if(Is_List_Element(Str2List(CACHE2->Str),MoodCategories->Str)){
	  Out=Add2Set(Out,Get_List_Element(DB->DS[1],_));
	  Found=1;
	}
	CACHE2=CACHE2->Next;
	_++;
      }
      if(!Found)
	Out=Ins_List_Element(Out,"N/A",0);
      PrintList(Out);
      CACHE=CACHE->Next;
    }
    MoodCategories=MoodCategories->Next;
  }
  return L;
}

/*! \brief Command interface to debugging the WMS records.
 *
 */
struct List_Str *Debug(struct List_Str *Word_List,struct List_Str *L){
   if(Word_List)
      while(Word_List){
	 Print_DB_Entry(Database[1],Find_DB_Entry(Database[1],Word_List->Str));
	 Word_List=Word_List->Next;
      }
   else
     PrintDatabase(Database);
   return L;
}

/*! \brief Shows the status of the language configuration.
 *
 */
struct List_Str *Language_Debug(struct List_Str *WordList,struct List_Str *R){
   int Found=0,_=0,StartSentence=0,EndSentence=0;
   char *LANG=NULL;
   struct Datablock *B=NULL,*MODE=Database[1];
   struct List_Str *L=NULL;
   puts("=[:LANGUAGEDEBUG]===========================================");
   puts("-[COMPONENT]--------------[STATUS]--------------------------");
   printf(" :MODE....................");
   if((MODE=Goto_DB_Entry(Database[1],":mode"))){
   printf("OK\n LANGUAGE.................");
      LANG=Get_DB_Entry(MODE,0,1);
      if(!LANG)
	puts("MISSING");
      else{
	puts(LANG);
	printf(" %-25s",LANG);
	if((B=Goto_DB_Entry(Database[1],LANG))){
	  puts("OK");
	  L=Str2List(Get_DB_Entry(B,0,7));
	  _=0;
	  while(L){
	    if(!strcmp(L->Str,"startsentence"))
	      StartSentence=1;
	    if(!strcmp(L->Str,"endsentence"))
	      EndSentence=1;
	    L=L->Next;
	    _++;
	  }
	  Found=Find_List_Element(B->DS[1],":sentenceunit");
	  printf(" ENTRIES..................%d\n",_);
	  printf(" startsentence............");
	  if(StartSentence)
	    puts("OK");
	  else
	    puts("MISSING");
	  printf(" endsentence..............");
	  if(EndSentence)
	    puts("OK");
	  else
	    puts("MISSING");
	  printf(" :SENTENCEUNIT............");
	  if(Found>-1)
	    puts("OK");
	  else
	    puts("MISSING");
	  Found=Find_List_Element(B->DS[1],":question");
	  printf(" :QUESTION................");
	  if(Found>-1)
	    puts("OK");
	  else
	    puts("MISSING");
	  Found=Find_List_Element(B->DS[1],":yn");
	  printf(" :YN......................");
	  if(Found>-1)
	    puts("OK");
	  else
	    puts("MISSING");
	  Found=Find_List_Element(B->DS[1],":wh");
	  printf(" :WH......................");
	  if(Found>-1)
	    puts("OK");
	  else
	    puts("MISSING");
	  printf(" :SENTIENCY...............");
	  if(Found>-1)
	    puts("ACTIVATED");
	  else
	    puts("DORMENT");
	  Found=Find_List_Element(B->DS[1],":nouns");
	  printf(" :NOUNS...................");
	  if(Found>-1)
	    puts("OK");
	  else
	    puts("MISSING");
	  Found=Find_List_Element(B->DS[1],":subj");
	  printf(" :SUBJ....................");
	  if(Found>-1)
	    puts("OK");
	  else
	    puts("MISSING");
	  Found=Find_List_Element(B->DS[1],":predverbs");
	  printf(" :PREDVERBS...............");
	  if(Found>-1)
	    puts("OK");
	  else
	    puts("MISSING");
	  Found=Find_List_Element(B->DS[1],":setnull");
	  printf(" :SETNULL.................");
	  if(Found>-1)
	    puts("OK");
	  else
	    puts("MISSING");
	  /* needs fixing the argue has been moved into emotion */
	  Found=Find_List_Element(B->DS[1],"argue");
	  printf(" :ARGUE...................");
	  if(Found>-1)
	    puts("OK");
	  else
	    puts("MISSING");
	  Found=Find_List_Element(B->DS[1],":graphs");
	  printf(" :GRAPHS..................");
	  if(Found>-1)
	    PrintList(Str2List(Get_List_Element(B->DS[2],Found)));
	  else
	    puts("MISSING");
	  Found=Find_List_Element(B->DS[1],":whqevent");
	  printf(" :WHQEVENT................");
	  if(Found>-1)
	    PrintList(Str2List(Get_List_Element(B->DS[2],Found)));
	  else
	    puts("MISSING");
	  Found=Find_List_Element(B->DS[1],":ynqevent");
	  printf(" :YNQEVENT................");
	  if(Found>-1)
	    PrintList(Str2List(Get_List_Element(B->DS[2],Found)));
	  else
	    puts("MISSING");
	  Found=Find_List_Element(B->DS[1],":infoevent");
	  printf(" :INFOEVENT...............");
	  if(Found>-1)
	    PrintList(Str2List(Get_List_Element(B->DS[2],Found)));
	  else
	    puts("MISSING");
	  Found=Find_List_Element(B->DS[1],":impevent");
	  printf(" :IMPEVENT................");
	  if(Found>-1)
	    PrintList(Str2List(Get_List_Element(B->DS[2],Found)));
	  else
	    puts("MISSING");
	  printf(" :PVF.....................");
	  if(Goto_DB_Entry(Database[1],":pvf"))
            puts("PRESENT");
	  else
	    puts("MISSING");
	  Found=Find_List_Element(B->DS[1],":auxverbs");
	  printf(" :AUXVERBS................");
	  if(Found>-1)
	    printf("%d\n",Size_of_List(Str2List(Get_List_Element(B->DS[2],Found))));
	  else
	    puts("MISSING");
	}
	else
	  puts("MISSING");
      }
   }
   else
     puts("MISSING");
   puts(" [i] If you see any MISSING language is not setup properly.");
   puts("============================================================");
   return R;
}

/*! \brief Shows the deconstruction of a sentence.
 *
 */
struct List_Str *Sentencedebug(struct List_Str *Word_List,struct List_Str *L){
  struct Sentence *SData=ConvertSentence(Word_List,0,1);
  int Word_P=0;
  char *Flags="NNN:NNN";
  struct List_Str *Input=NULL,*Buffer1=NULL,*Grammar=NULL;
  struct Datablock *DB=NULL;
  Input=Word_List;
  puts("=[SENTENCE DEBUG]=================[GRAMMAR][PURPOSE]===[EMOTION]");
  Buffer1=Input;
  while(Input){
    DB=Goto_DB_Entry(Database[1],Input->Str);
    printf("  %-20s %19s  %-9s %9s\n",Input->Str,Get_DB_Entry(DB,0,1),Get_DB_Entry(DB,0,2),Get_DB_Entry(DB,0,3));
    Grammar=Ins_List_Element(Grammar,Get_DB_Entry(DB,0,1),Word_P++);
    Input=Input->Next;
  }
  Input=Buffer1;
  puts("-[COMPONENT]------------------------[VALUE]---------------------");
  printf("  Sentiency                          ");
  if(Detect_Sentiency())
    puts("Active");
  else
    puts("Dorment / Uninitialized");
  printf("  Sentence mood                      ");
  if(SData->Mood)
    puts(SData->Mood);
  else
    puts("N/A");
  printf("  Sentence voice                     ");
  if(SData->PassiveVoice) 
    puts("Passive");
  else
    puts("Active");
  printf("  SentenceStructure                  ");
  if(SData->SentenceStructure) 
    PrintList(SData->SentenceStructure);
  else
    puts("N/A");
  printf("  Subject                            ");
  if(SData->Subject)
    PrintList(SData->Subject);
  else
    puts("N/A");
  printf("  PredicateNounBlock                 ");
  if(SData->PredicateNounBlock)
    PrintList(SData->PredicateNounBlock);
  else
    puts("N/A");
  printf("  PredicateVerbBlock                 ");
  if(SData->PredicateVerbBlock)
    PrintList(SData->PredicateVerbBlock);
  else
    puts("N/A");
  printf("  Final Subject                      ");
  if(SData->RefinedSubject)
    PrintListSpecial("[",SData->RefinedSubject,"][","][","]\n");
  else
    puts("N/A");
  printf("  Final Predicate                    ");
  if(SData->RefinedPredicate)
    PrintListSpecial("[",SData->RefinedPredicate,"][","][","]\n");
  else
    puts("N/A");
  printf("  Subject / Predicate Logic          %s / %s\n",LogicTypes[SData->SubjectLogic],LogicTypes[SData->PredicateLogic]);
  printf("  Final Verb                         ");
  if(SData->RefinedVerb)
    PrintList(SData->RefinedVerb);
  else
    puts("N/A");
  printf("  Plurals S[AGP]:P[AGP]              ");
  if(SData->SIsPlural)        Flags[0]='Y';
  if(SData->SContainsGroup)   Flags[1]='Y';
  if(SData->SContainsPlurals) Flags[2]='Y';
  if(SData->PIsPlural)        Flags[4]='Y';
  if(SData->PContainsGroup)   Flags[5]='Y';
  if(SData->PContainsPlurals) Flags[6]='Y';
  puts(Flags);
  printf("  Is Negated                         ");
  if(SData->Negation)
    puts("Yes");
  else
    puts("No");
  puts("================================================================");
  return L;
}

/*! \brief Default command help screen.
 *
 */
void HelpSplash(){
  puts("ENiX 3 is meant to be used with parameters.");
  puts("Behavioral inhibitors are preceeded by \":\"");
  puts("User defined commands are not prefixed...");
  puts("Use \":help\"            - GPL [OvO]wl 2008.");
}


/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
