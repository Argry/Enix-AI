/*! \file */
#include "WMS_API.h"

/*! \brief Calling function for the WMS database Daemon.
 *  
 */
int main(){
  Daemon();
  return 0;
}
