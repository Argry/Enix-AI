/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "ENiX_Globals.h"
#include "ENiX_LIST.h"
#include "ENiX_STRING.h"
#include "ENiX_WMS.h"
#include "ENiX_WMS_COMPAT.h"
#include "ENiX_ANALYSER.h"
#include "ENiX_EMO.h"
#include "ENiX_HLR.h"
#include "ENiX_CS.h"

/*! \brief Attempts to generate an effect from a cause. 
 *
 */
struct List_Str  *AbstractComputeEffect(char *Name,struct List_Str *Cause){
   int _=0,A=0,B=0,Max=0,Position=0,Value=0;
   struct List_Str *R=NULL,*Buffer=NULL,*B1=NULL,*B2=NULL,*Causes=NULL,*Effects=NULL,*MultiplexIndices=NULL,*Multiplexed=NULL,*InstanceCause=NULL,*InstanceEffect=NULL;
   char *SortedCause=NULL,*LocalName=NULL;
   struct Datablock *DB=NULL,*NN=NULL;
   if(!Name){
      if(ThinkOutLoud) puts("No record to retrieve cause and effect from (1).");
      return NULL;
   }
   LocalName=StrCat("_enix_",Name);
   SortedCause=Cause?List2Str(SortList(Cause)):StrCat("","?");
   if(!(DB=Goto_DB_Entry(Database[0],Name))){
     if(ThinkOutLoud) puts("No record to retrieve cause and effect from (2).");
      return NULL;
   }
   Borg(Str2List(Name),NULL); /* assimilates the trail of multiplexed concepts left by topic changes into one coherent concept */
   if((_=Find_List_Element(DB->DS[1],SortedCause))+1){
     R=Str2List(Get_DB_Entry(DB,2,_));
   }
   else{
      for(Buffer=RemoveDups(SortList(Str2List(List2Str(DB->DS[1]))));Buffer;Buffer=Buffer->Next)
	if(strcmp(Buffer->Str,":null"))
	  Causes=Ins_List_Element(Causes,Buffer->Str,0);
      for(Buffer=RemoveDups(SortList(Str2List(List2Str(DB->DS[2]))));Buffer;Buffer=Buffer->Next)
	if(strcmp(Buffer->Str,":null"))
	  Effects=Ins_List_Element(Effects,Buffer->Str,0);
      if(!(NN=Goto_DB_Entry(Database[0],LocalName))){
	Database[0]=Add_DB_Entry(Database[0],LocalName);
	NN=Database[0];
      }
      NN->DS[1]=Causes;
      NN->DS[2]=Effects;
      Max=((A=Size_of_List(Causes))>(B=Size_of_List(Effects)))?A:B;
      for(_=0;_<Max;_++)
	 MultiplexIndices=Ins_List_Element(MultiplexIndices,FloatToString(1<<_),_);
      for(_=0;_<(1<<Max);_++)
	 Multiplexed=Ins_List_Element(Multiplexed,":unknown",_);
      InstanceCause=DB->DS[1];
      InstanceEffect=DB->DS[2];
      for(;InstanceCause;InstanceCause=InstanceCause->Next){
	 B1=Str2List(InstanceCause->Str);
	 B2=Str2List(InstanceEffect->Str);
	 Position=0;
	 Max=Size_of_List(B1);
	 if(strcmp(B1->Str,":null"))
	    for(_=0;_<Max;_++)
	      Position+=atoi(Get_List_Element(MultiplexIndices,Find_List_Element(Causes,Get_List_Element(B1,_))));
	 Max=Size_of_List(B2);
	 Value=0;
	 if(strcmp(B2->Str,":null"))
	   for(_=0;_<Max;_++)
	     Value+=atoi(Get_List_Element(MultiplexIndices,Find_List_Element(Effects,Get_List_Element(B2,_))));
	 Multiplexed=Del_List_Element(Multiplexed,Position);
	 Multiplexed=Ins_List_Element(Multiplexed,FloatToString(Value),Position);
	 InstanceEffect=InstanceEffect->Next;
      }
      Multiplexed=Ins_List_Element(Multiplexed,LocalName,0);

      Decision_Maker(Multiplexed,NULL);
      Understand(NULL,Ins_List_Element(NULL,LocalName,0));      
      AwarenessFeedback(atoi(ANSWER->Str));
      
      Max=Size_of_List(Buffer=Cause);
      Position=0;
      if(strcmp(Buffer->Str,":null"))
	for(_=0;_<Max;_++)
	  Position+=atoi(Get_List_Element(MultiplexIndices,Find_List_Element(Causes,Get_List_Element(Buffer,_))));

      Decide(Ins_List_Element(NULL,FloatToString(Position),0),Ins_List_Element(NULL,LocalName,0));

      Value=atoi(ANSWER->Str);
      Max=Size_of_List(Effects);
      R=NULL;
      Position=0;
      for(_=0;_<Max;_++)
	 R=((B=Find_List_Element(MultiplexIndices,FloatToString(Value&(1<<_))))+1)?Ins_List_Element(R,Get_List_Element(Effects,B),Position++):R;
   }
   if(R)
     if(!strcmp(R->Str,"?"))
       R=NULL;
   if(!R) R=Ins_List_Element(NULL,":null",0);
  return R;
}

/*! \brief This function adds additional data to ENiX neural network multiplexors so that all data is factored into the learning process.
 *
 */
struct List_Str *Borg(struct List_Str *Word_List,struct List_Str *L){
  int _=0,Found=0,Pos=0;
  struct List_Str *Targets=NULL,*Buffer=NULL,*Buffer2=NULL,*Buffer3=NULL,*Buffer4=NULL,*Reaper=NULL,*ExpandedTargets=NULL,*Temporary=NULL,*VerifiedTargets=NULL;
  struct Datablock *DBTarget=NULL,*DBReaper=NULL;
  AllRels(NULL,NULL);
  Targets=ANSWER;
  if(ThinkOutLoud){
    puts("Activating Trapper Keeper 2000");
    PrintListSpecial("Scanning for viable targets... [",Targets,"][","][","]\n");
  }
  for(Buffer=Targets;Buffer;Buffer=Buffer->Next){
    if(strncmp(Buffer->Str,"cs",2)){
      ExpandedTargets=Ins_List_Element(ExpandedTargets,Buffer->Str,_++);
    }
    else
      ExpandedTargets=Ins_List_Element(ExpandedTargets,List2Str(IntCSRecon(Buffer->Str)),_++); 
  }
  if(ThinkOutLoud)
    PrintListSpecial(" -> Exploding viable targets... [",ExpandedTargets,"][","][","]\n");
  for(Buffer=Word_List;Buffer;Buffer=Buffer->Next){
    DBReaper=Goto_DB_Entry(Database[0],Buffer->Str);
    Reaper=NULL;
    if(strncmp(Buffer->Str,"cs",2)){
      Reaper=Str2List(Buffer->Str);
    }
    else
      Reaper=IntCSRecon(Buffer->Str);
    if(ThinkOutLoud){
      printf("Reaper ID [%-6s],",Buffer->Str);
      PrintListSpecial("Elaborating: [",Reaper,"][","][","]\n");
    }
    _=0;
    Pos=0;
    VerifiedTargets=NULL;
    for(Buffer2=ExpandedTargets;Buffer2;Buffer2=Buffer2->Next){
      Found=1;
      Temporary=Str2List(Buffer2->Str);
      for(Buffer3=Temporary;Buffer3;Buffer3=Buffer3->Next)
	if(!Is_List_Element(Reaper,Buffer3->Str))
	  Found=0;
      if(Found)
	VerifiedTargets=Ins_List_Element(VerifiedTargets,Get_List_Element(Targets,Pos),_++);
      Pos++;
    }
    if(ThinkOutLoud){
      PrintListSpecial(" -> Reaper has confirmed targets: [",VerifiedTargets,"][","][","]\n");
      puts(" -> Assimilating... ");
      PrintListSpecial(" -> OLD DS[1]: [",DBReaper->DS[1],"][","][","]\n");
      PrintListSpecial(" -> OLD DS[2]: [",DBReaper->DS[2],"][","][","]\n");
    }
    for(Buffer2=VerifiedTargets;Buffer2;Buffer2=Buffer2->Next){
      DBTarget=Goto_DB_Entry(Database[0],Buffer2->Str);
      Buffer4=DBTarget->DS[2];
      for(Buffer3=DBTarget->DS[1];Buffer3;Buffer3=Buffer3->Next){
	if(!Is_List_Element(DBReaper->DS[1],Buffer3->Str)) /* this is to check that multiplexed data hasnt been added already */
	  Rep_DB_Pair(DBReaper,Buffer3->Str,Buffer4->Str);      /* else there could be a possible dependency conflict */
	Buffer4=Buffer4->Next;
      }
    }
    if(ThinkOutLoud){
      PrintListSpecial(" -> NEW DS[1]: [",DBReaper->DS[1],"][","][","]\n");
      PrintListSpecial(" -> NEW DS[2]: [",DBReaper->DS[2],"][","][","]\n");
      puts(" -> OK");
    }
  }
  if(ThinkOutLoud)
    puts("Resistance is futile.");
  return L;
}

/*! \brief Associate causes and effects to relationship records ready for the neural network.
 *
 */
struct List_Str *AbstractThinkingAssociates(char *Name,struct List_Str *Cause,struct List_Str *Effect){
   int _=0;
   char *SortedCause=NULL,*SortedEffect=NULL;
   struct Datablock *DB=NULL;
   if(!Name){
      if(ThinkOutLoud) puts("No record to associate cause and effect in.");
      return NULL;
   }
   SortedCause=Cause?List2Str(SortList(Cause)):StrCat("","?");
   SortedEffect=Effect?List2Str(SortList(Effect)):StrCat("","?"); 
   if(!(DB=Goto_DB_Entry(Database[0],Name))){
      Database[0]=Add_DB_Entry(Database[0],Name);
      DB=Database[0];
   }
   if((_=Find_List_Element(DB->DS[1],SortedCause))+1)
     Rep_DB_Entry(DB,2,_,SortedEffect);
   else
     Rep_DB_Pair(DB,SortedCause,SortedEffect);
   return NULL;
}



/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
