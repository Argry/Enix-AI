/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ENiX_SETTHEORY.h"       
#include "ENiX_NLP.h"
#include "ENiX_REASON.h"
#include "ENiX_MULTIPLEX.h"
#include "ENiX_WMS_COMPAT.h"
#include "ENiX_LIST.h"
#include "ENiX_CS.h"
#include "ENiX_SEMANTICS.h"
#include "ENiX_Globals.h"

/*! \brief Accept a sentence and if a question find causes or consequences otherwise process as a normal conditional.
 *
 */
struct List_Str *ProcessReasoning(struct List_Str *Sentence){
  struct List_Str *Result=NULL,*Buffer=NULL,*ExpandedBuffer=NULL;
  struct Conditional *ConvertedSentence=NULL;

  /*  
  DEBUG;
  */

  ConvertedSentence=ConvertConditional(Sentence);

  if(!ConvertedSentence->IsQuestion){
    /* if it is not a question run ProcessConditional as normal */
    ConvertedSentence=ProcessConditional(ConvertedSentence);  
  }
  else{
    Result=NULL;
    /* if it is a question then we need to process separately. */
    if((ConvertedSentence->CauseSymbols)&&(ConvertedSentence->EffectSymbols)){
      /* if is a yes no question - i.e. cause and effect are both supplied */
      Result=YNReasoning(ConvertedSentence);
      if(!Result)
	Result=Str2List("unknown");
      if(Result){
	for(Buffer=Result;Buffer;Buffer=Buffer->Next){
	  PrintListSpecial("",IntCSRecon(Buffer->Str)," "," "," ");
	  if(Buffer->Next)
	    printf(", and ");
	}
      }
      else
	puts("Nothing happens.");    
    }
    else if((!ConvertedSentence->CauseSymbols)&&(ConvertedSentence->EffectSymbols)){
      /* if is a reductive logic question - i.e. only effect is supplied */
      Result=ReductiveReasoning(ConvertedSentence);
      if(Result){
	for(Buffer=Result;Buffer;Buffer=Buffer->Next){
	  for(ExpandedBuffer=Str2List(Buffer->Str);ExpandedBuffer;ExpandedBuffer=ExpandedBuffer->Next){
	    PrintListSpecial("",IntCSRecon(ExpandedBuffer->Str)," "," "," ");
	    if(ExpandedBuffer->Next)
	      printf(", and ");
	  }
	  if(Buffer->Next)
	    puts("");
	}
      }
      else
	puts("Unknown.");    
    }
    else if((ConvertedSentence->CauseSymbols)&&(!ConvertedSentence->EffectSymbols)){
      /* if is a deductive logic question - i.e. only cause is supplied */
      Result=DeductiveReasoning(ConvertedSentence);
      if(Result){
	for(Buffer=Result;Buffer;Buffer=Buffer->Next){
	  PrintListSpecial("",IntCSRecon(Buffer->Str)," "," "," ");
	  if(Buffer->Next)
	    printf(", and ");
	}
      }
      else
	puts("Nothing happens.");    
    }

  }
  return Result;
}

/*! \brief Accept a sentence and find outcomes.
 *
 */
struct List_Str *DeductiveReasoning(struct Conditional *ConvertedSentence){
  struct List_Str *CalculatedCause=NULL,*CalculatedEffect=NULL,*AllEffects=NULL;
  int CurrentLevel=0;
  CalculatedCause=ConvertedSentence->CauseSymbols;  
  ConvertedSentence->EffectSymbols=NULL;
  for(CurrentLevel=0;CurrentLevel<REASONINGDEPTH;CurrentLevel++){
    ConvertedSentence->CauseSymbols=CalculatedCause;
    ConvertedSentence->EffectSymbols=NULL;
    ConvertedSentence=ForwardMultiplexConditional(ConvertedSentence);
    CalculatedEffect=ConvertedSentence->Answer;
    ConvertedSentence->Answer=NULL;
    AllEffects=Ins_List_List(AllEffects,CalculatedEffect,0);
    CalculatedCause=IntShrink(CalculatedEffect);
    CalculatedEffect=NULL;
    if(!CalculatedCause)
      break;
  }    
  AllEffects=IntShrink(AllEffects);
  return AllEffects;
}

/*! \brief Accept a sentence and find its causes.
 *
 */
struct List_Str *ReductiveReasoning(struct Conditional *ConvertedSentence){
  struct List_Str *CalculatedCause=NULL,*CalculatedEffect=NULL,*AllCauses=NULL;
  int CurrentLevel=0;
  CalculatedEffect=ConvertedSentence->EffectSymbols;
  ConvertedSentence->CauseSymbols=NULL;
  for(CurrentLevel=0;CurrentLevel<REASONINGDEPTH;CurrentLevel++){
    ConvertedSentence->EffectSymbols=CalculatedEffect;
    ConvertedSentence->CauseSymbols=NULL;
    ConvertedSentence=BackwardMultiplexConditional(ConvertedSentence);
    CalculatedCause=ConvertedSentence->Answer;
    ConvertedSentence->Answer=NULL;
    AllCauses=Ins_List_List(AllCauses,CalculatedCause,0);
    CalculatedEffect=IntShrink(CalculatedCause);
    CalculatedCause=NULL;
    if(!CalculatedEffect)
      break;
  }  
  AllCauses=IntShrink(AllCauses);
  return AllCauses;
}

/*! \brief Determine if the effect is a consequence of the cause.
 *
 */
struct List_Str *YNReasoning(struct Conditional *ConvertedSentence){
  struct List_Str *BufferedEffects=ConvertedSentence->EffectSymbols,*CalculatedEffects=NULL;
  CalculatedEffects=DeductiveReasoning(ConvertedSentence);
  return Str2List(IntSubset(BufferedEffects,CalculatedEffects)?"yes":"no");
}

/*! \brief Create a new sentence tree and initialise it to zero.
 *
 */
struct ReasonTree *NewTreeSentence(){
   struct ReasonTree *Tree=(struct ReasonTree *)malloc(sizeof(struct ReasonTree));
   Tree->NodeSize=0;
   Tree->Sentence=NULL;
   Tree->Next=(struct ReasonTree **)malloc(sizeof(struct ReasonTree *));
   Tree->Next[0]=NULL;
   Tree->Prev=NULL;
   return Tree;
}

/*! \brief Initialise the sentence tree to an initial sentence.
 *
 */
struct ReasonTree *AddTreeSentence(struct ReasonTree *Tree,struct List_Str *Sentence,struct List_Str *Common){
  Tree->Sentence=Sentence;
  Tree->Common=Common;
  return Tree;
}

/*! \brief Add a new sentence to the tree.
 *
 */
struct ReasonTree *AddTreeNext(struct ReasonTree *Root,struct ReasonTree *Leaf){
  Root->Next=(struct ReasonTree **)realloc(Root->Next,(Root->NodeSize+1)*sizeof(struct ReasonTree *));
  Root->Next[Root->NodeSize]=Leaf;
  Leaf->Prev=Root;
  Root->NodeSize++;
  return Root;
}

/*! \brief Display the sentence tree.
 *
 */
void TreeDebug(struct ReasonTree *Leaf,int Level){
  int _=0,C=0;
  for(_=0;_<Leaf->NodeSize;_++){
    for(C=0;C<Level;C++){
      printf("  ");
    }
    PrintListSpecial("  ",Leaf->Sentence," "," ","");
    PrintListSpecial(" [",Leaf->Common," "," ","]\n");
    TreeDebug(Leaf->Next[_],Level+1);
  }
}

/*! \brief Recurse through the sentence tree looking for semantic intersection.
 *
 */
struct ReasonTree *TreeRecurse(struct ReasonTree *Leaf,struct List_Str *SentenceList){
  struct List_Str *Buffer=NULL,*Buffer2=NULL,*SubNouns=NULL,*PredNouns=NULL,*PredVerbs=NULL,*LocalSentenceList=NULL,*Search=NULL,*Common=NULL;
  struct ReasonTree *Tree=NULL,*OldTree=NULL;
  struct Sentence *Sentence=ConvertSentence(Leaf->Sentence,0,0);
  /*
  SubNouns=Sentence->SubjectNouns;
  PredNouns=Sentence->PredicateNouns;
  */
  SubNouns=Sentence->RefinedSubject;
  PredNouns=Sentence->RefinedPredicate;
  PredVerbs=ExtractArticles(Sentence->PredicateVerbBlock,"noun pronoun propernoun");
  Search=Ins_List_List(SubNouns,PredNouns,0);
  Search=Ins_List_List(Search,PredVerbs,0);
  for(Buffer=SentenceList;Buffer;Buffer=Buffer->Next){
    Buffer2=Str2List(Buffer->Str);
    if((Common=IntIntersect(Search,Buffer2))){
      LocalSentenceList=SetExclude(SentenceList,Ins_List_Element(NULL,Buffer->Str,0));
      OldTree=Leaf;
      /* Create a new tree */
      Tree=AddTreeSentence(NewTreeSentence(),Str2List(Buffer->Str),Common);
      /* add it to the bottom of the old tree */
      OldTree=AddTreeNext(OldTree,Tree);
      /* recurse one below the old tree i.e. the Tree */
      OldTree->Next[OldTree->NodeSize-1]=TreeRecurse(Tree,LocalSentenceList);
      Leaf=OldTree;
    }
  }
  return Leaf;
}

/*! \brief Populate the sentence tree with semantic information.
 *
 */
struct List_Str *TreeGenerate(struct List_Str *Word_List,struct List_Str *L){
  struct List_Str *SentenceList=NULL,*Buffer=NULL,*Buffer2=NULL;
  struct ReasonTree *Tree=NULL;
  ListSentences(CSList(),NULL);
  for(Buffer=ANSWER;Buffer;Buffer=Buffer->Next){
    CS2Sentence(Str2List(Buffer->Str),NULL);
    for(Buffer2=ANSWER;Buffer2;Buffer2=Buffer2->Next){
      SentenceList=Ins_List_Element(SentenceList,Buffer2->Str,0);
    }
  }  
  Tree=AddTreeSentence(NewTreeSentence(),Word_List,NULL);
  Tree=TreeRecurse(Tree,SentenceList);
  TreeDebug(Tree,0);
  return L;
}

/*! \brief Find similar sentences with many to many NLP meanings in common. 
 * - Many to many means that similar meanings to the meaning being searched is searched through other sentences with similar meanings.
 */
struct List_Str **NLPCauseM2M(struct List_Str *Source,struct List_Str *Target,struct List_Str *Available,int *ReturnSize){
  int _=0,Position=0,LocalSize=0;
  struct List_Str **R=NULL,*Buffer1=NULL,*Buffer2=NULL,*Sentence=NULL,*Buffer3=NULL,*Buffer4=NULL;
  struct List_Str *NewAvailable=NULL,*SourcePred=NULL,*TargetSub=NULL,**Recvd=NULL,*Similar=NULL;
  struct List_Str **Total=NULL;
  struct Sentence *SentenceData=NULL;
  if(!Available){
    return NULL;
  }
  if(IsSentenceSimilar(Source,Target)){
    R=Add_To_Array(R,Ins_List_Element(NULL,List2Str(Source),0),0);
    *ReturnSize=1;
    return R;
  }  
  /* checking through the source sentence because looking for similar MEANINGS */
  for(Buffer1=Available;Buffer1;Buffer1=Buffer1->Next){
    CS2Sentence(Str2List(Buffer1->Str),NULL);
    if((_=Find_List_Element(Available,Buffer1->Str))!=-1){
      NewAvailable=Cpy_List(Available);
      NewAvailable=Del_List_Element(NewAvailable,_);
    }
    for(Buffer2=ANSWER;Buffer2;Buffer2=Buffer2->Next){
      Similar=Str2List(Buffer2->Str);
      if(IsSentenceSimilar(Source,Similar)){
	/* need to find the predicate and search the subjects in sentences for predicate matches */	
	SentenceData=ConvertSentence(Similar,0,0);
	SourcePred=ExtractArticles(Str2List(List2Str(SentenceData->RefinedPredicate)),"noun pronoun propernoun adjective");
	for(Buffer3=NewAvailable;Buffer3;Buffer3=Buffer3->Next){
	  CS2Sentence(Str2List(Buffer3->Str),NULL);
	  for(Buffer4=ANSWER;Buffer4;Buffer4=Buffer4->Next){
	    Sentence=Str2List(Buffer4->Str);
	    SentenceData=ConvertSentence(Sentence,0,0);
	    TargetSub=Str2List(List2Str(SentenceData->RefinedSubject));
	    if(AtomMeanLike(List2Str(SourcePred),List2Str(TargetSub))){
	      /* Need to recurse next phase */
	      Recvd=NLPCauseM2M(Sentence,Target,NewAvailable,&LocalSize);
	      if(Recvd){
		for(_=0;_<LocalSize;_++){
		  Recvd[_]=Ins_List_Element(Recvd[_],List2Str(Similar),0);
		  Total=Add_To_Array(Total,Recvd[_],Position++);
		}
	      }
	    }
	  }
	}
      }
    }
  }
  if(Total){
    *ReturnSize=Position;
  }
  return Total;
}

/*! \brief Find similar sentences with one to one NLP meanings in common. 
 * - One to one means that only the meaning being searched is searched through other sentences with meaning.
 */
struct List_Str **NLPCauseO2O(struct List_Str *Source,struct List_Str *Target,struct List_Str *Available,int *ReturnSize){
  int _=0,Position=0,LocalSize=0;
  struct List_Str **R=NULL,*Buffer1=NULL,*Buffer2=NULL,*Sentence=NULL;
  struct List_Str *NewAvailable=NULL,*SourceSub=NULL,*SourcePred=NULL,*SourceVerb=NULL;
  struct List_Str *TargetSub=NULL,*TargetPred=NULL,*TargetVerb=NULL,**Recvd=NULL;
  struct List_Str **Total=NULL;
  struct Sentence *SentenceData=NULL;
  if(!Available)
    return NULL;
  if(IsSentenceSimilar(Source,Target)){
    R=Add_To_Array(R,Ins_List_Element(NULL,List2Str(Source),0),0);
    *ReturnSize=1;
    return R;
  }  
  SentenceData=ConvertSentence(Source,0,0);
  SourceSub=ExtractArticles(Str2List(List2Str(SentenceData->RefinedSubject)),"noun pronoun propernoun adjective");
  SourcePred=ExtractArticles(Str2List(List2Str(SentenceData->RefinedPredicate)),"noun pronoun propernoun adjective");
  SourceVerb=SentenceData->RefinedVerb;
  /* Need to deduct it from the available list */
  for(Buffer1=Available;Buffer1;Buffer1=Buffer1->Next,_++){
    CS2Sentence(Str2List(Buffer1->Str),NULL);
    for(Buffer2=ANSWER;Buffer2;Buffer2=Buffer2->Next){
      SentenceData=ConvertSentence(Str2List(Buffer2->Str),0,0);
      TargetSub=ExtractArticles(Str2List(List2Str(SentenceData->RefinedSubject)),"noun pronoun propernoun adjective");
      TargetPred=ExtractArticles(Str2List(List2Str(SentenceData->RefinedPredicate)),"noun pronoun propernoun adjective");
      TargetVerb=SentenceData->RefinedVerb;
      if(SourceSub&&TargetSub&&TargetPred&&TargetSub)
	if((!strcmp(List2Str(SourceSub),List2Str(TargetSub)))&&(!strcmp(List2Str(SourcePred),List2Str(TargetPred)))&&(!strcmp(List2Str(SourceVerb),List2Str(TargetVerb)))){
	  NewAvailable=Cpy_List(Available);
	  NewAvailable=Del_List_Element(NewAvailable,_);
      }
    }
  }
  for(Buffer1=NewAvailable;Buffer1;Buffer1=Buffer1->Next){
    CS2Sentence(Str2List(Buffer1->Str),NULL);
    for(Buffer2=ANSWER;Buffer2;Buffer2=Buffer2->Next){
      Sentence=Str2List(Buffer2->Str);
      SentenceData=ConvertSentence(Sentence,0,0);
      TargetSub=ExtractArticles(Str2List(List2Str(SentenceData->RefinedSubject)),"noun propernoun pronoun adjective");
      if(!strcmp(List2Str(SourcePred),List2Str(TargetSub))){
	/* Need to recurse next phase */
	Recvd=NLPCauseO2O(Sentence,Target,NewAvailable,&LocalSize);
	if(Recvd){
	  for(_=0;_<LocalSize;_++){
	    Recvd[_]=Ins_List_Element(Recvd[_],List2Str(Source),0);
	    Total=Add_To_Array(Total,Recvd[_],Position++);
	  }
	}
      }
    }
  }
  if(Total)
    *ReturnSize=Position;
  return Total;
}

/*! \brief Find similar sentences with one to many NLP meanings in common. 
 * - One to many means that only the meaning being searched is searched through other sentences with similar meanings.
 */
struct List_Str **NLPCauseO2M(struct List_Str *Source,struct List_Str *Target,struct List_Str *Available,int *ReturnSize){
  int _=0,Position=0,LocalSize=0;
  struct List_Str **R=NULL,*Buffer1=NULL,*Buffer2=NULL,*Sentence=NULL;
  struct List_Str *NewAvailable=NULL,*SourceSub=NULL,*SourcePred=NULL,*SourceVerb=NULL;
  struct List_Str *TargetSub=NULL,*TargetPred=NULL,*TargetVerb=NULL,**Recvd=NULL;
  struct List_Str **Total=NULL;
  struct Sentence *SentenceData=NULL;
  if(!Available)
    return NULL;
  if(IsSentenceSimilar(Source,Target)){
    R=Add_To_Array(R,Ins_List_Element(NULL,List2Str(Source),0),0);
    *ReturnSize=1;
    return R;
  }  
  SentenceData=ConvertSentence(Source,0,0);
  SourceSub=ExtractArticles(Str2List(List2Str(SentenceData->RefinedSubject)),"noun pronoun propernoun adjective");
  SourcePred=ExtractArticles(Str2List(List2Str(SentenceData->RefinedPredicate)),"noun pronoun propernoun adjective");
  SourceVerb=SentenceData->RefinedVerb;

  /* Need to deduct it from the available list */
  for(Buffer1=Available;Buffer1;Buffer1=Buffer1->Next,_++){
    CS2Sentence(Str2List(Buffer1->Str),NULL);
    for(Buffer2=ANSWER;Buffer2;Buffer2=Buffer2->Next){
      SentenceData=ConvertSentence(Str2List(Buffer2->Str),0,0);
      TargetSub=ExtractArticles(Str2List(List2Str(SentenceData->RefinedSubject)),"noun pronoun propernoun adjective");
      TargetPred=ExtractArticles(Str2List(List2Str(SentenceData->RefinedPredicate)),"noun pronoun propernoun adjective");
      TargetVerb=SentenceData->RefinedVerb;

      if(SourceSub&&TargetSub&&TargetPred&&TargetSub)
	if((!strcmp(List2Str(SourceSub),List2Str(TargetSub)))&&(!strcmp(List2Str(SourcePred),List2Str(TargetPred)))&&(!strcmp(List2Str(SourceVerb),List2Str(TargetVerb)))){
	  NewAvailable=Cpy_List(Available);
	  NewAvailable=Del_List_Element(NewAvailable,_);
	}
    }
  }

  for(Buffer1=NewAvailable;Buffer1;Buffer1=Buffer1->Next){
    CS2Sentence(Str2List(Buffer1->Str),NULL);
    for(Buffer2=ANSWER;Buffer2;Buffer2=Buffer2->Next){
      Sentence=Str2List(Buffer2->Str);
      SentenceData=ConvertSentence(Sentence,0,0);
      TargetSub=ExtractArticles(Str2List(List2Str(SentenceData->RefinedSubject)),"noun pronoun propernoun adjective");
      if(AtomMeanLike(List2Str(SourcePred),List2Str(TargetSub))){
	/* Need to recurse next phase */
	Recvd=NLPCauseO2M(Sentence,Target,NewAvailable,&LocalSize);
	if(Recvd)
	  for(_=0;_<LocalSize;_++){
	    Recvd[_]=Ins_List_Element(Recvd[_],List2Str(Source),0);
	    Total=Add_To_Array(Total,Recvd[_],Position++);
	  }
      }
    }
  }
  if(Total)
    *ReturnSize=Position;
  return Total;
}

/*! \brief Process alternate causes.
 * - Unfinished
 */
struct List_Str **NLPCauseAlt(struct List_Str *Source,struct List_Str *Target,struct List_Str *Available,int *ReturnSize){
  struct List_Str **R=NULL;
  
  
  return R;
}

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
