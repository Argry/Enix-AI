/*! \file */

/*

This file is part of ENiX3.

ENiX3 is free software you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ENiX3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ENiX3.  If not, see <http://www.gnu.org/licenses/>.

       oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP    888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP      888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb    888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


Programmed By M.S.Braithwaite 2007 - 2012.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ENiX_Globals.h"
#include "ENiX_STRING.h"
#include "ENiX_LIST.h"
#include "ENiX_WMS.h"
#include "ENiX_WMS_COMPAT.h"
#include "ENiX_NLP.h"
#include "ENiX_SPLINE.h"
#include "ENiX_CS.h"

struct List_Str  *Disambiguated;
int              InterceptedSpirit;

int              Route_Shortest_Length;
struct List_Str  *Route_Shortest;
struct List_Str  *Route_Length;

/*! \brief This function determines what Directed Graph (Hidden Markov Model) the sentence belongs to.
 * - Determines if the sentence is Imperative, Indicative, YN-Question, WH-Question, etc.
 */
char *Spirit(struct List_Str *WordList,int AutoLearnWords){ /* this is the heart of NLP - where there is a will there is a way */
   int Found=0,First=1,C=0,_=0,Overflow=0,SentenceNumber=0,SentenceLength=0,NumArticles=0,Possible_Meanings=1,*Chaos_Template=NULL,*Chaos_Position=NULL,*Graph=NULL,*GraphBuffer=NULL,*FinalGraphs=NULL,SentenceMatches=0,NumofGraphs=0,ValidSentence=0,NeededMB=0,MaxMB=0;
   char *Prev=NULL,*New=NULL,*Article_String=NULL,*AllBaseArtStr=NULL,*CharMemMax=NULL,*Classification=NULL;
   struct Datablock *ROM_Lang=GetLang(),**ROM_Articles=NULL,*DB=NULL;
   struct List_Str *L=NULL,*AllArts=NULL,*BaseArts=NULL,*Buffer=NULL,**ROM_Meanings=NULL,*ROM_Art_Template=NULL,*GraphNow=NULL,*FinalAns=NULL,*DGS=NULL,*SentenceUnits=NULL;
   DB=GetLang();
   InterceptedSpirit=0;
   if(!DB){
      if(ThinkOutLoud)
	puts("ERROR: Language not set up correctly!");
      return NULL;
   }
   
   if(!((_=Find_List_Element(DB->DS[1],":graphs"))+1)){
      if(ThinkOutLoud)
	puts("ERROR: Graphs not set up correctly!");
      return NULL;
   }
   DGS=Str2List(Get_List_Element(DB->DS[2],_));
   NumofGraphs=Size_of_List(DGS);
   AllArts=Str2List(Get_DB_Entry(ROM_Lang,0,7));
   _=0;
   for(L=AllArts;L;L=L->Next)
     if((strcmp(L->Str,"startsentence"))&&(strcmp(L->Str,"endsentence")))
       BaseArts=Ins_List_Element(BaseArts,L->Str,_++);
   AllBaseArtStr=List2Str(BaseArts);
   Chaos_Template=(int *)malloc((SentenceLength=Size_of_List(Buffer=WordList))*sizeof(int));
   Chaos_Position=(int *)malloc(SentenceLength*sizeof(int));
   Graph=(int *)malloc(NumofGraphs*sizeof(int));
   GraphBuffer=(int *)malloc(NumofGraphs*sizeof(int));
   FinalGraphs=(int *)malloc(NumofGraphs*sizeof(int));
   NumArticles=Size_of_List(BaseArts);
   for(_=0;Buffer;Buffer=Buffer->Next){
     Article_String=Get_DB_Entry(Goto_DB_Entry(Database[1],Buffer->Str),0,1);
     if(strcmp(Article_String,"?")){
       ROM_Art_Template=Ins_List_Element(ROM_Art_Template,Article_String,_);
       Chaos_Template[_]=Size_of_List(Str2List(Article_String));
     }
     else{
       ROM_Art_Template=Ins_List_Element(ROM_Art_Template,AllBaseArtStr,_);
       Chaos_Template[_]=NumArticles;
     }
     Possible_Meanings*=Chaos_Template[_];
     Chaos_Position[_++]=0;
   }
   NeededMB=(Possible_Meanings*sizeof(struct List_Str)>>20);
   CharMemMax=GetValue(":limits");
   if(CharMemMax){
      MaxMB=atoi(CharMemMax);
      if((MaxMB<(NeededMB))&&(NeededMB>0)){
	 if(ThinkOutLoud)
	   printf("Memory required %dMB, allocated to this task %dMB.\n",NeededMB,MaxMB);
	 return NULL;
      }
   }
   ROM_Meanings=(struct List_Str **)malloc(Possible_Meanings*sizeof(struct List_Str));
   ROM_Articles=(struct Datablock **)malloc(Size_of_List(AllArts)*sizeof(struct Datablock));
   _=0;
   for(Buffer=AllArts;Buffer;Buffer=Buffer->Next)
     ROM_Articles[_++]=Goto_DB_Entry(Database[1],Buffer->Str);
   for(_=0;_<NumofGraphs;_++) FinalGraphs[_]=0;
   for(SentenceNumber=0;SentenceNumber<Possible_Meanings;SentenceNumber++){
      ROM_Meanings[SentenceNumber]=NULL; L=ROM_Art_Template; First=1; Overflow=0;
      for(_=0;_<SentenceLength;_++){
	 if(Chaos_Template[_]>1){
	    ROM_Meanings[SentenceNumber]=Ins_List_Element(ROM_Meanings[SentenceNumber],Get_List_Element(Str2List(L->Str),Chaos_Position[_]),_);
	    if(First||Overflow){ 
	       Chaos_Position[_]++; First=0;    
	       if(Overflow) Overflow=0;
	    }
	    if(Chaos_Position[_]==Chaos_Template[_]){ Chaos_Position[_]=0; Overflow=1; }
	 }
	 else ROM_Meanings[SentenceNumber]=Ins_List_Element(ROM_Meanings[SentenceNumber],L->Str,_);
	 L=L->Next;
      }
      ROM_Meanings[SentenceNumber]=Ins_List_Element(ROM_Meanings[SentenceNumber],"endsentence",_++);    
      if(ThinkOutLoud){ printf("Analysis %03d: ",SentenceNumber); PrintList(ROM_Meanings[SentenceNumber]); } 
      Prev="startsentence";
      for(_=0;_<NumofGraphs;_++)
	Graph[_]=1;
      for(L=ROM_Meanings[SentenceNumber];L;L=L->Next){
	 New=L->Str;
	 for(_=0;_<NumArticles;_++)
	   if(!strcmp(Get_DB_Entry(ROM_Articles[_],0,0),Prev)){
	      DB=ROM_Articles[_];
	      _=NumArticles;
	   }
	 GraphNow=NULL; C=0;
	 for(_=0;_<NumofGraphs;_++) GraphBuffer[_]=0;
	 for(Buffer=DB->DS[1];Buffer;Buffer=Buffer->Next){
	    if(!strcmp(Buffer->Str,New)) GraphNow=Str2List(Get_List_Element(DB->DS[2],C));
	    else GraphNow=Ins_List_Element(NULL,"UNDEF",0);
	    for(_=0;_<NumofGraphs;_++)
	      if(Is_List_Element(GraphNow,Get_List_Element(DGS,_)))
		GraphBuffer[_]=1;
	    C++;
	 }
	 for(_=0;_<NumofGraphs;_++) Graph[_]&=GraphBuffer[_];
	 Prev=New;
      }
      for(_=0;_<NumofGraphs;_++)
	if(Graph[_]){ 
	   if(ThinkOutLoud) printf("Found directed graph type: %s\n",Get_List_Element(DGS,_)); 
	   Found=1;
	   FinalGraphs[_]=1; 
	   FinalAns=ROM_Meanings[SentenceNumber]; 
	   SentenceMatches++; 
	}
      
   }
   if(!Found){
      if(ThinkOutLoud) puts("Unable to identify sentence structure (none found).");
      return NULL;
   }
   else{
      Found=0;
      for(_=0;_<NumofGraphs;_++)
	if(FinalGraphs[_])
	  Found++;
      if(Found>1){
	 if(ThinkOutLoud)
	   puts("Unable to identify sentence structure (ambiguous).");
	 return NULL;
      }
      else{
	if(SentenceMatches==1){
	  Found=Size_of_List(WordList);
	  Disambiguated=FinalAns;
	  Disambiguated=Del_List_Element(Disambiguated,Size_of_List(Disambiguated)-1);
	  SentenceUnits=Str2List(Get_List_Element(ROM_Lang->DS[2],Find_List_Element(ROM_Lang->DS[1],":sentenceunit")));
	  ValidSentence=1;
	  for(Buffer=SentenceUnits;Buffer;Buffer=Buffer->Next){
	    if(!Is_List_Element(Disambiguated,Buffer->Str))
	      ValidSentence=0;
	  }
	    
	  if(!ValidSentence){
	    if(ThinkOutLoud) puts("Invalid Sentence!");
	    return NULL;
	  }
	  for(_=0;_<Found;_++){
	    if(Chaos_Template[_]-1){
	      Prev=Get_List_Element(WordList,_);
	      New=Get_List_Element(FinalAns,_);
	      if(AutoLearnWords)
		if(!Is_List_Element(Str2List(Goto_DB_Entry(Database[1],Prev)->DS[0]->Next->Str),New))
		  Attribute(Ins_List_Element(NULL,Prev,0),Ins_List_Element(NULL,New,0),1);
	    }
	  }
	}
	else{
	  if(ThinkOutLoud)
	    puts("Couldn't assign meanings - grammatical ambiguity.");
	  /* Need to request further info for any unclassified words... */
	  Buffer=NULL;
	  C=0;
	  for(_=0;_<SentenceLength;_++){
	    if(Chaos_Template[_]>1) Buffer=Ins_List_Element(Buffer,Get_List_Element(WordList,_),C++);
	  }
	  if(Buffer){
	    if(ThinkOutLoud)
	      PrintListSpecial("What is the meaning of: \"",Buffer,"\", \"","\" and \"","\"?\n");
	  }
	  return NULL;
	}
	for(_=0;_<NumofGraphs;_++){
	  if(FinalGraphs[_]){
	    Classification=Get_List_Element(DGS,_);
	    /* this will segfault if some are undefined. */
	    InterceptedSpirit=IsGrammarAttribute(":whqevent",Classification)+2*IsGrammarAttribute(":ynqevent",Classification)+3*IsGrammarAttribute(":infoevent",Classification)+4*IsGrammarAttribute(":impevent",Classification);
	    return Classification;
	  }
	}
      }
   }
   return NULL;
}

/*! \brief Semantic pathfinding heuristic. 
 * 
 */
struct Meanings *S_Spline(char *Start,char *Finish,struct List_Str *Spline_Used,struct List_Str *CSVerbs,struct List_Str *CSNouns){
  int Flag=0,Type=0,Save=0,Ended=0;
  unsigned long int _=0;
  char *AnsStr=NULL,*RecordName=NULL;
  struct List_Str *Buffer=NULL,*Buffer1=NULL,*Buffer2=NULL,*Buffer3=NULL,*D1=NULL,*D2=NULL,*D3=NULL;
  struct List_Str *Buffer4=NULL;
  struct Datablock *DB=NULL;
  struct Meanings *Subjective_Thoughts=NULL,*Ideas=NULL;
  /* Add current position to used, exit if already exists */
  if(!Is_List_Element(Spline_Used,Start))
    Spline_Used=Ins_List_Element(Spline_Used,Start,0);
  else
    return NULL;
  /* stop run-away conditions and highly intensive processing */
  if(Size_of_List(Spline_Used)>EMPATHY_MAX_DEPTH)
    return NULL;
  /* if its not cs number */
  if(strncmp(Start,"cs",2)){
    /* if not ended */
    if(strcmp(Start,Finish)){
      Flag=1;
      Type=0;
    }
    else
      Ended=1;
  }
  else{
    /* is a cs number get the reconstruct the CS into a phrase */
    if(!Is_List_Element(IntCSRecon(Start),Finish)){
      Flag=1;
      Type=1;
    }
    else
      Ended=1;
  }
  /* ended */
  if(Ended){
    /* if not the start then return the finish, otherwise return nothing */
    if(Size_of_List(Spline_Used)>EMPATHY_MIN_DEPTH){
      Subjective_Thoughts=ZeroMeanings();
      Subjective_Thoughts->Conversations=Add_To_Array(Subjective_Thoughts->Conversations,Ins_List_Element(NULL,Finish,0),Subjective_Thoughts->Size++);
    }
    return Subjective_Thoughts;    
  }
  /* if not terminated */
  if(Flag){
    /* for every sentence (ie verb) */
    for(Buffer=CSVerbs;Buffer;Buffer=Buffer->Next){
      RecordName=StrCat("_examples_",Buffer->Str);
      DB=Goto_DB_Entry(Database[0],RecordName);
      free(RecordName);
      /* for every subject and predicate noun block within the verb record */
      for(Buffer4=DB->DS[1],Buffer2=DB->DS[2];Buffer4&&Buffer2;Buffer4=Buffer4->Next,Buffer2=Buffer2->Next){
	D2=IntCSRecon(Buffer2->Str);
	for(Buffer1=Str2List(Buffer4->Str);Buffer1;Buffer1=Buffer1->Next){ 	/* added recently */
	  /* double check that the subject and predicate nouns are in the CSNouns list */
	  if((Is_List_Element(CSNouns,Buffer1->Str))&&(Is_List_Element(CSNouns,Buffer2->Str))){
	    /* loop through any phrases that overlap with the current sentence */
	    for(Buffer3=SharedContext(Start,CSVerbs,CSNouns);Buffer3;Buffer3=Buffer3->Next){
	      D1=IntCSRecon(Buffer1->Str);
	      D3=IntCSRecon(Buffer->Str);
	      Save=0;
	      /* if not terminated then recurse */	      
	      if(Type==0){
		if(Is_List_Element(D1,Start))
		  if((Ideas=S_Spline(Buffer2->Str,Finish,Spline_Used,CSVerbs,CSNouns)))
		    Save=1;
		if(Is_List_Element(D2,Start))
		  if((Ideas=S_Spline(Buffer1->Str,Finish,Spline_Used,CSVerbs,CSNouns)))
		    Save=1;
	      }
	      else{
		if(!strcmp(Buffer1->Str,Buffer3->Str))
		  if((Ideas=S_Spline(Buffer2->Str,Finish,Spline_Used,CSVerbs,CSNouns)))
		    Save=1;
		if(!strcmp(Buffer2->Str,Buffer3->Str))
		  if((Ideas=S_Spline(Buffer1->Str,Finish,Spline_Used,CSVerbs,CSNouns)))
		    Save=1;
	      }
	      /* if something has been returned then save it */
	      if(Save){
		/* if nothing has been found then save nothing */
		if(!Subjective_Thoughts)
		  Subjective_Thoughts=ZeroMeanings();
		/* otherwise save what has been returned */
		if(Ideas->Size){
		  AnsStr=List2Str(Convert2Sentence(CreateSentenceStruct(Ins_List_Element(NULL,List2Str(D1),0),0,Ins_List_Element(NULL,List2Str(D2),0),0,D3,0,"indicative")));
		}
		for(_=0;_<Ideas->Size;_++)
		  Subjective_Thoughts->Conversations=Add_To_Array(Subjective_Thoughts->Conversations,Ins_List_Element(Ideas->Conversations[_],AnsStr,0),Subjective_Thoughts->Size++);
	      }
	    }
	  }
	}
      }
    }
    return Subjective_Thoughts;
  }
  return NULL;
}

/*! \brief Remove duplicate routes from S_Spline().
 * 
 */
struct Meanings *Optimise_Spline(struct Meanings *Thoughts){
   int _=0,Pos=0;
   char *Tag=NULL;
   struct List_Str *Buffer=NULL,*Cache=NULL,*Unique=NULL,*Separated=NULL;
   struct Meanings *Filtered_Thoughts=NULL;
   if(Thoughts){
      Filtered_Thoughts=(struct Meanings *)malloc(sizeof(MeaningTemplate));
      Filtered_Thoughts->Size=0;
      Filtered_Thoughts->Conversations=NULL;
      for(_=0;_<Thoughts->Size;_++){
	 Cache=Del_List_Element(Cpy_List(Thoughts->Conversations[_]),Size_of_List(Thoughts->Conversations[_])-1);
	 if(Cache){
	    Pos=0;
	    Unique=NULL;
	    for(Separated=Cache;Separated;Separated=Separated->Next)
	       if(Find_List_Element(Unique,Separated->Str)==-1)
		 Unique=Ins_List_Element(Unique,Separated->Str,Pos++);
	    Cache=Unique;
	    Tag=List2Str(Cache);
	    if(!Is_List_Element(Buffer,Tag)){
	       Buffer=Ins_List_Element(Buffer,Tag,0);
	       Filtered_Thoughts->Conversations=Add_To_Array(Filtered_Thoughts->Conversations,Cache,Filtered_Thoughts->Size++);
	    }
	 }
      }
   }
   return Filtered_Thoughts;
}

/*! \brief A function to find semantic pathways between words.
 * 
 */
int Route_Stage(char *P1, char *P2, struct List_Str *Used, struct List_Str *Pathway){
  int LengthofPath=0,Pos=0;
  struct List_Str *L1=NULL;
  struct Datablock *DB=NULL;
  if(!Is_List_Element(Used,P1)){
    Used=Ins_List_Element(Used,P1,0);
    Pathway=Ins_List_Element(Pathway,P1,0);
  }
  else
    return 0;
  DB=Goto_DB_Entry(Database[1],P1);
  L1=DB->DS[1];
  Pos=Find_List_Element(L1,P2);
  if((!strcmp(P1,P2))||(Pos!=-1)){
    Pathway=Ins_List_Element(Pathway,P2,0);
    LengthofPath=Size_of_List(Pathway);
    if((LengthofPath<Route_Shortest_Length)||(!Route_Shortest_Length)){
      Route_Shortest_Length=LengthofPath;
      Route_Shortest=Pathway;
    }
    return 1;
  }
  for(;L1;L1=L1->Next)
    if(!Is_List_Element(Used,L1->Str))
      Route_Stage(L1->Str,P2,Used,Pathway);
  return 0;
}

/*! \brief A function to find semantic pathways between words.
 * - Wraps Route_Stage().
 */
struct List_Str *Route(struct List_Str *WordList,struct List_Str *L){
  char *Start=WordList->Str,*Finish=L->Str;
  struct List_Str *Result=NULL;
  Route_Shortest_Length=0;
  Route_Shortest=NULL;
  Route_Length=NULL;
  Route_Stage(Start,Finish,NULL,NULL);
  if(Route_Shortest)
    for(Result=Route_Shortest;Result;Result=Result->Next)
      ANSWER=Ins_List_Element(ANSWER,Result->Str,0);
  return L->Next;
}

/*! \brief Pathfinding heuristic between "Start" and "Finish".
 * 
 */
struct List_Str *D_Spline(char *Start,char *Finish,struct List_Str *Spline_Used){
   unsigned long int CSMax=0,CSC=0;
   char *CSRec=(char *)malloc(12*sizeof(char *)),*Vref=NULL,*Equiv=NULL;
   struct List_Str *R=NULL,*Associations=NULL,*Buffer=NULL,*Buffer2=NULL,*Retrieved=NULL,*FinalRoute=NULL,*D1=NULL,*D2=NULL;
   struct Datablock *DB=NULL;
   Spline_Used=Ins_List_Element(Spline_Used,Start,0);
   if(Size_of_List(Spline_Used)>EMPATHY_MAX_DEPTH)
     return NULL;
   if(strcmp(Start,Finish)){
      DB=Goto_DB_Entry(Database[1],Start);
      if(!DB)
	return NULL;
      Buffer2=DB->DS[2];
      for(Buffer=DB->DS[1];Buffer;Buffer=Buffer->Next){
	 for(D1=Str2List(Buffer->Str);D1;D1=D1->Next)
	   if((!Is_List_Element(Associations,D1->Str))&&(!Is_List_Element(Spline_Used,D1->Str)))
	     Associations=Ins_List_Element(Associations,D1->Str,0);
	 for(D2=Str2List(Buffer2->Str);D2;D2=D2->Next)
	   if((!Is_List_Element(Associations,D2->Str))&&(!Is_List_Element(Spline_Used,D2->Str)))
	     Associations=Ins_List_Element(Associations,D2->Str,0);
	 Buffer2=Buffer2->Next;
      }
      if((Vref=Get_DB_Entry(DB,0,3)))
	for(D1=Str2List(Vref);D1;D1=D1->Next)
	  if((!Is_List_Element(Associations,D1->Str))&&(!Is_List_Element(Spline_Used,D1->Str)))
	    Associations=Ins_List_Element(Associations,D1->Str,0);
      if((Equiv=Get_DB_Entry(DB,0,7)))
	for(D2=Str2List(Equiv);D2;D2=D2->Next)
	  if((!Is_List_Element(Associations,D2->Str))&&(!Is_List_Element(Spline_Used,D2->Str)))
	    Associations=Ins_List_Element(Associations,D2->Str,0);
      CSMax=atol(Get_DB_Entry(Goto_DB_Entry(Database[1],":mode"),0,7)+2);
      memset(CSRec,0,11);
      for(CSC=0;CSC<CSMax;CSC++){
	 sprintf(CSRec,"cs%ld",CSC);
	 if(Is_List_Element(IntCSRecon(CSRec),Start))
	   Associations=Ins_List_Element(Associations,CSRec,0);
      }
      for(Buffer=Associations;Buffer;Buffer=Buffer->Next){
	if((Retrieved=D_Spline(Buffer->Str,Finish,Spline_Used)))
	   for(Buffer2=Retrieved;Buffer2;Buffer2=Buffer2->Next)
	     FinalRoute=Ins_List_Element(FinalRoute,List2Str(Ins_List_Element(Str2List(Buffer2->Str),Start,0)),0);
      }
      if(FinalRoute)
	return FinalRoute;
      else
	return NULL;
   }
   else{
      if(Size_of_List(Spline_Used)>EMPATHY_MIN_DEPTH)
	R=Ins_List_Element(NULL,Finish,0);
      else
	return NULL;
   }
   return R;
}

/*

            88 oooooooooooo ooooo      ooo  o8o  ooooooo  ooooo   .oooo.          
   .dP     .8' `888'     `8 `888b.     `8'  `"'   `8888    d8'  .dP""Y88b  Yb     
 .dP      .8'   888          8 `88b.    8  oooo     Y888..8P          ]8P'  `Yb   
dP       .8'    888oooo8     8   `88b.  8  `888      `8888'         <88b.     `Yb 
Yb      .8'     888    "     8     `88b.8   888     .8PY888.         `88b.    .dP 
 `Yb   .8'      888       o  8       `888   888    d8'  `888b   o.   .88P   .dP   
   `Yb 88      o888ooooood8 o8o        `8  o888o o888o  o88888o `8bd88P'   dP     


 */
